package parking.app;

import java.time.LocalDate;
import java.time.LocalDateTime;
import parking.model.*;
import parking.service.*;

public class Tests2 {
    static LocalDateTime at(int h, int m) { return TestRunner.at(h, m); }

    static ParkingFacility newFacility() {
        // register new categories WITHOUT editing any existing class
        VehicleFactory.register("EBIKE", EBike::new);
        VehicleFactory.register("DELIVERYVAN", DeliveryVan::new);
        PricingPolicy p = new PricingPolicy();
        p.register(EBike.class, new FlatFeeRule(15));
        p.register(DeliveryVan.class, new PeakWindowRule(9, 17, 2.0));
        // 5 floors, different number of slots on each floor (jagged array)
        return new ParkingFacility(new int[]{20, 30, 40, 50, 60}, new FeeService(p));
    }

    public static void main(String[] args) {
        System.out.println("=== PART 1: original (Task 11) tests re-run unchanged on the new code ===");
        TestRunner.main(new String[0]);
        System.out.println("\n=== PART 2: Task 12 tests ===");
        System.out.printf("%-5s | %-48s | %-22s | %-22s | %s%n", "ID", "Test", "Expected", "Actual", "Result");
        Visitor vis = new Visitor("Guest"); Staff st = new Staff("Dr. S", true);
        ParkingFacility f = newFacility();
        check("C1", "Capacity of 5 jagged floors 20+30+40+50+60", 200, f.capacity());
        check("E1", "E-bike flat fee, 10 min", 15.0, run(f, "EBike", "EB1", vis, at(9, 0), at(9, 10)));
        check("E2", "E-bike flat fee, 6 hours (same flat fee)", 15.0, run(f, "EBike", "EB2", vis, at(9, 0), at(15, 0)));
        check("V1", "Van 10:00-13:00, all peak (3 x 60)", 180.0, run(f, "DeliveryVan", "DV1", vis, at(10, 0), at(13, 0)));
        check("V2", "Van 07:00-09:00, all off-peak (2 x 30)", 60.0, run(f, "DeliveryVan", "DV2", vis, at(7, 0), at(9, 0)));
        check("V3", "Van 08:30-10:15: hours start 8:30(30) 9:30(60)", 90.0, run(f, "DeliveryVan", "DV3", vis, at(8, 30), at(10, 15)));
        check("V4", "Van 16:30-18:00: hours start 16:30(60) 17:30(30)", 90.0, run(f, "DeliveryVan", "DV4", vis, at(16, 30), at(18, 0)));
        check("V5", "Van 0 minutes", 0.0, run(f, "DeliveryVan", "DV5", vis, at(10, 0), at(10, 0)));
        Visitor pv = new Visitor("PassVisitor"); pv.buyOneDayPass(LocalDate.of(2026, 11, 12));
        check("P1", "Visitor one-day pass, same day -> free", 0.0, run(f, "Car", "PC1", pv, at(9, 0), at(12, 0)));
        Visitor pv2 = new Visitor("OldPass"); pv2.buyOneDayPass(LocalDate.of(2026, 11, 11));
        check("P2", "Visitor pass for another day -> pays (3h x 30)", 90.0, run(f, "Car", "PC2", pv2, at(9, 0), at(12, 0)));
        Visitor pv3 = new Visitor("PassEV"); pv3.buyOneDayPass(LocalDate.of(2026, 11, 12));
        check("P3", "Pass covers parking, NOT charging (5 kWh)", 60.0, runKwh(f, "ElectricCar", "PE1", pv3, at(9, 0), at(11, 0), 5));
        check("R1", "Regression: Car unchanged (3h x 30)", 90.0, run(f, "Car", "R1", vis, at(9, 0), at(12, 0)));
        check("R2", "Regression: EV unchanged (3h x 30 + 10kWh)", 210.0, runKwh(f, "ElectricCar", "R2", vis, at(8, 0), at(10, 10), 10));
        check("R3", "Regression: staff pass still free", 0.0, run(f, "Car", "R3", st, at(8, 0), at(17, 0)));
        check("X1", "Unknown type still rejected", "IllegalArgumentException",
              TestRunner.thrown(() -> VehicleFactory.create("Tractor", "T1", vis)));
        // fill the whole 200-slot jagged facility, then one more
        ParkingFacility big = newFacility();
        for (int i = 0; i < 200; i++) big.enter(VehicleFactory.create("Car", "BIG" + i, vis), at(9, 0));
        check("F1", "All 200 slots on 5 floors can be used", 200, big.getOccupied());
        check("F2", "201st vehicle rejected", "ParkingFullException",
              TestRunner.thrown(() -> big.enter(VehicleFactory.create("Car", "BIG200", vis), at(9, 1))));
        // hand-calculated total for a new-category day
        ParkingFacility day = newFacility();
        double total = 0;
        total += run(day, "EBike", "HD1", vis, at(9, 0), at(10, 0));             // 15
        total += run(day, "DeliveryVan", "HD2", vis, at(10, 0), at(13, 0));      // 180
        total += run(day, "DeliveryVan", "HD3", vis, at(8, 30), at(10, 15));     // 90
        total += run(day, "Car", "HD4", pv, at(9, 0), at(12, 0));                // 0
        total += run(day, "Car", "HD5", vis, at(9, 0), at(11, 30));              // 90
        check("H1", "Day total 15+180+90+0+90", 375.0, total);
        check("H2", "Facility collection equals the same", 375.0, day.getCollection());
        System.out.println("\nTask 12 summary: " + TestRunner.pass + " passed, " + TestRunner.fail + " failed (cumulative with Part 1)");
    }

    static double run(ParkingFacility f, String type, String reg, ParkingUser u, LocalDateTime in, LocalDateTime out) {
        return runKwh(f, type, reg, u, in, out, 0);
    }
    static double runKwh(ParkingFacility f, String type, String reg, ParkingUser u, LocalDateTime in, LocalDateTime out, int kWh) {
        f.enter(VehicleFactory.create(type, reg, u), in);
        return f.exit(reg, out, kWh);
    }
    static void check(String id, String w, Object e, Object a) { TestRunner.check(id, w, e, a); }
}
