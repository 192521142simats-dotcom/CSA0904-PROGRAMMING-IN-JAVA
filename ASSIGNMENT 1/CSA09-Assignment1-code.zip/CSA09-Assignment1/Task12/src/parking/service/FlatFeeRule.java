package parking.service;

import java.time.LocalDateTime;
import parking.model.Vehicle;

/** NEW: one fixed amount per visit (e-bikes). */
public class FlatFeeRule implements PricingRule {
    private final double amount;
    public FlatFeeRule(double amount) { this.amount = amount; }
    @Override public double fee(Vehicle v, LocalDateTime in, LocalDateTime out) { return amount; }
}
