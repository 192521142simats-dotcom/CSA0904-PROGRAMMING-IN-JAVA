package parking.service;

import java.time.Duration;
import java.time.LocalDateTime;
import parking.model.Vehicle;

/** NEW: each started hour is priced by its start time; hours starting in [from,to) cost multiplier x rate. */
public class PeakWindowRule implements PricingRule {
    private final int fromHour, toHour; private final double multiplier;
    public PeakWindowRule(int fromHour, int toHour, double multiplier) {
        this.fromHour = fromHour; this.toHour = toHour; this.multiplier = multiplier;
    }
    @Override public double fee(Vehicle v, LocalDateTime in, LocalDateTime out) {
        int minutes = Math.toIntExact(Duration.between(in, out).toMinutes());
        int hours = (minutes + 59) / 60;
        double total = 0;
        for (int i = 0; i < hours; i++) {
            int h = in.plusHours(i).getHour();
            total += v.hourlyRate() * ((h >= fromHour && h < toHour) ? multiplier : 1);
        }
        return total;
    }
}
