package parking.service;

import java.time.Duration;
import java.time.LocalDateTime;
import parking.model.Vehicle;

/** The ORIGINAL rule (hourly + daily cap), moved out of FeeService unchanged in behaviour. */
public class StandardHourlyRule implements PricingRule {
    @Override public double fee(Vehicle v, LocalDateTime in, LocalDateTime out) {
        int minutes = Math.toIntExact(Duration.between(in, out).toMinutes());
        int days = minutes / 1440, rem = minutes % 1440;
        return days * v.dailyCap() + Math.min(v.dailyCap(), v.calculateFee(rem));
    }
}
