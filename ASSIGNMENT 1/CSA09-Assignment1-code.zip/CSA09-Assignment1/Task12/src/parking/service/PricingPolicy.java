package parking.service;

import java.util.HashMap;
import java.util.Map;
import parking.model.Vehicle;

/** NEW: maps a vehicle class to its rule; walks up the class chain; default = standard hourly. */
public class PricingPolicy {
    private final Map<Class<? extends Vehicle>, PricingRule> rules = new HashMap<>();
    private final PricingRule fallback = new StandardHourlyRule();

    public void register(Class<? extends Vehicle> type, PricingRule rule) { rules.put(type, rule); }

    public PricingRule ruleFor(Vehicle v) {
        for (Class<?> c = v.getClass(); c != null && Vehicle.class.isAssignableFrom(c); c = c.getSuperclass()) {
            PricingRule r = rules.get(c);
            if (r != null) return r;
        }
        return fallback;
    }
}
