package parking.service;

import java.time.Duration;
import java.time.LocalDateTime;
import parking.model.*;

/** MODIFIED in Task 12: parking fee now delegated to a PricingRule chosen by PricingPolicy. */
public class FeeService {
    private final PricingPolicy policy;
    public FeeService() { this(new PricingPolicy()); }          // old behaviour: standard rule for all
    public FeeService(PricingPolicy policy) { this.policy = policy; }

    public double fee(ParkingTicket t, LocalDateTime out, int kWh) {
        if (out.isBefore(t.getEntry())) throw new IllegalArgumentException("exit before entry");
        Vehicle v = t.getVehicle();
        boolean free = v.getOwner().isFeeExempt(t.getEntry().toLocalDate());
        double parking = free ? 0 : policy.ruleFor(v).fee(v, t.getEntry(), out);
        double charging = (v instanceof Chargeable c) ? c.chargingFee(kWh) : 0;
        return parking + charging;
    }
}
