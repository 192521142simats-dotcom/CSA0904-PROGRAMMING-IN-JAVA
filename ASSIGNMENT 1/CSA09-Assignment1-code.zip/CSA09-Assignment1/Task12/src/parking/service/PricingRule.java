package parking.service;

import java.time.LocalDateTime;
import parking.model.Vehicle;

/** NEW (Task 12): Strategy - one place per pricing rule. */
public interface PricingRule {
    double fee(Vehicle v, LocalDateTime in, LocalDateTime out);
}
