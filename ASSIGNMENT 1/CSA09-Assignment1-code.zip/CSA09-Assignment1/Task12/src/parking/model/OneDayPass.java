package parking.model;

import java.time.LocalDate;

/** NEW (Task 12): visitor one-day pass, valid only on the purchase date. */
public class OneDayPass implements Pass {
    private final LocalDate validOn;
    public OneDayPass(LocalDate validOn) { this.validOn = validOn; }
    @Override public boolean covers(LocalDate day) { return validOn.equals(day); }
}
