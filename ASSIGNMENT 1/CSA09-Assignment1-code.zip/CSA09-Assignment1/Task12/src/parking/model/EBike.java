package parking.model;

/** NEW (Task 12): e-bike, charged a flat fee by its pricing rule. */
public class EBike extends Vehicle {
    public EBike(String regNo, ParkingUser owner) { super(regNo, owner); }
    @Override protected double ratePerHour() { return 0; }   // not hourly
}
