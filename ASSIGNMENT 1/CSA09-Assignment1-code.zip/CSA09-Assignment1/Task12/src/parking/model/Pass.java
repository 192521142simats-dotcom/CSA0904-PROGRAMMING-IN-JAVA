package parking.model;

import java.time.LocalDate;

/** NEW (Task 12): abstraction for any pass that can make a stay free. */
public interface Pass {
    boolean covers(LocalDate day);
}
