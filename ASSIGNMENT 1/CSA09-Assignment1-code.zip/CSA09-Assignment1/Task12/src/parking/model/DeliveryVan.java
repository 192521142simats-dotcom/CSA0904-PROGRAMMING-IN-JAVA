package parking.model;

/** NEW (Task 12): delivery van, base rate = car rate; doubled 9-17 by its pricing rule. */
public class DeliveryVan extends Vehicle {
    public DeliveryVan(String regNo, ParkingUser owner) { super(regNo, owner); }
    @Override protected double ratePerHour() { return 30; }
}
