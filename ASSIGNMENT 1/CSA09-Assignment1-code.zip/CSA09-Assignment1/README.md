# CSA09-<RegisterNumber>-Assignment1

Name: <Your Name>  |  Register number: <RegisterNumber>  |  Java: OpenJDK 21

Campus Smart-Parking System – object-oriented model in Java.

| Folder | Task | Compile and run | Result |
|---|---|---|---|
| Task03 | Complete the Code (allocate/release) | `javac ParkingFacility.java && java ParkingFacility` | output equals expected output |
| Task08 | Complete the Code (Vehicle hierarchy, FeeDemo) | `javac FeeDemo.java && java FeeDemo` | output equals expected output (Rs 30/90/210, true) |
| Task11 | Full system + tests (Tasks 1-11) | `javac -d out $(find src -name "*.java")`; `java -cp out parking.app.Main`; `java -cp out parking.app.TestRunner` | 26/26 tests pass |
| Task12 | Day-4 redesign (e-bike, van, one-day pass, 5 jagged floors) | same; `java -cp out parking.app.Tests2` | 45/45 tests pass (26 original unchanged + 19 new) |
| Benchmarks | timings for the complexity analyses | `javac Benchmarks.java && java Benchmarks` | see outputs/benchmarks_output.txt |

Commit one task at a time (git add Task03 && git commit ...) so the history shows progressive work.
