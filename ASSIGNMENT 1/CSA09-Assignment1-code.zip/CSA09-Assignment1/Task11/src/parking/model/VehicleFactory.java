package parking.model;

import java.util.HashMap;
import java.util.Map;
import java.util.function.BiFunction;

/** Creates vehicles by type name. New types are REGISTERED, the factory is never edited. */
public final class VehicleFactory {
    private static final Map<String, BiFunction<String, ParkingUser, Vehicle>> REGISTRY = new HashMap<>();
    static {
        register("TWOWHEELER", TwoWheeler::new);
        register("CAR", Car::new);
        register("ELECTRICCAR", ElectricCar::new);
    }
    private VehicleFactory() {}

    public static void register(String type, BiFunction<String, ParkingUser, Vehicle> maker) {
        REGISTRY.put(type.toUpperCase(), maker);
    }
    public static Vehicle create(String type, String regNo, ParkingUser owner) {
        BiFunction<String, ParkingUser, Vehicle> m = REGISTRY.get(type == null ? "" : type.toUpperCase());
        if (m == null) throw new IllegalArgumentException("Unknown vehicle type: " + type);
        return m.apply(regNo, owner);
    }
}
