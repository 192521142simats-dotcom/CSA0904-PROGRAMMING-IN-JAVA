package parking.model;

import java.time.LocalDateTime;

public final class ParkingTicket {
    private static int counter;                 // shared by ALL tickets
    static { counter = 1000; }                  // static block: first ticket is 1001

    private final int ticketNo;
    private final Vehicle vehicle;
    private final int floor, slot;
    private final LocalDateTime entry;

    /** Main constructor: validates every argument. */
    public ParkingTicket(Vehicle vehicle, int floor, int slot, LocalDateTime entry) {
        if (vehicle == null || entry == null) throw new IllegalArgumentException("null argument");
        if (floor < 0 || slot < 0) throw new IllegalArgumentException("invalid floor/slot");
        this.ticketNo = ++counter;              // never reused
        this.vehicle = vehicle; this.floor = floor; this.slot = slot; this.entry = entry;
    }
    /** Overloaded constructor chaining to the main one with the current time. */
    public ParkingTicket(Vehicle vehicle, int floor, int slot) {
        this(vehicle, floor, slot, LocalDateTime.now());
    }
    /** Copy constructor: duplicate (re-issued) ticket keeps the SAME number. */
    public ParkingTicket(ParkingTicket t) {
        this.ticketNo = t.ticketNo; this.vehicle = t.vehicle;
        this.floor = t.floor; this.slot = t.slot; this.entry = t.entry;
    }

    public static int issuedCount() { return counter - 1000; }

    public int getTicketNo() { return ticketNo; }
    public Vehicle getVehicle() { return vehicle; }
    public int getFloor() { return floor; }
    public int getSlot() { return slot; }
    public LocalDateTime getEntry() { return entry; }
    @Override public String toString() {
        return "Ticket#" + ticketNo + " " + vehicle.getRegNo() + " F" + floor + "/S" + slot + " @" + entry;
    }
}
