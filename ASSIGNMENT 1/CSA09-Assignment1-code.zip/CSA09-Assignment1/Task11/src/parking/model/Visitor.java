package parking.model;

public class Visitor extends ParkingUser {
    public Visitor(String name) { super(name); }
    @Override public boolean isFeeExempt() { return false; }
}
