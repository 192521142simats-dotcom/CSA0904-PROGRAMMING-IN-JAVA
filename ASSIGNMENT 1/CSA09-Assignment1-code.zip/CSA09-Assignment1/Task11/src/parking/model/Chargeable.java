package parking.model;

/** Capability: a vehicle that can be charged and billed per kWh. */
public interface Chargeable {
    double RATE_PER_KWH = 12;
    double chargingFee(int kWh);
}
