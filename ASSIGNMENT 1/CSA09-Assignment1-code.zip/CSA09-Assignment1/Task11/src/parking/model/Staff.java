package parking.model;

public class Staff extends ParkingUser {
    private final boolean monthlyPass;
    public Staff(String name, boolean monthlyPass) { super(name); this.monthlyPass = monthlyPass; }
    @Override public boolean isFeeExempt() { return monthlyPass; }
}
