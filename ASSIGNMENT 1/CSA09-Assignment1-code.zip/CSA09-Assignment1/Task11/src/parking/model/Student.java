package parking.model;

public class Student extends ParkingUser {
    private final boolean monthlyPass;
    public Student(String name, boolean monthlyPass) { super(name); this.monthlyPass = monthlyPass; }
    @Override public boolean isFeeExempt() { return monthlyPass; }
}
