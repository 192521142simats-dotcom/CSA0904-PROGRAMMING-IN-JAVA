package parking.model;

public class Car extends Vehicle {
    public Car(String regNo, ParkingUser owner) { super(regNo, owner); }
    @Override protected double ratePerHour() { return 30; }
}
