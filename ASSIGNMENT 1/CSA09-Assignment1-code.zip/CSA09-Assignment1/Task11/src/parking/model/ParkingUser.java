package parking.model;

/** The person who owns the vehicle. Students and staff may hold a monthly pass. */
public abstract class ParkingUser {
    private final String name;

    protected ParkingUser(String name) {
        if (name == null || name.isBlank()) throw new IllegalArgumentException("name required");
        this.name = name;
    }
    public String getName() { return name; }

    /** true if the user parks free of charge. */
    public abstract boolean isFeeExempt();

    @Override public String toString() { return getClass().getSimpleName() + "(" + name + ")"; }
}
