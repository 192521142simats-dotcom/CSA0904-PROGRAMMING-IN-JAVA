package parking.model;

public class TwoWheeler extends Vehicle {
    public TwoWheeler(String regNo, ParkingUser owner) { super(regNo, owner); }
    @Override protected double ratePerHour() { return 10; }
}
