package parking.model;

import java.time.Duration;
import java.time.LocalTime;

public abstract class Vehicle {
    private final String regNo;          // final: identity never changes
    private final ParkingUser owner;

    protected Vehicle(String regNo, ParkingUser owner) {
        if (regNo == null || regNo.isBlank()) throw new IllegalArgumentException("regNo required");
        if (owner == null) throw new IllegalArgumentException("owner required");
        this.regNo = regNo.trim().toUpperCase();
        this.owner = owner;
    }

    public String getRegNo() { return regNo; }
    public ParkingUser getOwner() { return owner; }

    protected abstract double ratePerHour();
    /** Public read access to the rate for the pricing code in other packages. */
    public final double hourlyRate() { return ratePerHour(); }

    /** Compile-time polymorphism: overload 1 - every started hour is charged in full. */
    public double calculateFee(int minutes) {
        if (minutes < 0) throw new IllegalArgumentException("negative duration");
        int hours = (minutes + 59) / 60;          // integer ceiling
        return hours * ratePerHour();
    }

    /** Overload 2 - same-day entry and exit times. */
    public double calculateFee(LocalTime in, LocalTime out) {
        return calculateFee(Math.toIntExact(Duration.between(in, out).toMinutes()));
    }

    /** Daily maximum: 8 hours of the hourly rate. */
    public double dailyCap() { return 8 * ratePerHour(); }

    @Override public boolean equals(Object o) {
        return o instanceof Vehicle && regNo.equals(((Vehicle) o).regNo);
    }
    @Override public int hashCode() { return regNo.hashCode(); }
    @Override public String toString() { return getClass().getSimpleName() + "[" + regNo + "]"; }
}
