package parking.model;

public class ElectricCar extends Car implements Chargeable {
    public ElectricCar(String regNo, ParkingUser owner) { super(regNo, owner); }
    @Override public double chargingFee(int kWh) {
        if (kWh < 0) throw new IllegalArgumentException("negative kWh");
        return kWh * RATE_PER_KWH;
    }
}
