package parking.service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import parking.model.*;

public class ParkingFacility {
    private final String[][] slots;                       // jagged: floors may differ in size
    private final Map<String, ParkingTicket> active = new HashMap<>();
    private final FeeService feeService;
    private double collection;
    private int occupied;

    public ParkingFacility(int[] slotsPerFloor) { this(slotsPerFloor, new FeeService()); }
    public ParkingFacility(int[] slotsPerFloor, FeeService feeService) {
        if (slotsPerFloor == null || slotsPerFloor.length == 0) throw new IllegalArgumentException("no floors");
        slots = new String[slotsPerFloor.length][];
        for (int f = 0; f < slotsPerFloor.length; f++) {
            if (slotsPerFloor[f] <= 0) throw new IllegalArgumentException("slots must be > 0");
            slots[f] = new String[slotsPerFloor[f]];
        }
        this.feeService = feeService;
    }

    public int[] allocate(String regNo) {
        for (int f = 0; f < slots.length; f++)
            for (int s = 0; s < slots[f].length; s++)
                if (slots[f][s] == null) { slots[f][s] = regNo; occupied++; return new int[]{f, s}; }
        return null;
    }
    public boolean release(int floor, int slot) {
        if (floor < 0 || floor >= slots.length || slot < 0 || slot >= slots[floor].length) return false;
        if (slots[floor][slot] == null) return false;
        slots[floor][slot] = null; occupied--; return true;
    }

    public ParkingTicket enter(Vehicle v, LocalDateTime time) {
        if (active.containsKey(v.getRegNo()))
            throw new IllegalStateException("Duplicate registration number: " + v.getRegNo());
        int[] pos = allocate(v.getRegNo());
        if (pos == null) throw new ParkingFullException("No free slot for " + v.getRegNo());
        ParkingTicket t = new ParkingTicket(v, pos[0], pos[1], time);
        active.put(v.getRegNo(), t);
        return t;
    }
    public double exit(String regNo, LocalDateTime time) { return exit(regNo, time, 0); }
    public double exit(String regNo, LocalDateTime time, int kWh) {
        ParkingTicket t = active.get(regNo.trim().toUpperCase());
        if (t == null) throw new IllegalStateException("No active ticket for " + regNo);
        double fee = feeService.fee(t, time, kWh);
        release(t.getFloor(), t.getSlot());
        active.remove(t.getVehicle().getRegNo());
        collection += fee;
        return fee;
    }
    public double getCollection() { return collection; }
    public int getOccupied() { return occupied; }
    public int capacity() { int c = 0; for (String[] f : slots) c += f.length; return c; }
}
