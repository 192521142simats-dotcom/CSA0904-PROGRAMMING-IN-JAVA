package parking.service;

public class ParkingFullException extends RuntimeException {
    public ParkingFullException(String msg) { super(msg); }
}
