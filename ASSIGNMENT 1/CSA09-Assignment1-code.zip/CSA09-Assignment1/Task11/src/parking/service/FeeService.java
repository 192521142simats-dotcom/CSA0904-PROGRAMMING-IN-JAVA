package parking.service;

import java.time.Duration;
import java.time.LocalDateTime;
import parking.model.*;

/** Computes the fee for a completed stay. */
public class FeeService {
    public double fee(ParkingTicket t, LocalDateTime out, int kWh) {
        if (out.isBefore(t.getEntry())) throw new IllegalArgumentException("exit before entry");
        int minutes = Math.toIntExact(Duration.between(t.getEntry(), out).toMinutes());
        Vehicle v = t.getVehicle();
        double parking = v.getOwner().isFeeExempt() ? 0 : cappedFee(v, minutes);
        double charging = (v instanceof Chargeable c) ? c.chargingFee(kWh) : 0;
        return parking + charging;
    }

    /** Full days pay the daily cap; the remainder pays min(cap, hourly fee). */
    private double cappedFee(Vehicle v, int minutes) {
        int days = minutes / 1440, rem = minutes % 1440;
        return days * v.dailyCap() + Math.min(v.dailyCap(), v.calculateFee(rem));
    }
}
