package parking.app;

import java.time.LocalDateTime;
import parking.model.*;
import parking.service.*;

public class Main {
    public static void main(String[] args) {
        LocalDateTime d = LocalDateTime.of(2026, 11, 12, 0, 0);
        ParkingFacility f = new ParkingFacility(new int[]{2, 1});
        Vehicle[] v = {
            VehicleFactory.create("Car", "TN01AB1111", new Visitor("Guest")),
            VehicleFactory.create("TwoWheeler", "TN02CD2222", new Student("Asha", true)),
            VehicleFactory.create("ElectricCar", "TN03EF3333", new Staff("Dr. Rao", true)) };
        ParkingTicket[] t = new ParkingTicket[3];
        for (int i = 0; i < v.length; i++) {
            t[i] = f.enter(v[i], d.plusHours(9));
            System.out.println("ENTER " + t[i]);
        }
        try { f.enter(VehicleFactory.create("Car", "TN04GH4444", new Visitor("Late")), d.plusHours(9)); }
        catch (ParkingFullException e) { System.out.println("REJECTED: " + e.getMessage()); }
        System.out.println("Duplicate ticket (copy ctor): " + new ParkingTicket(t[0]));
        for (int i = 0; i < v.length; i++)
            System.out.println("EXIT  " + v[i].getRegNo() + " fee = Rs " + f.exit(v[i].getRegNo(), d.plusHours(12).plusMinutes(10), 10));
        System.out.println("Collection = Rs " + f.getCollection() + ", occupied = " + f.getOccupied()
                + ", tickets issued = " + ParkingTicket.issuedCount());
    }
}
