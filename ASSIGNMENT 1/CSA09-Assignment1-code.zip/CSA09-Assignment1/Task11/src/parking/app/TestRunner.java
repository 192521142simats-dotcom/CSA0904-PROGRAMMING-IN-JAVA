package parking.app;

import java.time.LocalDateTime;
import java.util.function.Supplier;
import parking.model.*;
import parking.service.*;

public class TestRunner {
    static int pass, fail;
    static final LocalDateTime D = LocalDateTime.of(2026, 11, 12, 0, 0);
    static LocalDateTime at(int h, int m) { return D.plusHours(h).plusMinutes(m); }

    static void check(String id, String what, Object expected, Object actual) {
        boolean ok = String.valueOf(expected).equals(String.valueOf(actual));
        if (ok) pass++; else fail++;
        System.out.printf("%-5s | %-48s | %-22s | %-22s | %s%n", id, what, expected, actual, ok ? "PASS" : "FAIL");
    }
    static String thrown(Runnable r) {
        try { r.run(); return "no exception"; } catch (RuntimeException e) { return e.getClass().getSimpleName(); }
    }

    public static void main(String[] args) {
        System.out.printf("%-5s | %-48s | %-22s | %-22s | %s%n", "ID", "Test", "Expected", "Actual", "Result");
        runBase();
        System.out.println("\nSummary: " + pass + " passed, " + fail + " failed");
    }

    /** Tests for the ORIGINAL requirements. */
    public static void runBase() {
        Visitor vis = new Visitor("Guest"); Staff st = new Staff("Dr. S", true); Student sn = new Student("Stu", false);
        ParkingFacility f = new ParkingFacility(new int[]{2, 2});
        // normal operation
        ParkingTicket t1 = f.enter(new Car("TN01", vis), at(9, 0));
        check("N1", "Car enters: first slot is F0/S0", "0/0", t1.getFloor() + "/" + t1.getSlot());
        ParkingTicket t2 = f.enter(new TwoWheeler("TN02", vis), at(10, 0));
        check("N2", "Ticket numbers increase and are unique", t1.getTicketNo() + 1, t2.getTicketNo());
        check("N3", "Car 09:00-11:30 (150 min -> 3h x 30)", 90.0, f.exit("TN01", at(11, 30)));
        check("N4", "TwoWheeler 10:00-10:45 (1h x 10)", 10.0, f.exit("TN02", at(10, 45)));
        f.enter(new ElectricCar("TN03", vis), at(8, 0));
        check("N5", "EV 08:00-10:10 + 10 kWh (3h x 30 + 120)", 210.0, f.exit("TN03", at(10, 10), 10));
        f.enter(new Car("TN04", st), at(8, 0));
        check("N6", "Staff with monthly pass parks free", 0.0, f.exit("TN04", at(17, 0)));
        check("N7", "Student WITHOUT pass pays (2h x 30)", 60.0, feeFor(f, new Car("TN05", sn), at(9, 0), at(10, 30)));
        // boundary
        check("B1", "Zero-minute stay costs nothing", 0.0, feeFor(f, new Car("TN06", vis), at(9, 0), at(9, 0)));
        check("B2", "Exactly 60 min = 1 hour", 30.0, feeFor(f, new Car("TN07", vis), at(9, 0), at(10, 0)));
        check("B3", "61 min = 2 hours (slab boundary)", 60.0, feeFor(f, new Car("TN08", vis), at(9, 0), at(10, 1)));
        check("B4", "9 h hits daily cap (270 -> 240)", 240.0, feeFor(f, new Car("TN09", vis), at(9, 0), at(18, 0)));
        check("B5", "Exactly 24 h = one capped day", 240.0, feeFor(f, new Car("TN10", vis), at(9, 0), at(9, 0).plusDays(1)));
        check("B6", "25 h = cap + 1 hour", 270.0, feeFor(f, new Car("TN11", vis), at(9, 0), at(10, 0).plusDays(1)));
        ParkingFacility one = new ParkingFacility(new int[]{1});
        one.enter(new Car("L1", vis), at(9, 0));
        check("B7", "Last free slot used -> facility full", 1, one.getOccupied());
        check("B8", "Entry when full is rejected", "ParkingFullException", thrown(() -> one.enter(new Car("L2", vis), at(9, 5))));
        one.exit("L1", at(10, 0));
        check("B9", "Slot reusable after exit", "0/0", one.enter(new Car("L3", vis), at(10, 5)).getFloor() + "/0");
        // invalid
        check("I1", "Unknown vehicle type", "IllegalArgumentException", thrown(() -> VehicleFactory.create("HELICOPTER", "X1", vis)));
        ParkingFacility g = new ParkingFacility(new int[]{3});
        g.enter(new Car("DUP", vis), at(9, 0));
        check("I2", "Duplicate registration number", "IllegalStateException", thrown(() -> g.enter(new Car("DUP", vis), at(9, 1))));
        check("I3", "Release invalid floor", false, g.release(9, 0));
        check("I4", "Release invalid slot", false, g.release(0, -1));
        check("I5", "Release already-free slot", false, g.release(0, 2));
        check("I6", "Exit of vehicle never parked", "IllegalStateException", thrown(() -> g.exit("GHOST", at(10, 0))));
        check("I7", "Exit before entry", "IllegalArgumentException", thrown(() -> g.exit("DUP", at(8, 0))));
        check("I8", "Equal regNo => equal vehicles (Car vs EV)", true, new Car("A1", vis).equals(new ElectricCar("a1", vis)));
        // hand-calculated day collection
        ParkingFacility day = new ParkingFacility(new int[]{2, 2});
        day.enter(new Car("D1", vis), at(9, 0));          day.exit("D1", at(11, 30));          // 90
        day.enter(new TwoWheeler("D2", vis), at(10, 0));  day.exit("D2", at(10, 45));          // 10
        day.enter(new ElectricCar("D3", vis), at(8, 0));  day.exit("D3", at(10, 10), 10);      // 210
        day.enter(new Car("D4", st), at(8, 0));           day.exit("D4", at(17, 0));           // 0
        day.enter(new Car("D5", vis), at(9, 0));          day.exit("D5", at(9, 0));            // 0
        day.enter(new Car("D6", vis), at(9, 0));          day.exit("D6", at(18, 0));           // 240
        check("H1", "Day collection: 90+10+210+0+0+240", 550.0, day.getCollection());
        check("H2", "All slots free at end of day", 0, day.getOccupied());
    }

    static double feeFor(ParkingFacility f, Vehicle v, LocalDateTime in, LocalDateTime out) {
        f.enter(v, in); return f.exit(v.getRegNo(), out);
    }
}
