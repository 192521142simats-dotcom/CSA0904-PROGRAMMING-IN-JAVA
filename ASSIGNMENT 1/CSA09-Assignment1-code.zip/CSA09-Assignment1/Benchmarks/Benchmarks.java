import java.util.*;

/** Own measurements for the "Alternative Concept and Complexity Analysis" sections. */
public class Benchmarks {
    static long sink;                                  // defeats dead-code elimination

    // ---------- helper types ----------
    static class Veh { final String regNo; final String type; final long entry;
        Veh(String r, String t, long e) { regNo = r; type = t; entry = e; } }
    static class Ticket { final String reg; Ticket(String r) { reg = r; } }
    static class T2 { String reg; int floor; void setReg(String r) { reg = r; } void setFloor(int f) { floor = f; } }
    static class T3 { final String reg; final int floor; T3(String r, int f) { reg = r; floor = f; } T3(String r) { this(r, 0); } }

    static abstract class V { abstract double rate(); double fee(int m) { return ((m + 59) / 60) * rate(); } }
    static class A extends V { double rate() { return 10; } }
    static class B extends V { double rate() { return 30; } }
    static class C extends B { double rate() { return 30; } }
    static class D extends V { double rate() { return 60; } }
    static class E extends V { double rate() { return 15; } }
    static class F2 extends V { double rate() { return 20; } }
    static double feeInstanceof(V v, int m) {
        double r;
        if (v instanceof A) r = 10; else if (v instanceof C) r = 30; else if (v instanceof B) r = 30;
        else if (v instanceof D) r = 60; else if (v instanceof E) r = 15; else r = 20;
        return ((m + 59) / 60) * r;
    }

    // ---------- timing util ----------
    interface Job { void run(); }
    static double timeNs(Job j, int reps) {
        for (int i = 0; i < 3; i++) j.run();            // warm-up
        long best = Long.MAX_VALUE;
        for (int k = 0; k < 5; k++) { long t0 = System.nanoTime(); for (int i = 0; i < reps; i++) j.run(); best = Math.min(best, System.nanoTime() - t0); }
        return (double) best / reps;
    }

    public static void main(String[] args) {
        Random rnd = new Random(42);

        System.out.println("B1 (Task 1): search by registration number, objects vs parallel String arrays; ns per search (worst case = last element)");
        for (int n : new int[]{1_000, 10_000, 100_000}) {
            Veh[] objs = new Veh[n]; String[] reg = new String[n], typ = new String[n]; long[] ent = new long[n];
            for (int i = 0; i < n; i++) { String r = "TN" + i; objs[i] = new Veh(r, "CAR", i); reg[i] = r; typ[i] = "CAR"; ent[i] = i; }
            String key = "TN" + (n - 1);
            double a = timeNs(() -> { for (Veh v : objs) if (v.regNo.equals(key)) { sink += v.entry; break; } }, 50);
            double b = timeNs(() -> { for (int i = 0; i < reg.length; i++) if (reg[i].equals(key)) { sink += ent[i]; break; } }, 50);
            System.out.printf("  n=%-7d objects=%10.0f ns   parallel arrays=%10.0f ns%n", n, a, b);
        }

        System.out.println("B2 (Task 2): locate slot (floor,slot) in jagged String[][] vs flat 1-D array vs ArrayList<String[]>; ns per 1,000 lookups");
        int F = 50, S = 1000; String[][] jag = new String[F][S]; String[] flat = new String[F * S];
        List<String[]> al = new ArrayList<>(); for (int f = 0; f < F; f++) al.add(new String[S]);
        int[] fs = new int[1000], ss = new int[1000]; for (int i = 0; i < 1000; i++) { fs[i] = rnd.nextInt(F); ss[i] = rnd.nextInt(S); }
        double j1 = timeNs(() -> { for (int i = 0; i < 1000; i++) sink += jag[fs[i]][ss[i]] == null ? 1 : 0; }, 2000);
        double j2 = timeNs(() -> { for (int i = 0; i < 1000; i++) sink += flat[fs[i] * 1000 + ss[i]] == null ? 1 : 0; }, 2000);
        double j3 = timeNs(() -> { for (int i = 0; i < 1000; i++) sink += al.get(fs[i])[ss[i]] == null ? 1 : 0; }, 2000);
        System.out.printf("  jagged=%.0f ns   flat=%.0f ns   ArrayList=%.0f ns%n", j1, j2, j3);

        System.out.println("B3 (Task 3): allocate() when only the LAST slot is free; scan vs free-slot stack; ns per allocate+release");
        for (int[] cfg : new int[][]{{5, 100}, {50, 1000}, {200, 2000}}) {
            int f = cfg[0], s = cfg[1];
            String[][] sl = new String[f][s];
            for (String[] row : sl) Arrays.fill(row, "X");
            sl[f - 1][s - 1] = null;                                 // only the last slot is free
            double scan = timeNs(() -> {
                for (int i = 0; i < f; i++) { boolean found = false;
                    for (int k = 0; k < s; k++) if (sl[i][k] == null) { sl[i][k] = "V"; found = true; break; }
                    if (found) break; }
                sl[f - 1][s - 1] = null; }, 20);
            ArrayDeque<Integer> stack = new ArrayDeque<>(); stack.push((f - 1) * s + (s - 1));
            double st = timeNs(() -> { int id = stack.pop(); sink += id; stack.push(id); }, 100000);
            System.out.printf("  F=%-4d S=%-5d scan=%10.0f ns   stack=%6.1f ns%n", f, s, scan, st);
        }

        System.out.println("B4 (Task 4): create n tickets: chained constructors vs default ctor + setters; ms for n objects");
        for (int n : new int[]{100_000, 1_000_000}) {
            double a = timeNs(() -> { T3[] x = new T3[n]; for (int i = 0; i < n; i++) x[i] = new T3("R", 1); sink += x.length; }, 1) / 1e6;
            double b = timeNs(() -> { T2[] x = new T2[n]; for (int i = 0; i < n; i++) { T2 t = new T2(); t.setReg("R"); t.setFloor(1); x[i] = t; } sink += x.length; }, 1) / 1e6;
            System.out.printf("  n=%-8d constructor=%7.2f ms   setters=%7.2f ms%n", n, a, b);
        }

        System.out.println("B5 (Task 8): dynamic dispatch vs instanceof chain, k=6 types; ns per 1,000,000 fee calls");
        V[] vs = { new A(), new B(), new C(), new D(), new E(), new F2() };
        int[] pick = new int[1000]; for (int i = 0; i < 1000; i++) pick[i] = rnd.nextInt(6);
        double d1 = timeNs(() -> { double t = 0; for (int r = 0; r < 1000; r++) for (int i = 0; i < 1000; i++) t += vs[pick[i]].fee(130); sink += (long) t; }, 3);
        double d2 = timeNs(() -> { double t = 0; for (int r = 0; r < 1000; r++) for (int i = 0; i < 1000; i++) t += feeInstanceof(vs[pick[i]], 130); sink += (long) t; }, 3);
        System.out.printf("  dispatch=%.0f ns   instanceof=%.0f ns  (per 1e6 calls)%n", d1, d2);

        System.out.println("B6 (Task 11): find active ticket on exit, ArrayList (linear) vs HashMap; ns per lookup (worst case = last)");
        for (int n : new int[]{1_000, 10_000, 100_000}) {
            ArrayList<Ticket> list = new ArrayList<>(); HashMap<String, Ticket> map = new HashMap<>();
            for (int i = 0; i < n; i++) { Ticket t = new Ticket("TN" + i); list.add(t); map.put(t.reg, t); }
            String key = "TN" + (n - 1);
            double a = timeNs(() -> { for (Ticket t : list) if (t.reg.equals(key)) { sink++; break; } }, 50);
            double b = timeNs(() -> { sink += map.get(key) != null ? 1 : 0; }, 100000);
            System.out.printf("  n=%-7d ArrayList=%10.0f ns   HashMap=%7.1f ns%n", n, a, b);
        }

        System.out.println("B7 (Task 10): validation inside setter vs repeated at every caller; ns per 1e6 updates");
        int[] vals = new int[1000]; for (int i = 0; i < 1000; i++) vals[i] = rnd.nextInt(100);
        class Box { private int d; void set(int x) { if (x < 0) throw new IllegalArgumentException(); d = x; } }
        Box bx = new Box();
        double e1 = timeNs(() -> { for (int r = 0; r < 1000; r++) for (int i = 0; i < 1000; i++) bx.set(vals[i]); sink += bx.d; }, 3);
        class Pub { int d; }
        Pub pb = new Pub();
        double e2 = timeNs(() -> { for (int r = 0; r < 1000; r++) for (int i = 0; i < 1000; i++) { int x = vals[i]; if (x < 0) throw new IllegalArgumentException(); pb.d = x; } sink += pb.d; }, 3);
        System.out.printf("  setter validation=%.0f ns   caller validation=%.0f ns (both O(1))%n", e1, e2);
        System.out.println("sink=" + sink);
    }
}
