import java.io.*;
import java.nio.file.*;
import java.util.*;

public class SerVsCsv {
    static class Resident implements Serializable {
        private static final long serialVersionUID = 1L;
        String name; String regNo; transient String password;   // password never written
        transient java.sql.Connection con;                       // not serializable -> transient
        Resident(String n, String r, String p) { name = n; regNo = r; password = p; }
    }
    static class Room implements Serializable { private static final long serialVersionUID = 1L; int no; List<Resident> res = new ArrayList<>(); }
    static class Hostel implements Serializable { private static final long serialVersionUID = 1L; List<Room> rooms = new ArrayList<>(); }

    public static void main(String[] a) throws Exception {
        // 1) What happens if Connection is NOT transient: show the exception
        class Bad implements Serializable { Object con = new Thread(); }   // Thread is not Serializable, like a live Connection
        try (ObjectOutputStream o = new ObjectOutputStream(new ByteArrayOutputStream())) { o.writeObject(new Bad()); }
        catch (NotSerializableException e) { System.out.println("Non-transient Connection -> " + e); }

        // 2) transient fields come back null
        Hostel h = new Hostel(); Room r = new Room(); r.no = 101; r.res.add(new Resident("Arun", "192311001", "secret")); h.rooms.add(r);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        try (ObjectOutputStream o = new ObjectOutputStream(bo)) { o.writeObject(h); }
        Hostel h2; try (ObjectInputStream in = new ObjectInputStream(new ByteArrayInputStream(bo.toByteArray()))) { h2 = (Hostel) in.readObject(); }
        Resident x = h2.rooms.get(0).res.get(0);
        System.out.println("After load: name=" + x.name + " regNo=" + x.regNo + " password=" + x.password + " con=" + x.con);

        // 3) size/time for n residents: serialization vs CSV
        System.out.printf("%n%-8s %-12s %-12s %-12s %-12s %-12s %-12s%n", "n", "ser bytes", "csv bytes", "ser save ms", "ser load ms", "csv save ms", "csv load ms");
        for (int rep = 0; rep < 2; rep++)
        for (int n : new int[]{1000, 10000, 100000}) {
            Hostel H = new Hostel();
            for (int i = 0; i < n; i++) { if (i % 4 == 0) { Room rm = new Room(); rm.no = i / 4; H.rooms.add(rm); }
                H.rooms.get(H.rooms.size() - 1).res.add(new Resident("Student" + i, "19231" + i, "pw")); }
            Path sp = Paths.get("h.ser"), cp = Paths.get("h.csv");
            long t = System.nanoTime();
            try (ObjectOutputStream o = new ObjectOutputStream(new BufferedOutputStream(Files.newOutputStream(sp)))) { o.writeObject(H); }
            double sSave = (System.nanoTime() - t) / 1e6;
            t = System.nanoTime();
            try (ObjectInputStream in = new ObjectInputStream(new BufferedInputStream(Files.newInputStream(sp)))) { in.readObject(); }
            double sLoad = (System.nanoTime() - t) / 1e6;
            t = System.nanoTime();
            try (BufferedWriter w = Files.newBufferedWriter(cp)) { for (Room rm : H.rooms) for (Resident rs : rm.res) { w.write(rm.no + "," + rs.name + "," + rs.regNo); w.newLine(); } }
            double cSave = (System.nanoTime() - t) / 1e6;
            t = System.nanoTime(); int cnt = 0;
            try (BufferedReader rd = Files.newBufferedReader(cp)) { String l; while ((l = rd.readLine()) != null) { l.split(","); cnt++; } }
            double cLoad = (System.nanoTime() - t) / 1e6;
            if (rep == 1) System.out.printf("%-8d %-12d %-12d %-12.1f %-12.1f %-12.1f %-12.1f%n", n, Files.size(sp), Files.size(cp), sSave, sLoad, cSave, cLoad);
            Files.delete(sp); Files.delete(cp);
        }
    }
}
