import java.io.*;
import java.nio.file.*;
import java.util.*;

public class LineCountBench {
    static int unbuffered(Path p) throws IOException {
        int n = 0;
        try (FileInputStream in = new FileInputStream(p.toFile())) {
            int b; while ((b = in.read()) != -1) if (b == '\n') n++;
        } return n;
    }
    static int byteArray(Path p) throws IOException {
        int n = 0; byte[] buf = new byte[8192];
        try (FileInputStream in = new FileInputStream(p.toFile())) {
            int k; while ((k = in.read(buf)) != -1) for (int i = 0; i < k; i++) if (buf[i] == '\n') n++;
        } return n;
    }
    static int bufferedStream(Path p) throws IOException {
        int n = 0;
        try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(p.toFile()), 8192)) {
            int b; while ((b = in.read()) != -1) if (b == '\n') n++;
        } return n;
    }
    static int bufferedReader(Path p) throws IOException {
        int n = 0;
        try (BufferedReader r = Files.newBufferedReader(p)) { while (r.readLine() != null) n++; }
        return n;
    }
    static int readAllLines(Path p) throws IOException { return Files.readAllLines(p).size(); }

    interface Counter { int run(Path p) throws IOException; }
    static double time(Counter c, Path p) throws IOException {
        long t = System.nanoTime(); int n = c.run(p); double ms = (System.nanoTime() - t) / 1e6;
        if (n <= 0) throw new IllegalStateException(); return ms;
    }
    static Path make(int mb) throws IOException {
        Path p = Paths.get("attendance_" + mb + "MB.log");
        long target = mb * 1024L * 1024L; long size = 0; long i = 0;
        try (BufferedWriter w = Files.newBufferedWriter(p)) {
            while (size < target) {
                String l = "2026-11-15,192311" + String.format("%03d", i % 1000) + ",PRESENT,LAB-" + (i % 40);
                w.write(l); w.newLine(); size += l.length() + 1; i++;
            }
        } return p;
    }
    public static void main(String[] a) throws Exception {
        for (int w = 0; w < 3; w++) { Path p = make(1); byteArray(p); bufferedReader(p); unbuffered(p); readAllLines(p); } // JIT warm-up
        System.out.println("Java " + System.getProperty("java.version"));
        System.out.printf("%-6s %-9s %-12s %-12s %-12s %-12s %-12s%n","MB","lines","unbuffered","BufferedIS","byte[8192]","BufferedRdr","readAllLines");
        for (int mb : new int[]{1, 10, 50}) {
            Path p = make(mb);
            int lines = byteArray(p);
            double u = time(LineCountBench::unbuffered, p);
            double bi = time(LineCountBench::bufferedStream, p);
            double ba = time(LineCountBench::byteArray, p);
            double br = time(LineCountBench::bufferedReader, p);
            System.gc(); long before = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
            double ra = time(LineCountBench::readAllLines, p);
            System.out.printf("%-6d %-9d %-12.1f %-12.1f %-12.1f %-12.1f %-12.1f%n", mb, lines, u, bi, ba, br, ra);
            System.out.println("   file bytes=" + Files.size(p) + "  unbuffered read() calls = " + Files.size(p) + "  byte[8192] read() calls = " + (Files.size(p) / 8192 + 1));
            if (mb != 50) Files.delete(p);
        }
        Runtime rt = Runtime.getRuntime();
        System.out.println("max heap MB = " + rt.maxMemory() / (1024 * 1024));
    }
}
