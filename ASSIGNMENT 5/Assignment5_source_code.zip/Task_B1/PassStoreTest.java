import java.nio.file.*;
import java.util.*;

public class PassStoreTest {
    static void show(String label, Object o) {
        System.out.println(String.format("%-34s -> %s", label,
            o instanceof String[] a ? Arrays.toString(a) : String.valueOf(o)));
    }
    public static void main(String[] args) throws Exception {
        Path f = Files.createTempFile("test", ".csv");
        PassStore s = new PassStore(f);
        System.out.println("=== B1.1 functional tests ===");
        s.add("P1", "192311001", "Arun", 12, 4500);
        s.add("P2", "192311002", "Bala", 12, 4500);
        s.add("P3", "192311003", "Divya", 7, 3800);
        show("T1 find existing P3", s.find("P3"));
        show("T2 find missing P999", s.find("P999"));
        Files.writeString(f, "P4,ONLY,THREE\n", StandardOpenOption.APPEND);
        s.add("P5", "192311005", "Eswar", 12, 4500);
        show("T3 find P4 (damaged line)", s.find("P4"));
        show("T4 find P5 (after damaged)", s.find("P5"));
        show("T5 list route 12 (count)", s.listByRoute(12).size());
        System.out.println("\n=== B2 adversarial bus-pass file ===");
        Files.writeString(f,
            "P6,192311006,Farah,12,abc\n" +      // non-numeric amount
            "\n" +                                // empty line
            "P7,192311007,Gita,12,4500,EXTRA\n" + // 6 fields
            "P8,192311008,\"Hari, K\",12,4500\n" + // name with comma -> 6 fields
            "P9,192311009,Indu,12,4500\n", StandardOpenOption.APPEND);
        show("find P6 (amount=abc)", s.find("P6"));
        show("find P7 (6 fields)", s.find("P7"));
        show("find P8 (comma in name)", s.find("P8"));
        show("find P9 (valid, after damage)", s.find("P9"));
        List<String[]> r = s.listByRoute(12);
        System.out.print("list route 12 IDs: ");
        for (String[] x : r) System.out.print(x[0] + " ");
        System.out.println();
        Files.delete(f);
    }
}
