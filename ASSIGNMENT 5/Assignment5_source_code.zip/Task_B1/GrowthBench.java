import java.nio.file.*;
import java.util.*;
import java.io.*;

public class GrowthBench {
    static Path build(int n) throws IOException {
        Path p = Paths.get("passes_" + n + ".csv");
        try (BufferedWriter w = Files.newBufferedWriter(p)) {
            for (int i = 1; i <= n; i++)
                w.write(String.format("P%07d,19231%05d,Student%d,%d,%d.0%n", i, i % 100000, i, 1 + i % 30, 3000 + i % 2000));
        } return p;
    }
    static long used() { System.gc(); System.gc(); Runtime r = Runtime.getRuntime(); return r.totalMemory() - r.freeMemory(); }
    public static void main(String[] a) throws Exception {
        PassStore warm = new PassStore(build(1000));
        for (int i = 0; i < 200; i++) warm.find("P0001000");
        System.out.println("A) single find() latency (file scan), median of 15 runs, ms");
        System.out.printf("%-9s %-14s %-14s%n", "n", "last record", "missing ID");
        int[] sizes = {1000, 5000, 10000, 25000, 50000, 100000};
        for (int n : sizes) {
            PassStore s = new PassStore(build(n));
            double[] last = new double[15], miss = new double[15];
            for (int k = 0; k < 15; k++) {
                long t = System.nanoTime(); s.find(String.format("P%07d", n)); last[k] = (System.nanoTime() - t) / 1e6;
                t = System.nanoTime(); s.find("P9999999"); miss[k] = (System.nanoTime() - t) / 1e6;
            }
            Arrays.sort(last); Arrays.sort(miss);
            System.out.printf("%-9d %-14.2f %-14.2f%n", n, last[7], miss[7]);
        }
        System.out.println("\nB) q=100 searches, n=100000: scan every time vs HashMap loaded once");
        int n = 100000; PassStore s = new PassStore(Paths.get("passes_100000.csv")); int q = 100;
        Random rnd = new Random(42); String[] ids = new String[q];
        for (int i = 0; i < q; i++) ids[i] = String.format("P%07d", 1 + rnd.nextInt(n));
        long t0 = System.nanoTime(); for (String id : ids) if (s.find(id) == null) throw new Error();
        double scan = (System.nanoTime() - t0) / 1e6;
        long m0 = used();
        t0 = System.nanoTime();
        Map<String, String[]> map = new HashMap<>();
        try (BufferedReader r = Files.newBufferedReader(Paths.get("passes_100000.csv"))) {
            String l; while ((l = r.readLine()) != null) { String[] f = l.split(",", -1); if (f.length == 5) map.put(f[0], f); }
        }
        double load = (System.nanoTime() - t0) / 1e6;
        long m1 = used();
        t0 = System.nanoTime(); for (String id : ids) if (map.get(id) == null) throw new Error();
        double look = (System.nanoTime() - t0) / 1e6;
        System.out.printf("scan x %d searches        : %.1f ms%n", q, scan);
        System.out.printf("HashMap load (n=%d)    : %.1f ms%n", n, load);
        System.out.printf("HashMap %d lookups      : %.3f ms%n", q, look);
        System.out.printf("HashMap total            : %.1f ms%n", load + look);
        System.out.printf("HashMap heap used (approx): %.1f MB  (file size %.1f MB)%n", (m1 - m0) / 1048576.0, Files.size(Paths.get("passes_100000.csv")) / 1048576.0);
        System.out.println("map size = " + map.size());
        for (int x : sizes) Files.deleteIfExists(Paths.get("passes_" + x + ".csv"));
    }
}
