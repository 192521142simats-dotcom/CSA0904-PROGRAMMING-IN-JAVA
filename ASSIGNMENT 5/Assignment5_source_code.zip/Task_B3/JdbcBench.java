import java.sql.*;
import java.util.*;

public class JdbcBench {
    static List<String[]> gen(int n) {
        List<String[]> l = new ArrayList<>();
        for (int i = 1; i <= n; i++) l.add(new String[]{String.format("P%07d", i), "19231" + (10000 + i % 90000), "Student" + i, "" + (1 + i % 30), "" + (3000 + i % 2000)});
        return l;
    }
    static void clear(Connection c) throws SQLException { try (Statement s = c.createStatement()) { s.execute("TRUNCATE TABLE bus_pass"); } }

    static long stmt(Connection c, List<String[]> d) throws SQLException {
        long t = System.nanoTime();
        try (Statement s = c.createStatement()) {
            for (String[] p : d) s.executeUpdate("INSERT INTO bus_pass VALUES ('" + p[0] + "','" + p[1] + "','" + p[2] + "'," + p[3] + "," + p[4] + ")");
        } return (System.nanoTime() - t) / 1_000_000;
    }
    static long prep(Connection c, List<String[]> d) throws SQLException {
        long t = System.nanoTime();
        try (PreparedStatement ps = c.prepareStatement("INSERT INTO bus_pass VALUES (?,?,?,?,?)")) {
            for (String[] p : d) { ps.setString(1, p[0]); ps.setString(2, p[1]); ps.setString(3, p[2]); ps.setInt(4, Integer.parseInt(p[3])); ps.setDouble(5, Double.parseDouble(p[4])); ps.executeUpdate(); }
        } return (System.nanoTime() - t) / 1_000_000;
    }
    static long batch(Connection c, List<String[]> d) throws SQLException {
        long t = System.nanoTime();
        PassLoader.loadAll(c, d);                      // batch + single transaction
        return (System.nanoTime() - t) / 1_000_000;
    }
    static long batchAutoCommit(Connection c, List<String[]> d) throws SQLException {
        long t = System.nanoTime(); c.setAutoCommit(true);
        try (PreparedStatement ps = c.prepareStatement("INSERT INTO bus_pass VALUES (?,?,?,?,?)")) {
            int n = 0;
            for (String[] p : d) { ps.setString(1, p[0]); ps.setString(2, p[1]); ps.setString(3, p[2]); ps.setInt(4, Integer.parseInt(p[3])); ps.setDouble(5, Double.parseDouble(p[4])); ps.addBatch(); if (++n % 1000 == 0) ps.executeBatch(); }
            ps.executeBatch();
        } return (System.nanoTime() - t) / 1_000_000;
    }
    public static void main(String[] a) throws Exception {
        // rewriteBatchedStatements=true makes MySQL Connector/J send real multi-row inserts
        String url = "jdbc:mysql://localhost:3306/transport_test?rewriteBatchedStatements=true";
        try (Connection c = DriverManager.getConnection(url, "root", "<your-password>")) {
            System.out.printf("%-8s %-12s %-12s %-12s %-14s%n", "rows", "Statement", "Prepared", "Batch+txn", "Batch autocommit");
            for (int n : new int[]{1000, 10000, 100000}) {
                List<String[]> d = gen(n);
                clear(c); long t1 = stmt(c, d);
                clear(c); long t2 = prep(c, d);
                clear(c); long t3 = batch(c, d);
                clear(c); long t4 = batchAutoCommit(c, d);
                System.out.printf("%-8d %-12d %-12d %-12d %-14d%n", n, t1, t2, t3, t4);
            }
            // B3.3 failure half-way
            List<String[]> d = gen(2000); d.get(1000)[4] = "abc";        // invalid amount
            clear(c);
            try { PassLoader.loadAll(c, d); } catch (RuntimeException | SQLException e) { System.out.println("txn failed: " + e); }
            System.out.println("rows after failed TRANSACTION   = " + count(c));   // expect 0
            clear(c);
            try { batchAutoCommit(c, d); } catch (RuntimeException | SQLException e) { System.out.println("auto-commit failed: " + e); }
            System.out.println("rows after failed AUTO-COMMIT   = " + count(c));   // expect 1000
        }
    }
    static int count(Connection c) throws SQLException { try (Statement s = c.createStatement(); ResultSet r = s.executeQuery("SELECT COUNT(*) FROM bus_pass")) { r.next(); return r.getInt(1); } }
}
