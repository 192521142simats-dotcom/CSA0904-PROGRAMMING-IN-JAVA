import sqlite3, time, os
def db():
    if os.path.exists("t.db"): os.remove("t.db")
    c = sqlite3.connect("t.db", isolation_level=None)   # isolation_level=None -> explicit control (autocommit)
    c.execute("CREATE TABLE bus_pass(pass_id TEXT PRIMARY KEY, reg_no TEXT, name TEXT, route_no INT, amount REAL CHECK(amount>=0))")
    c.execute("CREATE TABLE users(id TEXT PRIMARY KEY, pwd TEXT)")
    c.executemany("INSERT INTO users VALUES(?,?)", [("admin","Secret@123"),("arun","pass1")])
    return c
def gen(n): return [(f"P{i:07d}", f"19231{10000+i%90000}", f"Student{i}", 1+i%30, 3000.0+i%2000) for i in range(1,n+1)]

print("== B2: injection (SQLite stand-in for MySQL) ==")
c = db()
def unsafe(i,p): return c.execute("SELECT * FROM users WHERE id='"+i+"' AND pwd='"+p+"'").fetchone() is not None
def safe(i,p):   return c.execute("SELECT 1 FROM users WHERE id=? AND pwd=?", (i,p)).fetchone() is not None
for label,i,p in [("admin / wrong","admin","wrong"),("admin / ' OR '1'='1","admin","' OR '1'='1"),("admin' --  / x","admin' -- ","x"),("admin / Secret@123","admin","Secret@123")]:
    print(f"{label:24s} unsafe={unsafe(i,p)!s:6s} safe={safe(i,p)}")
print("built SQL:", "SELECT * FROM users WHERE id='admin' AND pwd='' OR '1'='1'")

print("\n== B3.2 insert time (ms), SQLite on local disk ==")
print(f"{'rows':8s}{'Statement':>12s}{'Prepared':>12s}{'Batch+txn':>12s}{'Batch autocommit':>18s}")
for n in (1000,10000,100000):
    d = gen(n); r = []
    # (a) Statement-like: build SQL string per row, autocommit
    c = db(); t=time.perf_counter()
    for p in d: c.execute(f"INSERT INTO bus_pass VALUES('{p[0]}','{p[1]}','{p[2]}',{p[3]},{p[4]})")
    r.append((time.perf_counter()-t)*1000)
    # (b) Prepared: parameterised, one execute per row, autocommit
    c = db(); t=time.perf_counter()
    for p in d: c.execute("INSERT INTO bus_pass VALUES(?,?,?,?,?)", p)
    r.append((time.perf_counter()-t)*1000)
    # (c) batch (executemany) in ONE transaction
    c = db(); t=time.perf_counter(); c.execute("BEGIN")
    for k in range(0,n,1000): c.executemany("INSERT INTO bus_pass VALUES(?,?,?,?,?)", d[k:k+1000])
    c.execute("COMMIT"); r.append((time.perf_counter()-t)*1000)
    # (d) batch with autocommit on (each batch its own commit; per-row autocommit to mirror JDBC autocommit)
    c = db(); t=time.perf_counter()
    for p in d: c.execute("INSERT INTO bus_pass VALUES(?,?,?,?,?)", p)
    r.append((time.perf_counter()-t)*1000)
    print(f"{n:<8d}{r[0]:12.0f}{r[1]:12.0f}{r[2]:12.0f}{r[3]:18.0f}")

print("\n== B3.3 failure half-way (invalid amount -5 at row 1001 of 2000; CHECK amount>=0) ==")
d = gen(2000); d[1000] = d[1000][:4]+(-5.0,)
c = db()
try:
    c.execute("BEGIN")
    for k in range(0,2000,1000): c.executemany("INSERT INTO bus_pass VALUES(?,?,?,?,?)", d[k:k+1000])
    c.execute("COMMIT")
except Exception as e:
    c.execute("ROLLBACK"); print("transaction failed:", type(e).__name__, "->", e)
print("rows after failed TRANSACTION  =", c.execute("SELECT COUNT(*) FROM bus_pass").fetchone()[0])
c = db()
try:
    for p in d: c.execute("INSERT INTO bus_pass VALUES(?,?,?,?,?)", p)       # autocommit
except Exception as e: print("auto-commit failed:", type(e).__name__, "->", e)
print("rows after failed AUTO-COMMIT  =", c.execute("SELECT COUNT(*) FROM bus_pass").fetchone()[0])

print("\n== A5 wallet transfer: failure between the two updates ==")
c = db(); c.execute("CREATE TABLE w(name TEXT PRIMARY KEY, bal INT)"); c.executemany("INSERT INTO w VALUES(?,?)",[("hostel",2000),("canteen",300)])
def transfer(txn, crash):
    if txn: c.execute("BEGIN")
    try:
        c.execute("UPDATE w SET bal=bal-500 WHERE name='hostel'")
        if crash: raise RuntimeError("power failure")
        c.execute("UPDATE w SET bal=bal+500 WHERE name='canteen'")
        if txn: c.execute("COMMIT")
    except RuntimeError:
        if txn: c.execute("ROLLBACK")
for txn in (False, True):
    c.execute("UPDATE w SET bal=2000 WHERE name='hostel'"); c.execute("UPDATE w SET bal=300 WHERE name='canteen'")
    transfer(txn, True)
    print("transaction" if txn else "two auto-commit statements", "->", c.execute("SELECT name,bal FROM w ORDER BY name").fetchall(), "total =", c.execute("SELECT SUM(bal) FROM w").fetchone()[0])
