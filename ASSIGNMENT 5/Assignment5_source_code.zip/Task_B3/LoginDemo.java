import java.sql.*;

public class LoginDemo {
    static boolean unsafe(Connection c, String id, String pwd) throws SQLException {
        String sql = "SELECT * FROM users WHERE id='" + id + "' AND pwd='" + pwd + "'";
        try (Statement st = c.createStatement(); ResultSet rs = st.executeQuery(sql)) { return rs.next(); }
    }
    static boolean safe(Connection c, String id, String pwd) throws SQLException {
        String sql = "SELECT 1 FROM users WHERE id=? AND pwd=?";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, id); ps.setString(2, pwd);
            try (ResultSet rs = ps.executeQuery()) { return rs.next(); }
        }
    }
    public static void main(String[] a) throws Exception {
        try (Connection c = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/transport_test", "root", "<your-password>")) {
            String evil = "' OR '1'='1";
            System.out.println("unsafe(admin, wrong)     = " + unsafe(c, "admin", "wrong"));
            System.out.println("unsafe(admin, evil)      = " + unsafe(c, "admin", evil));
            System.out.println("unsafe(admin' -- , x)    = " + unsafe(c, "admin' -- ", "x"));
            System.out.println("safe(admin, wrong)       = " + safe(c, "admin", "wrong"));
            System.out.println("safe(admin, evil)        = " + safe(c, "admin", evil));
            System.out.println("safe(admin, Secret@123)  = " + safe(c, "admin", "Secret@123"));
        }
    }
}
