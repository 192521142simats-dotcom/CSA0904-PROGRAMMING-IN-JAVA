import java.sql.*;
/** B3.1: print table contents with ResultSetMetaData */
public class MetaCheck {
    public static void main(String[] a) throws Exception {
        try (Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/transport_test", "root", "<your-password>");
             Statement s = c.createStatement(); ResultSet rs = s.executeQuery("SELECT * FROM bus_pass LIMIT 10")) {
            ResultSetMetaData md = rs.getMetaData();
            for (int i = 1; i <= md.getColumnCount(); i++) System.out.printf("%-10s %-10s%n", md.getColumnName(i), md.getColumnTypeName(i));
            while (rs.next()) { for (int i = 1; i <= md.getColumnCount(); i++) System.out.print(rs.getString(i) + "  "); System.out.println(); }
        }
    }
}
