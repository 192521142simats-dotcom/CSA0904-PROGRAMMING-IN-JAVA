import java.io.*;
import java.nio.file.*;
import java.sql.*;
import java.util.*;

/** B4.1 + B4.2: migrate passes.csv -> MySQL in batches inside one transaction; report rejects. */
public class Migrate {
    public static void main(String[] a) throws Exception {
        Path in = Paths.get(a.length > 0 ? a[0] : "passes.csv");
        List<String[]> good = new ArrayList<>(); List<String> rejected = new ArrayList<>();
        try (BufferedReader r = Files.newBufferedReader(in)) {
            String line; int ln = 0;
            while ((line = r.readLine()) != null) {
                ln++; String[] f = line.split(",", -1);
                String why = null;
                if (line.isBlank()) why = "empty line";
                else if (f.length != 5) why = "expected 5 fields, found " + f.length;
                else try { Integer.parseInt(f[3].trim()); if (Double.parseDouble(f[4]) < 0) why = "negative amount"; }
                     catch (NumberFormatException e) { why = "non-numeric route/amount"; }
                if (why == null) good.add(f); else rejected.add("line " + ln + ": " + why + "  -> " + line);
            }
        }
        try (Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/transport_test?rewriteBatchedStatements=true", "root", "<your-password>")) {
            int n = PassLoader.loadAll(c, good);
            System.out.println("Loaded " + n + " rows; rejected " + rejected.size());
            rejected.forEach(System.out::println);
            DatabaseMetaData m = c.getMetaData();                       // B4.2
            System.out.println("Product : " + m.getDatabaseProductName() + " " + m.getDatabaseProductVersion());
            System.out.println("Driver  : " + m.getDriverName() + " " + m.getDriverVersion());
            System.out.println("JDBC URL: " + m.getURL());
            try (ResultSet t = m.getTables("transport_test", null, "%", new String[]{"TABLE"})) {
                while (t.next()) System.out.println("Table   : " + t.getString("TABLE_NAME"));
            }
        }
    }
}
