CREATE DATABASE IF NOT EXISTS transport_test;
USE transport_test;
DROP TABLE IF EXISTS bus_pass;
CREATE TABLE bus_pass (
  pass_id  VARCHAR(10)   PRIMARY KEY,
  reg_no   VARCHAR(12)   NOT NULL,
  name     VARCHAR(60)   NOT NULL,
  route_no INT           NOT NULL,
  amount   DECIMAL(8,2)  NOT NULL CHECK (amount >= 0)
);
DROP TABLE IF EXISTS users;
CREATE TABLE users (id VARCHAR(20) PRIMARY KEY, pwd VARCHAR(40) NOT NULL);
INSERT INTO users VALUES ('admin','Secret@123'),('arun','pass1');
