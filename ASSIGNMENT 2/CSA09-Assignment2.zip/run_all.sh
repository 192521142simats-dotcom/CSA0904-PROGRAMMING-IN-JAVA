#!/usr/bin/env bash
# Compile and run every program of Assignment 2; outputs are written next to the sources.
set -e
unset JAVA_TOOL_OPTIONS
cd "$(dirname "$0")"

(cd Q1 && javac *.java && java -Xms512m -Xmx512m TicketBench > ticketbench_output.txt && java AllocBench > allocbench_output.txt && java BookingLog > bookinglog_output.txt)
(cd Q2 && javac ListBench.java && java -Xms1g -Xmx2g ListBench > listbench_output.txt)
(cd Q3/before && javac Attendance.java && java Attendance)
(cd Q3/after  && javac Attendance.java && java Attendance)
(cd Q3 && javac *.java && java ContractExperiments > contract_output.txt && java -Xms1g -Xmx3g DedupBench > dedup_output.txt)
(cd Q4 && javac PharmacyBench.java && java -Xms1g -Xmx3g PharmacyBench > pharmacy_output.txt)
(cd Q5 && javac *.java && java LeaderboardDemo > leaderboard_output.txt && java RankingExperiments > ranking_experiments_output.txt)
(cd Q6 && javac *.java && java Triage > triage_output.txt && java -Xms1g -Xmx3g TriageExperiments > triage_experiments_output.txt)
(cd Q7 && javac AgingRedesign.java && java -Xms1g -Xmx3g AgingRedesign > aging_output.txt)
echo "All tasks executed. See the *_output.txt files."
