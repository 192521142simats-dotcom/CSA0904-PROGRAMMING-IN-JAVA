import java.util.*;

/** Q3 alternative concepts: HashSet<Student> vs TreeSet<Student>(Comparator on regNo) vs HashMap<String,Student>. */
public class DedupBench {
    static class Student {
        final String regNo, name;
        Student(String r, String n) { regNo = r; name = n; }
        @Override public boolean equals(Object o) { return o instanceof Student && regNo.equals(((Student) o).regNo); }
        @Override public int hashCode() { return regNo.hashCode(); }
    }
    static long sink;

    static long heap() { System.gc(); System.gc(); Runtime r = Runtime.getRuntime(); return r.totalMemory() - r.freeMemory(); }

    public static void main(String[] args) {
        System.out.println("n_unique,scans,structure,final_size,ns_per_scan(median of 5),approx_heap_MB");
        for (int n : new int[]{10_000, 100_000, 1_000_000}) {
            // scans: every student scanned 3 times, shuffled
            List<Student> scans = new ArrayList<>(3 * n);
            for (int rep = 0; rep < 3; rep++)
                for (int i = 0; i < n; i++) scans.add(new Student(String.valueOf(192_000_000 + i), "S" + i));
            Collections.shuffle(scans, new Random(1));
            int m = scans.size();

            for (String kind : new String[]{"HashSet", "TreeSet(Comparator)", "HashMap<String,Student>"}) {
                double[] t = new double[5]; int size = 0; long mem = 0;
                for (int rep = 0; rep < 5; rep++) {
                    long h0 = heap();
                    Object ds;
                    long s = System.nanoTime();
                    if (kind.equals("HashSet")) {
                        Set<Student> x = new HashSet<>(); for (Student st : scans) x.add(st); size = x.size(); ds = x;
                    } else if (kind.startsWith("TreeSet")) {
                        Set<Student> x = new TreeSet<>(Comparator.comparing((Student st) -> st.regNo)); for (Student st : scans) x.add(st); size = x.size(); ds = x;
                    } else {
                        Map<String, Student> x = new HashMap<>(); for (Student st : scans) x.putIfAbsent(st.regNo, st); size = x.size(); ds = x;
                    }
                    t[rep] = (System.nanoTime() - s) / (double) m;
                    if (rep == 4) mem = heap() - h0;
                    sink += size + ds.hashCode() % 2;
                }
                Arrays.sort(t);
                System.out.printf("%d,%d,%s,%d,%.1f,%.1f%n", n, m, kind, size, t[2], mem / 1048576.0);
            }
        }
        System.out.println("sink=" + sink);
    }
}
