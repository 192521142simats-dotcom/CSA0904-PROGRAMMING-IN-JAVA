import java.util.*;

/** Q3 - three designed tests on the equals/hashCode contract (each preceded by a stated prediction). */
public class ContractExperiments {

    // equals() only (the junior developer's class)
    static class BadStudent {
        final String regNo, name;
        BadStudent(String r, String n) { regNo = r; name = n; }
        @Override public boolean equals(Object o) {
            return o instanceof BadStudent && regNo.equals(((BadStudent) o).regNo);
        }
        @Override public String toString() { return regNo + " " + name; }
    }

    // equals() + consistent hashCode()
    static class GoodStudent {
        final String regNo, name;
        GoodStudent(String r, String n) { regNo = r; name = n; }
        @Override public boolean equals(Object o) {
            return o instanceof GoodStudent && regNo.equals(((GoodStudent) o).regNo);
        }
        @Override public int hashCode() { return regNo.hashCode(); }
        @Override public String toString() { return regNo + " " + name; }
    }

    // mutable key: hashCode depends on a field that can change
    static class MutableStudent {
        String regNo; final String name;
        MutableStudent(String r, String n) { regNo = r; name = n; }
        @Override public boolean equals(Object o) {
            return o instanceof MutableStudent && regNo.equals(((MutableStudent) o).regNo);
        }
        @Override public int hashCode() { return regNo.hashCode(); }
    }

    // compareTo inconsistent with equals: compareTo uses name, equals uses regNo
    static class NameOrdered implements Comparable<NameOrdered> {
        final String regNo, name;
        NameOrdered(String r, String n) { regNo = r; name = n; }
        @Override public boolean equals(Object o) {
            return o instanceof NameOrdered && regNo.equals(((NameOrdered) o).regNo);
        }
        @Override public int hashCode() { return regNo.hashCode(); }
        @Override public int compareTo(NameOrdered o) { return name.compareTo(o.name); }
    }

    static void report(String test, String prediction, int actual) {
        System.out.println(test + "\n   prediction : " + prediction + "\n   observed   : size = " + actual + "\n");
    }

    public static void main(String[] args) {
        // Test 1: HashSet "appears" to work - all scans are distinct students (no duplicates to remove)
        Set<BadStudent> t1 = new HashSet<>();
        t1.add(new BadStudent("101", "A")); t1.add(new BadStudent("102", "B")); t1.add(new BadStudent("103", "C"));
        report("Test 1a: BadStudent, 3 DIFFERENT students", "3 (nothing to de-duplicate)", t1.size());

        // Test 1b: same OBJECT scanned twice -> identical identity hash, equals true via ==/regNo
        Set<BadStudent> t1b = new HashSet<>();
        BadStudent same = new BadStudent("101", "A");
        t1b.add(same); t1b.add(same); t1b.add(new BadStudent("102", "B"));
        report("Test 1b: BadStudent, the SAME object added twice", "2 (same object => same identity hashCode)", t1b.size());

        // Test 2: designed to expose duplicates: equal-by-regNo but separate objects
        Set<BadStudent> t2 = new HashSet<>();
        for (int gate = 1; gate <= 3; gate++) t2.add(new BadStudent("101", "Arun"));
        t2.add(new BadStudent("102", "Divya"));
        report("Test 2: BadStudent, Arun scanned at 3 gates (new object each scan) + Divya",
               "4 (each new object gets a different identity hash -> different bucket -> equals never called). Correct answer would be 2",
               t2.size());
        System.out.println("   contains(new BadStudent(\"102\",\"Divya\")) = " + t2.contains(new BadStudent("102", "Divya")) + "  (should be true)\n");

        // Test 2 repeated with the corrected class
        Set<GoodStudent> t2g = new HashSet<>();
        for (int gate = 1; gate <= 3; gate++) t2g.add(new GoodStudent("101", "Arun"));
        t2g.add(new GoodStudent("102", "Divya"));
        report("Test 2 (fixed): GoodStudent, same scans", "2", t2g.size());
        System.out.println("   contains(new GoodStudent(\"102\",\"Divya\")) = " + t2g.contains(new GoodStudent("102", "Divya")) + "\n");

        // Test 3a: mutate a field used in hashCode after insertion
        Set<MutableStudent> t3 = new HashSet<>();
        MutableStudent m = new MutableStudent("101", "Arun");
        t3.add(m);
        m.regNo = "999";   // hash changes, but the entry stays in the old bucket
        System.out.println("Test 3a: mutate regNo after insertion");
        System.out.println("   prediction : size stays 1, but contains(m) = false and remove(m) fails (looked up in the wrong bucket)");
        System.out.println("   observed   : size = " + t3.size() + ", contains(m) = " + t3.contains(m)
            + ", remove(m) = " + t3.remove(m) + ", size after remove = " + t3.size()
            + ", iteration still sees it: " + t3.iterator().hasNext());
        t3.add(m);
        System.out.println("   adding m again -> size = " + t3.size() + "  (the same object is now stored TWICE)\n");

        // Test 3b: TreeSet whose compareTo is inconsistent with equals
        Set<NameOrdered> tree = new TreeSet<>();
        tree.add(new NameOrdered("101", "Arun"));
        tree.add(new NameOrdered("205", "Arun"));    // different student, same name
        Set<NameOrdered> hash = new HashSet<>();
        hash.add(new NameOrdered("101", "Arun"));
        hash.add(new NameOrdered("205", "Arun"));
        System.out.println("Test 3b: two different students (regNo 101 and 205) with the same name 'Arun'");
        System.out.println("   prediction : TreeSet = 1 (compareTo==0 treated as duplicate), HashSet = 2 (equals says different)");
        System.out.println("   observed   : TreeSet size = " + tree.size() + ", HashSet size = " + hash.size());
    }
}
