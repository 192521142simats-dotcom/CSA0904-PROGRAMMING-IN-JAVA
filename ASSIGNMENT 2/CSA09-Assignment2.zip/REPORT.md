---
title: "Programming in Java (CSA09) – Assignment 2 (CO2)"
subtitle: "Report with evidence for Q1–Q7"
---

**Name:** ______________________  **Register No.:** ______________________

**GitHub repository:** https://github.com/______________/CSA09-<RegisterNumber>-Assignment2

**Environment:** OpenJDK 21.0.12.1, Linux, single JVM. Every timing is the median (or mean, where stated) of repeated runs after a warm-up. Raw outputs are in the `*_output.txt` file of each task folder. Absolute times depend on the machine; the *growth trends and ratios* are the evidence.

---

# Q1 – String, StringBuilder or StringBuffer? (6)

## Prediction (before implementation)

`String` is immutable. In `s = s + field` every iteration allocates a new String and copies *all* characters built so far, so the characters copied are L(1+2+…+n) = L·n(n+1)/2 = **O(n²)** for n fields of L characters. `StringBuilder` keeps a growable `char/byte` buffer and copies each character about once (plus amortised doubling), so **O(n)**. `StringBuffer` is the same algorithm with every method `synchronized`.

Prediction: for a short ticket all three are equally fast in practice; the gap opens as fields per ticket grow; `StringBuilder` and `StringBuffer` stay close to each other when there is no contention.

## Workloads and results

| Workload | Description |
|---|---|
| W1 | one short ticket (10 fields) – contrasting case 1 |
| W2 | 10,000 tickets × 50 fields – contrasting case 2 |
| W3 (my own) | 20 tickets × 2,000 fields – very long tickets |

Time (ms). W1 is per single ticket; W2 and W3 are for the whole batch. Source: `Q1/ticketbench_output.txt`.

| Method | W1 (per ticket) | W2 (10,000 × 50) | W3 (20 × 2,000) |
|---|---|---|---|
| String `+` in loop | 0.00020 | 25.65 | 101.29 |
| StringBuilder | 0.00010 | 6.17 | 0.596 |
| StringBuffer | 0.00008 | 5.80 | 0.544 |
| String.join | 0.00006 | 2.33 | 0.249 |
| StringJoiner | 0.00009 | 4.13 | 0.590 |

Bytes actually allocated per ticket, including garbage (per-thread allocation counter, `Q1/AllocBench.java`):

| Fields n | String `+` | StringBuilder | String.join | `+` ÷ StringBuilder |
|---|---|---|---|---|
| 10 | 1,168 | 544 | 240 | 2.1× |
| 50 | 21,648 | 3,248 | 1,040 | 6.7× |
| 200 | 336,448 | 12,768 | 4,240 | 26.4× |
| 2,000 | 36,674,048 | 185,472 | 45,840 | 197.7× |

Estimated intermediate String objects per ticket: `+` creates about n (one new String per iteration, each copying everything built so far); StringBuilder/StringBuffer create 1 (the final `toString()`).

Model of characters copied (L = 14 characters per field): n = 10 → 770 vs 280; n = 50 → 17,850 vs 1,400; n = 200 → 281,400 vs 5,600; n = 2,000 → 28,014,000 vs 56,000.

*Note:* I also tried measuring heap-before/after with `Runtime.totalMemory()-freeMemory()`. It mostly measures the retained result, not the garbage, so I do not use it as evidence; the allocated-bytes table above is the reliable memory measure.

## Predicted vs observed

* Short ticket: the difference is ~100 ns per ticket – negligible, as predicted.
* Growth: `+` becomes 4× slower than StringBuilder at 50 fields and **~170× slower at 2,000 fields**; allocated bytes grow 2.1× → 197.7×, matching the O(n²) vs O(n) model (the ratio itself grows roughly linearly with n).
* StringBuilder vs StringBuffer: within noise (5.80 vs 6.17 ms; the order even flips between workloads) – uncontended synchronisation is cheap because of JIT lock optimisations.
* Not predicted: `String.join` was the fastest (it computes the total length first and allocates once).

## Design decision (multithreaded server)

I ran 8 threads × 20,000 appends of one character into a shared object (`Q1/BookingLog.java`):

| Round | Expected | StringBuilder | StringBuffer |
|---|---|---|---|
| 1 | 160,000 | 159,888 | 160,000 |
| 2 | 160,000 | 159,988 | 160,000 |
| 3 | 160,000 | 159,656 | 160,000 |

* **Per-ticket text → `StringBuilder`.** A ticket is built by one thread in a local variable, so nothing is shared and synchronisation would be pure overhead.
* **Shared booking log → `StringBuffer`** (the measured data loss of StringBuilder proves it is unsafe). Refinement: `StringBuffer` is thread-safe *per call* only, so a log line made of several `append` calls can interleave with another thread's line. Build each line in a local StringBuilder and append it with **one** call; in a real server I would prefer a logging framework or a `ConcurrentLinkedQueue<String>` drained by a single writer.

## Alternative concept and complexity

* `String.join("", fields)` – one pass to sum lengths, one allocation, one copy: **O(total length) time, O(total length) space, no intermediate Strings**. `StringJoiner` – same complexity, collects pieces then builds. `String.format` – each call parses its format string and boxes arguments; same O(n) copy cost but a larger constant (not benchmarked here).
* Repeated `+`: time O(n²) characters copied, extra garbage O(n²) characters (measured 36.7 MB for one 2,000-field ticket). StringBuilder: time O(n) amortised, extra space O(n) (capacity doubling leaves up to 2× slack, and one final copy in `toString()`).

---

# Q2 – When is ArrayList an appropriate choice? (4)

## Experiment design

`Q2/ListBench.java`. Sizes: **10,000 / 100,000 / 500,000**. Each operation is run on a freshly built list (setup not timed); median of 5 runs. Front/middle/get operations use a fixed 2,000 operations at each size so growth with size is visible. Times in ms (source `Q2/listbench_output.txt`).

| Operation | n | ArrayList | LinkedList | ArrayDeque | Plain array (manual shift) |
|---|---|---|---|---|---|
| add at end (n adds) | 10k | 0.508 | 0.507 | 0.687 | 0.108 |
| | 100k | 1.775 | 1.628 | 0.995 | 0.177 |
| | 500k | 9.776 | 9.416 | 9.756 | 0.138 |
| insert front (2,000) | 10k | 1.100 | 0.248 | 0.065 | 3.121 |
| | 100k | 14.747 | 0.048 | 0.039 | 24.406 |
| | 500k | 81.208 | 0.084 | 0.061 | 144.970 |
| remove front (2,000) | 10k | 0.746 | 0.126 | 0.048 | 2.567 |
| | 100k | 14.528 | 0.056 | 0.040 | 24.332 |
| | 500k | 81.428 | 0.051 | 0.033 | 123.351 |
| insert middle (2,000) | 10k | 0.351 | 14.831 | n/a | 1.101 |
| | 100k | 7.445 | 147.024 | n/a | 11.434 |
| | 500k | 36.362 | 1,230.588 | n/a | 55.805 |
| remove middle (2,000) | 10k | 0.255 | 11.683 | n/a | – |
| | 100k | 7.104 | 140.151 | n/a | – |
| | 500k | 37.225 | 852.270 | n/a | – |
| get k-th (2,000) | 10k | 0.071 | 8.171 | n/a | 0.024 |
| | 100k | 0.109 | 80.469 | n/a | 0.025 |
| | 500k | 0.335 | 669.812 | n/a | 0.027 |
| iterate all | 10k | 0.335 | 0.419 | 0.311 | 0.103 |
| | 100k | 0.705 | 0.886 | 0.597 | 0.209 |
| | 500k | 0.909 | 2.519 | 0.818 | 0.853 |

Observations: the 10k rows are small enough to be affected by JIT warm-up, so I rely on the trend across sizes. The plain array's "add at end" is fast because it is pre-sized (no growth); the manual array has the same shifting cost as ArrayList but a larger constant here because it is un-optimised user code around `System.arraycopy`.

Interesting result: **ArrayList beats LinkedList by roughly 20–40× for insertion in the middle even though both are O(n)** (0.351 vs 14.8 ms at 10k, 7.4 vs 147 ms at 100k, 36 vs 1,231 ms at 500k). LinkedList must walk n/2 nodes (pointer chasing, cache misses) while ArrayList does one contiguous `memmove`.

## Operating boundary

* **ArrayList is a reasonable choice** when the playlist is read far more often than it is edited at the front/middle: adding at the end is O(1) amortised, `get(k)` is O(1) (0.335 ms for 2,000 jumps even at 500k songs), and iteration is faster than LinkedList (0.909 vs 2.519 ms at 500k). Typical playlists are ≤ ~10,000 songs: at that size 2,000 front inserts cost 1.1 ms, i.e. **~0.5 µs per insert** – invisible to a user.
* **I would stop recommending it** when front/middle insert-or-remove is frequent *and* the list is large: the cost per front insert is ≈ 0.55 µs at 10k, 7 µs at 100k, 40 µs at 500k (linear in n). Concretely, when (edits per second × n) pushes the per-edit cost above the latency budget (say a few ms per edit for an interactive UI), or the list reaches the hundreds of thousands.
* `LinkedList` is **not** the answer for a playlist: random access (`get(k)`) is 670 ms vs 0.335 ms at 500k, and middle edits are slower than ArrayList's.

## Changed condition – "Up Next" queue (add at both ends, remove from front)

100,000 mixed operations (⅓ addFirst, ⅓ addLast, ⅓ removeFirst), time in ms:

| Queue size | ArrayList | LinkedList | ArrayDeque |
|---|---|---|---|
| 10,000 | 88.466 | 1.051 | 0.807 |
| 100,000 | 544.587 | 0.708 | 0.762 |
| 500,000 | 2,744.444 | 0.641 | 0.576 |

ArrayList degrades linearly with queue size (every front operation shifts the array); LinkedList and ArrayDeque are flat. **Revised recommendation: ArrayDeque for "Up Next"**, ArrayList for the playlist. ArrayDeque is as fast as LinkedList for end operations, needs no per-element node object, and iterates faster; its limitation is that it has no index access or middle insertion, which an "Up Next" queue does not need.

## Alternative concept and complexity

| Operation | ArrayList | LinkedList | ArrayDeque | Plain array, manual shifting |
|---|---|---|---|---|
| add at end | O(1) amortised | O(1) | O(1) amortised | O(1) if spare capacity, else O(n) to reallocate and copy |
| insert at front | O(n) | O(1) | O(1) amortised | O(n) |
| insert in middle | O(n) shift | O(n) traverse + O(1) link | not supported | O(n) |
| get k-th | O(1) | O(n) | not supported | O(1) |
| iterate | O(n) | O(n) (poorer cache locality) | O(n) | O(n) |
| space per element* | one reference slot (+ up to ~50 % spare capacity) | one node (item + next + prev + header) – roughly 5–6× a slot | one slot (+ spare capacity) | one slot, fixed size |

\*Typical HotSpot figures with compressed references (4-byte reference, 24-byte LinkedList node); *not measured here*. Elements themselves (e.g. `Song` objects) cost the same in every structure.

A plain array with manual shifting gives exactly ArrayList's complexities (it *is* what ArrayList does internally) but adds manual capacity management, no bounds/ concurrent-modification checks and more code to get wrong; measured, it is no faster than ArrayList for front/middle edits (81 vs 145 ms at 500k).

---

# Q3 – Engineer the hashCode–equals contract (6)

Code: `Q3/ContractExperiments.java`, `Q3/before/Attendance.java`, `Q3/after/Attendance.java`, `Q3/DedupBench.java`. Predictions are written inside the program *before* each test's result is printed.

## Tests, predictions, observations

| # | Test | Predicted size | Observed |
|---|---|---|---|
| 1a | 3 different students, `equals` only | 3 – nothing to de-duplicate | 3 |
| 1b | the *same object* added twice + one more | 2 – same object has the same identity hash | 2 |
| 2 | Arun scanned at 3 gates (3 separate objects) + Divya | 4 – each object gets a different identity hash → different bucket → `equals` never called; the correct answer is 2 | **4** |
| 2 (fixed) | same scans, class with `hashCode()` | 2 | 2 |
| 3a | change `regNo` *after* insertion (hash uses `regNo`) | size stays 1, but `contains(m)` and `remove(m)` fail | size 1, `contains` = false, `remove` = false; adding `m` again gives size **2** (same object stored twice) |
| 3b | `TreeSet` whose `compareTo` uses name while `equals` uses regNo; two different students called "Arun" | TreeSet 1, HashSet 2 | TreeSet **1**, HashSet **2** |

## Complete the Code (Attendance)

* **Before TODO 1** (no `hashCode`), run 5 times: `Unique students: 3` every time.
* **After TODO 1** (`return regNo.hashCode();`): `Unique students: 2` – matches the expected output.

Why the difference: `HashSet.add` computes `hashCode()` to choose a bucket. Without an override, `Object.hashCode()` is identity-based, so the two "Arun" objects almost surely land in different buckets and `equals()` is never even asked. (Only if the two identity hash codes happened to be exactly equal – roughly 1 chance in 2³¹ – would `equals()` be consulted and the set accidentally be correct, so the bug is effectively always present.)

## Inquiry

* **How HashSet locates an element:** `hash = hashCode()` (spread) → bucket index → inside the bucket compare the stored hash and then `equals()`. Both must agree for an element to be found.
* **Contract:** if `a.equals(b)` then `a.hashCode() == b.hashCode()`; `hashCode` must be stable while the object is in a hash collection; the reverse is not required (collisions allowed).
* **Changing a hash field after insertion** (test 3a): the entry stays in the old bucket; lookups hash the new value, go to another bucket and miss it – the object becomes unreachable by `contains`/`remove` yet still counted by `size()` and visible in iteration (a "leak").
* **Correction:** make the fields used in `equals/hashCode` `final` (the given class already does), override `hashCode()` using exactly the same fields as `equals()`, and verify with a unit test that equal objects give equal hashes, that scanning the same ID several times leaves size 2, and with a mutation test as in 3a.

```java
@Override public int hashCode() { return regNo.hashCode(); }   // TODO 1
```

## Alternative concept and complexity

Benchmark: every student scanned 3 times in shuffled order; ns per scan (median of 5), approximate heap of the structure (`Q3/dedup_output.txt`).

| Unique students n | HashSet | TreeSet(Comparator on regNo) | HashMap<String,Student> | heap MB (HS / TS / HM) |
|---|---|---|---|---|
| 10,000 | 222.7 ns | 326.2 ns | 232.5 ns | 0.4 / 0.4 / 0.4 |
| 100,000 | 175.7 ns | 1,076.5 ns | 174.2 ns | 5.1 / 3.8 / 5.1 |
| 1,000,000 | 278.0 ns | 2,144.5 ns | 250.0 ns | 40.5 / 38.2 / 40.5 |

* `HashSet` / `HashMap<String,Student>`: **O(1) average per scan** (worst case O(log n) because Java 8 turns long buckets into trees), space Θ(n); a `HashSet` is internally a `HashMap`, which the identical memory figures confirm. The map additionally lets the app look up a student by regNo.
* `TreeSet` with a comparator on regNo: **O(log n) per scan** (comparisons grow with log n: about 8× slower than HashSet at 1M), space Θ(n) with three links per node; needs no `hashCode`, keeps students sorted by regNo and answers range queries, and its notion of "same" is defined solely by the comparator (see test 3b for what goes wrong if that disagrees with `equals`).
* Heap figures are approximate (GC-based, small values are noisy); the point is that all three are Θ(n) with similar constants.

---

# Q4 – Choosing a Map for a pharmacy inventory (6)

## Design reasoning (before implementation)

| | put | get | iteration | natural report |
|---|---|---|---|---|
| HashMap | O(1) avg | O(1) avg | O(n + capacity), arbitrary order | none |
| TreeMap | O(log n) | O(log n) | O(n), **sorted by code** | code-order |
| LinkedHashMap | O(1) avg | O(1) avg | O(n), **insertion order** | added-order |
| Hashtable | O(1) avg, synchronised | same | arbitrary | none |

Extra work if the "wrong" map is used: HashMap/LinkedHashMap for the code-order report → copy the keys and sort, O(n log n). HashMap/TreeMap for the added-order report → maintain a separate `List` of codes (extra O(n) memory and the risk of it going out of sync with the map).

## Measurements (`Q4/PharmacyBench.java`, `Q4/pharmacy_output.txt`)

Medicines are inserted in shuffled code order (so insertion order ≠ code order); codes like `MED00012345`; 100,000 random lookups; median of 5. Both reports were compared with the required order and **matched in every case** (`code_order_correct = true`, `insertion_order_correct = true`).

| n | Structure | build (ms) | 100k lookups (ms) | ns / lookup | code-order report (ms) | added-order report (ms) |
|---|---|---|---|---|---|---|
| 1,000 | HashMap | 0.18 | 4.21 | 42.1 | 0.49 (sort) | 0.01 (extra list) |
| | TreeMap | 0.28 | 13.74 | 137.4 | 0.10 (native) | 0.02 (extra list) |
| | LinkedHashMap | 0.17 | 1.65 | 16.5 | 0.36 (sort) | 0.02 (native) |
| | Hashtable | 0.13 | 2.27 | 22.7 | 0.22 (sort) | 0.01 (extra list) |
| 100,000 | HashMap | 14.45 | 7.05 | 70.5 | 26.78 | 0.12 |
| | TreeMap | 68.67 | 68.13 | 681.3 | 10.00 | 0.12 |
| | LinkedHashMap | 9.04 | 3.19 | 31.9 | 33.31 | 0.79 |
| | Hashtable | 7.77 | 4.20 | 42.0 | 14.44 | 0.09 |
| 1,000,000 | HashMap | 159.62 | 9.52 | 95.2 | 260.75 | 3.90 |
| | TreeMap | 1,570.84 | 175.20 | 1,752.0 | 161.67 | 6.39 |
| | LinkedHashMap | 153.72 | 10.21 | 102.1 | 667.97 | 17.10 |
| | Hashtable | 136.76 | 15.77 | 157.7 | 257.25 | 1.27 |

*(n = 1,000 values contain JIT warm-up noise; trends from 100,000 upward are the reliable ones.)*

## Scalability inquiry

* **Acceptability criterion:** a stock lookup must use ≤ 1 % of a 100 ms interactive budget, i.e. **≤ 1 ms** (and I require ≤ 5 µs for the in-memory part, so the database/UI/network can use the rest); the evening report must finish in under 1 s at the largest realistic size.
* **Result:** all maps meet it by a huge margin – even TreeMap at 1,000,000 medicines needs 1.75 µs per lookup. Pharmacists doing hundreds of lookups a day cannot tell the difference, so lookup speed is not the deciding factor; **the two reports are**.
* **Deployment choice: `LinkedHashMap<String, Medicine>`** – O(1) lookups (≈ 30–100 ns), the added-order report comes natively and needs no extra list, and the code-order report is produced once per evening by sorting the keys (33 ms at 100,000 medicines, 0.67 s at 1,000,000). If the code-order report were needed continuously, or range queries ("all codes between X and Y") were needed, I would choose `TreeMap` instead and keep a list for the added-order report.
* **Where the remaining cost comes from:** the code-order report in `LinkedHashMap` is dominated by the O(n log n) sort of 11-character strings (cache misses and string comparisons); for TreeMap the remaining cost is the building (1.57 s for 1M puts) and the pointer-chasing O(log n) comparisons in every lookup.
* **Why not `Hashtable`:** it is a legacy class; every method is `synchronized` on one lock (coarse, and not a cure for compound operations such as check-then-put), it rejects `null` keys and values, it guarantees no order, and even single-threaded it was slower for lookups (157.7 vs 95.2 ns at 1M). Use `HashMap` (single thread) or `ConcurrentHashMap` (concurrent).

## Alternative concept and complexity – sorted array + `Arrays.binarySearch`

| | Sorted array + binarySearch | HashMap | TreeMap |
|---|---|---|---|
| lookup | O(log n) – measured 1,492 ns at 1M | O(1) avg – 95 ns | O(log n) – 1,752 ns |
| insert | **O(n)** shift (+ O(log n) search) – 1,000 inserts: 4.6 ms at 100k, **63.7 ms at 1M** | O(1) avg | O(log n) |
| code-order report | **O(n)**, already sorted – 31 ms at 1M (fastest) | O(n log n) – 261 ms | O(n) – 162 ms |
| space | n references, no per-entry node (smallest, contiguous) | table + node per entry (~40 MB for 1M in Q3's equivalent) | node with three links per entry |
| build | O(n log n) sort – 816 ms at 1M | 160 ms | 1,571 ms |

A sorted array is excellent for a *read-mostly* catalogue (smallest memory, fastest sorted report), but each new medicine costs O(n), and the added-order report would still need an extra list.

---

# Q5 – Derive a generic ranking component from a principle (7)

## Design derived from the principle

*Principle:* a ranking is correct only if the comparison is consistent – transitive, antisymmetric in sign, and "equal" items compare as 0.

1. **Comparator, not Comparable.** A class can have only one `compareTo`, but the same `Team` may be ranked by different rules (league table, fair-play table), and players/colleges/quiz teams need other rules. A `Comparator<T>` passed into the component keeps the ranking rule outside the data class. `Comparable` is right only when there is one obvious natural order.
2. **Multi-field comparison as a lexicographic chain:** `comparingInt(points).reversed()`, then `thenComparing(comparingInt(goalDiff).reversed())`, then `thenComparing(name)`. Each key comparator is a total preorder; `reversed()` preserves that; `thenComparing` applies the next one only on an exact tie.
3. **Generic class with the right bounds.** `Leaderboard<T>` takes `Comparator<? super T>` (a comparator written for a supertype can rank subtypes – consumer wildcard, "PECS"). For types with a natural order, `<T extends Comparable<? super T>>` bounds the type.
4. **Where `List<? extends T>` helps:** `addAll(Collection<? extends T> more)` *reads* from the argument, so a `List<SubTeam>` can be added to a `RankBoard<Team>` (shown in `RankingExperiments`: top team printed was `Sub1(12,0)`).

## Complete the Code (`Q5/LeaderboardDemo.java`)

```java
List<T> ranking() {                                   // TODO 1
    List<T> copy = new ArrayList<>(items);
    copy.sort(order);
    return copy;                                      // items itself is never reordered
}
Comparator<Team> byRank = Comparator                  // TODO 2
    .comparingInt((Team t) -> t.points).reversed()
    .thenComparing(Comparator.comparingInt((Team t) -> t.goalDiff).reversed())
    .thenComparing(t -> t.name);
```

Output: `[Eagles(9,6), Bisons(9,4), Panthers(9,4), Cobras(6,1)]` – identical to the expected output.

**Why Bisons is above Panthers:** both have 9 points and goal difference 4, so the first two comparators return 0; the third, name A–Z, puts "Bisons" before "Panthers".

## Tests (`Q5/ranking_experiments_output.txt`)

* **Set A (ties at every level)**: Eagles/Lions (9,6), Bisons/Panthers (9,4), Hawks (6,3), Cobras/Zebras (6,1), Aces/Wolves (3,0). The program output equals the order worked out by hand: `[Eagles, Lions, Bisons, Panthers, Hawks, Cobras, Zebras, Aces, Wolves]`.
* **Set B (designed to break a faulty comparator):** four teams with 5 points and goal differences `MAX_VALUE, -5, MIN_VALUE, 1`. Correct: `Alpha, Delta, Beta, Gamma`. The **subtraction** comparator returned `Beta, Gamma, Alpha, Delta` – wrong; e.g. `compare(Alpha, Beta)` = 2,147,483,644 (positive), saying Alpha ranks *after* Beta, because `-5 - MAX_VALUE` overflows.
* **Comparator that ignores the name tie-breaker:** `[Panthers, Bisons]` stays in that order and `[Bisons, Panthers]` stays in that order – the ranking depends on the input order, which means two equal-by-rule teams are ranked arbitrarily. With the name tie-breaker both inputs give `[Bisons, Panthers]`.
* **5,000 random teams with extreme values:** the faulty comparator did *not* make `TimSort` throw "Comparison method violates its general contract" on this data (it can for other inputs), but its result is not a valid ranking; the correct comparator was verified pairwise on the whole sorted list.

## Correctness argument (by reasoning)

Let *k₁(t)=points, k₂(t)=goalDiff, k₃(t)=name*. Each `cᵢ(a,b)` = `Integer.compare` or `String.compareTo` on the key (reversed for the first two) – a total preorder: `sign cᵢ(a,b) = −sign cᵢ(b,a)`, and `cᵢ(a,b) ≤ 0 ∧ cᵢ(b,c) ≤ 0 ⇒ cᵢ(a,c) ≤ 0`. The chain returns the first non-zero `cᵢ`. Suppose A ranks above B and B above C. Let *i* be the first key where A and B differ (A better) and *j* the first key where B and C differ (B better). Case *i < j*: B and C agree on keys 1…*j*−1, which includes key *i*, so A is also strictly better than C at key *i* and all earlier keys agree → A above C. Case *j < i*: A and B agree on keys 1…*i*−1, which includes key *j*, so A is strictly better than C at key *j* → A above C. Case *i = j*: A is strictly better than B and B strictly better than C on the same key, so A is strictly better than C on that key by transitivity of that key. In every case A ranks above C. Antisymmetry of sign follows from each key's. Two teams compare 0 only if all three keys are equal. Subtraction breaks the property because `b − a` can overflow, so the sign no longer reflects the order (violating sign-antisymmetry and transitivity).

## Alternative concept and complexity

| Approach | Sorts | Time | Extra space | Reuse |
|---|---|---|---|---|
| Comparator chain (used) | 1 | O(n log n) | TimSort buffer up to n/2 references + a few lambdas | rule is a parameter – **easiest to reuse** for players/colleges/quiz teams |
| `Team implements Comparable<Team>` | 1 | O(n log n) | same | one fixed rule baked into the class; the ranking component can only use that rule |
| 3 stable sorts (name, then goalDiff, then points) | **3** | 3 × O(n log n) = O(n log n) with a larger constant | same buffer (reused, but 3 passes) | correct only because sorts are stable and keys are applied from least to most significant; easy to get wrong |

Measured sort time (ms, median of 5, `Q5/ranking_experiments_output.txt`):

| n | Comparator chain | Comparable | 3 stable sorts |
|---|---|---|---|
| 10,000 | 2.8 | 2.2 | 7.1 |
| 100,000 | 41.6 | 29.2 | 74.4 |
| 1,000,000 | 830.4 | 657.0 | 1,314.9 |

All three produced identical orderings on Set A. The comparator chain costs about 25–40 % more than a hand-written `Comparable` (lambda/boxing overhead), but is the most reusable; three sorts cost ~1.6–2.5× more.

---

# Q6 – Priority, order and fairness in a queue (8)

## Design

* A plain FIFO `Queue` serves strictly by arrival, so a critical patient who arrives last waits behind everybody; it has no concept of severity.
* A `PriorityQueue<Patient>` with the comparator *severity ascending, then arrival counter ascending* always has the most urgent patient at the head. The arrival counter is a strictly increasing `long` given at admission; two patients of equal severity compare by it, so the earlier arrival is served first, and no two patients ever compare equal, so the order is fully deterministic (a heap alone is *not* stable).
* Next patient: `poll()`. Waiting list display: copy the queue and sort the copy (`new ArrayList<>(queue)` then `sort`), leaving the queue untouched.

## Complete the Code (`Q6/Triage.java`)

```java
private final PriorityQueue<Patient> queue = new PriorityQueue<>(
    Comparator.comparingInt((Patient p) -> p.severity).thenComparingLong(p -> p.arrival));
```

Output: `Meena(S1) Kumar(S1) Lata(S2) Ravi(S3) John(S3) Asha(S5)` – matches the expected output. Ravi and John are both S3; Ravi was admitted with counter 0 and John with counter 2, so Ravi (smaller counter) is served first – the counter is the tie-breaker that restores arrival order among equal severities.

## Correctness check (8 patients, `Q6/triage_experiments_output.txt`)

Arrivals: Ravi S3, Meena S1, John S3, Asha S5, Kumar S1, Lata S2, Dev S2, Zoya S1. Hand-worked: severity 1 in arrival order (Meena, Kumar, Zoya), then severity 2 (Lata, Dev), then severity 3 (Ravi, John), then Asha.

* Program: `Meena Kumar Zoya Lata Dev Ravi John Asha` – **matches**.
* `System.out.println(queue)` printed `[Meena(S1), Kumar(S1), Lata(S2), Zoya(S1), Ravi(S3), John(S3), Dev(S2), Asha(S5)]`, which is *not* the treatment order: a `PriorityQueue` is a binary heap stored in an array; only the head (index 0) is guaranteed to be the smallest, and `toString()` walks the array in heap order, where Zoya (S1) appears after Lata (S2).

## Growth investigation

*Prediction:* admit = O(log n) (sift-up), serve = O(log n) (sift-down); the sorted-list design: admit O(n), serve O(1); five FIFO queues: admit O(1), serve O(1) (look at ≤ 5 queues).

Measured ns per operation with n patients already waiting (median of 5; 1,000 admits then 1,000 serves):

| n | PQ admit | PQ serve | Sorted LinkedList admit | Sorted LinkedList serve | 5 FIFO queues admit | 5 FIFO queues serve |
|---|---|---|---|---|---|---|
| 1,000 | 148 | 1,163 | 7,956 | 28 | 59 | 39 |
| 10,000 | 42 | 324 | 10,031 | 11 | 9 | 36 |
| 100,000 | 35 | 743 | **336,774** | 8 | 9 | 20 |
| 1,000,000 | 60 | 1,524 | skipped (too slow) | skipped | 14 | 10 |

Interpretation: PQ *serve* grows with n (roughly log n plus cache misses; the n = 1,000 figure is inflated by JIT warm-up). PQ *admit* stays almost flat – expected, because inserting into a binary heap is O(1) on average for random keys (worst case O(log n)). The sorted list's admit grows linearly (7,956 → 336,774 ns, ×42 for ×100 more patients – O(n)); serving from its head is O(1). The five-queue design is O(1) for both.

Space: all three Θ(n); PriorityQueue is a compact array of references; the linked list adds a node per patient; five queues add five deques.

## Inquiry – starvation and a fair rule

With strict severity-first ordering, a severity-5 patient is served only when no severity 1–4 patient is waiting. If severe cases keep arriving faster than the doctor can serve them, that moment never comes. Simulation (2 severity-1/2 arrivals per step, 1 service per step, Zed = severity 5 at t = 0, 3,000 steps):

| Policy | Zed served at step | mean wait S1 | mean wait S2 |
|---|---|---|---|
| Static severity (current rule) | **never** (still waiting) | 11.9 | 1,966.3 |
| Promote one level every T = 100 steps of waiting | 400 | 726.6 | 774.1 |
| Single static key = arrival + T·(severity−1) | 690 | 659.8 | 843.8 |

The simulation is overloaded on purpose – that is the only situation in which starvation occurs. (In Q7 Zed is served at step 696 instead of 690 for the weighted-key rule only because extra severity 3–5 patients are added to that stream.) Fair rule recommended: **age-based priority** (rule 2 or 3). Rule 2 needs an O(n) scan every tick (see Q7); rule 3 needs no scan.

## Deployment decision

**Yes – the design can serve a city hospital receiving 5,000 patients a day.** That is on average one patient every 17.3 s. A full simulated day (5,000 admits + 5,000 serves) took **1.09 ms** in total. The number that matters is the queue length at any one time (tens to a few hundred patients), not the daily total; at 100,000 waiting patients an operation is still under a microsecond. Conditions: `PriorityQueue` is not thread-safe (use a lock or `PriorityBlockingQueue` when several clerks admit patients); it is not persistent (store admissions in a database so a restart does not lose the queue); changing a patient's severity requires remove + re-add (`remove(Object)` is O(n), fine at these sizes); and an aging rule (above) is needed so severity-5 patients are not starved.

## Alternative concept and complexity

| Design | Admit | Serve next | Space |
|---|---|---|---|
| PriorityQueue (binary heap) | O(log n) worst, O(1) average | O(log n) | Θ(n), array |
| LinkedList kept sorted | **O(n)** (find position) | O(1) | Θ(n) + two links per node |
| Array of 5 FIFO queues | O(1) | O(1) – at most 5 emptiness checks | Θ(n) + 5 deques |

Five FIFO queues is the fastest when the number of priority levels is small and fixed (severity 1–5) and arrival order within a level is exactly FIFO; it does not generalise to arbitrary priorities, and aging by promotion would need ordered merging between queues.

---

# Q7 – Day-4 Design Challenge: Diagnose, Redesign and Validate (13)

**Chosen solution:** the fair-triage rule of Q6 ("promote a waiting patient by one severity level every T = 100 steps").

## A. Diagnose the bottleneck (2)

Evidence (`Q7/aging_output.txt`, original design, overloaded stream, T = 100):

| Ticks S | Time (ms) | Comparator calls | Aging-scan visits | Heap rebuilds |
|---|---|---|---|---|
| 1,000 | 15.5 | 415,622 | 527,050 | 685 |
| 2,000 | 26.0 | 1,664,913 | 2,104,100 | 1,464 |
| 4,000 | 95.1 | 6,547,389 | 8,408,200 | 3,002 |
| 8,000 | 326.8 | 25,867,192 | 33,616,400 | 6,045 |
| 16,000 | 1,214.7 | 103,440,775 | 134,432,800 | 12,187 |

* **Where the time goes:** in the aging scan (visits) and the heap rebuild that follows it (comparator calls). Scan visits and comparator calls quadruple each time the run length doubles, and run time grows ×3.4–3.7 per doubling at large S → **O(S²)**, because the backlog grows by about one patient per tick and the whole backlog is scanned every tick.
* **Unnecessarily repeated work:** almost every scan finds nothing to promote (a patient changes level only every 100 ticks) yet still visits every patient; every promotion rebuilds the entire heap (`new PriorityQueue(...).addAll`), i.e. re-sorting data that was almost sorted.
* **Characteristic of the class that causes it:** a `PriorityQueue` orders elements by keys *at insertion time*. It cannot notice that a key changed, has no decrease-key operation, and `remove(Object)`/iteration are O(n). A rule that *changes* keys over time therefore forces scan + rebuild.

## B. Design objective (2)

1. **Zero** aging scans and rebuilds (visits = 0, rebuilds = 0).
2. Keep every admit/serve at O(log n): comparator calls at 8,000 ticks reduced by **≥ 10×**, time by ≥ 10×.
3. Preserve a deterministic total order (equal keys broken by arrival counter) and **bounded waiting for severity 5**: Zed served by step ≤ 700.
4. Accept: strict severity order may be relaxed in a controlled, tunable way.

## C. Revised solution (4)

**Change:** replace "keys change over time, so re-sort" with a **single static key computed once at admission**:

```
key(p) = p.arrival + W * (p.severity - 1)        // smaller key = served earlier, W = T = 100
tie  : smaller arrival first

admit(p):  p.key = p.arrival + W*(p.severity-1);  pq.add(p)      // O(log n)
serve():   return pq.poll()                                      // O(log n)
```

```
Patient { name, severity, arrival }            WeightedTriage
    |                                           - PriorityQueue<Patient> pq
    +-- key() = arrival + W*(severity-1)        - admit(p) / next()
```

**Property exploited:** relative order of two *already waiting* patients depends only on their fixed arrival times and severities, never on the current clock, so the heap invariant stays valid forever. A patient of severity *s* is treated as if he arrived *W·(s−1)* steps later; newcomers' keys increase with time without bound, so after at most *W·(s−1)* steps nobody newer can overtake him – aging is "built into" the key.

**Starvation bound (reasoned):** patient *B* can be served before an earlier-queued patient *A* only if `key(B) < key(A)`, i.e. `B.arrival < A.arrival + W·(sA − sB) ≤ A.arrival + 4W`. So only patients who arrive within 4W = 400 steps after *A* can ever overtake him – a finite set. Zed (arrival 0, severity 5) therefore waits only behind patients with earlier keys.

**Operations avoided:** the O(n) scan every tick (134 M visits at 16,000 ticks → 0) and every heap rebuild. **Extra memory/preprocessing:** one `long` key per patient (can be cached in the object). **New trade-offs:** (i) behaviour is not identical to "promote one level per T" – a severity-2 patient who arrived more than W earlier than a severity-1 patient is served first; (ii) W is a clinical policy parameter; (iii) it needs a monotonic arrival counter/clock; (iv) it does not by itself fix a department that is overloaded.

## D. Prediction (1) (written to `Q7/prediction.txt` before the benchmark run)

1. Aging-scan visits: original O(S²), redesign 0.
2. Time ≈ ×4 per doubling of S for the original, ≈ ×2 for the redesign; at S = 8,000 the redesign ≥ 10× faster.
3. Zed served at about step 400–700 (not "never").
4. Cost expected: mean waiting time of severity-1 patients *higher* in the redesign (because lower-severity patients can overtake).

## E. Implementation and validation (2)

Same arrival stream, same random seed, same doctor rate, median of 5 runs (`Q7/AgingRedesign.java`). Extra severity 3–5 patients arrive every 20 ticks to measure waits of low-urgency patients.

| Ticks | Design | Time (ms) | Comparator calls | Scan visits | Rebuilds | Zed served at | Max wait S3–5 | Mean wait S1 |
|---|---|---|---|---|---|---|---|---|
| 1,000 | Original | 15.5 | 415,622 | 527,050 | 685 | 400 | 503 | 231.2 |
| | Redesign | 0.3 | 17,732 | 0 | 0 | 696 | 831 | 177.9 |
| 4,000 | Original | 95.1 | 6,547,389 | 8,408,200 | 3,002 | 400 | 2,036 | 1,011.4 |
| | Redesign | 0.7 | 85,684 | 0 | 0 | 696 | 2,318 | 931.8 |
| 8,000 | Original | 326.8 | 25,867,192 | 33,616,400 | 6,045 | 400 | 4,095 | 2,042.2 |
| | Redesign | 1.3 | 188,534 | 0 | 0 | 696 | 4,314 | 1,964.2 |
| 16,000 | Original | 1,214.7 | 103,440,775 | 134,432,800 | 12,187 | 400 | 8,189 | 4,096.1 |
| | Redesign | 2.7 | 412,180 | 0 | 0 | 696 | 8,498 | 4,017.0 |

Speed-up (original ÷ redesign time): 52× at 1,000 ticks, ~136× at 4,000, **~251× at 8,000**, ~450× at 16,000. Comparator calls are reduced 23× at 1,000 ticks, 137× at 8,000 and 251× at 16,000. Both designs reach the same final backlog (the system is overloaded 2:1), so the correctness of what remains is comparable.

## F. Defend the final design (2)

* **Prediction check.** (1) Supported: visits grow ×4 per doubling, redesign 0. (2) Supported in direction and exceeded in magnitude: I predicted ≥ 10×, observed ~250× at 8,000 ticks; redesign time roughly doubles when S doubles (0.7 → 1.3 → 2.7 ms). (3) Supported: Zed served at step 696 (original: 400). (4) **Not supported:** I predicted a *higher* mean severity-1 wait, but it was *lower* at small S (177.9 vs 231.2 at 1,000 ticks) and nearly equal at large S (4,017 vs 4,096). Reason: in the original design a promoted severity-2 patient competes at level 1 by raw arrival time and can overtake newer severity-1 patients as soon as it has waited T, whereas in the redesign a severity-2 patient must be W *older* than the severity-1 patient to overtake it – so the relaxation of strict priority turned out smaller than in the original rule. The cost that did show up is on the low-urgency side: maximum wait of severity 3–5 patients is 1.65× higher at 1,000 ticks (831 vs 503) and ~4 % higher at 16,000 ticks; Zed waits 696 instead of 400 steps.
* **Magnitude:** ~250× less time at 8,000 ticks; 134 M scan visits and 12,187 rebuilds eliminated.
* **New costs/trade-offs:** policy changed from "one level per T" to a weighted-age order; low-urgency patients wait longer; W must be agreed with clinicians; overload is not solved by any ordering rule (the backlog is identical in both runs).
* **When the original may still be preferred:** when the queue is tiny (a scan of ≤ 100 patients is microseconds), when the written clinical policy is literally "promote one level every T" and must be auditable, or when each promotion has to trigger an action such as an alert to nursing staff.
* **Conclusion:** the redesign achieved its objective – no rescans, O(log n) operations, bounded waiting for severity-5 patients – and I consider it the better engineering choice for a large queue; the severity-weighting W must be validated with the hospital.

---

# Summary of evidence

| Q | Key result |
|---|---|
| 1 | `+` is ~170× slower than StringBuilder for 2,000 fields and allocates ~198× more; StringBuffer needed for shared log (StringBuilder lost up to 344 of 160,000 appends) |
| 2 | ArrayList wins for get/iterate/append; front inserts degrade linearly; ArrayDeque for "Up Next" (0.58 ms vs 2,744 ms for ArrayList on 100,000 mixed ops at queue size 500k) |
| 3 | Missing `hashCode` → 3 unique instead of 2; fixed → 2; mutating a hash field breaks `contains`/`remove` |
| 4 | All maps meet the lookup criterion; reports decide: LinkedHashMap chosen; Hashtable not preferred |
| 5 | Comparator chain satisfies the ranking principle; subtraction overflows; chain is the most reusable |
| 6 | PriorityQueue + arrival counter is correct (hand-verified); 5,000 patients/day costs ~1 ms; starvation fixed by age-based key |
| 7 | Static weighted key removes O(n) rescans: ~250× faster at 8,000 ticks, same bounded-wait guarantee for severity 5 |
