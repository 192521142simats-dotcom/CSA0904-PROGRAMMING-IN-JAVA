import java.util.*;
import java.util.function.Function;

/** Q5 - generic design, tie-heavy data, faulty comparators, and alternative approaches. */
public class RankingExperiments {

    // ---------- reusable generic component with bounded type + wildcard ----------
    static class RankBoard<T> {
        private final List<T> items = new ArrayList<>();
        private final Comparator<? super T> order;
        RankBoard(Comparator<? super T> order) { this.order = order; }
        // producer wildcard: accepts List<Team>, List<Premier extends Team>, ... (read-only use of the argument)
        void addAll(Collection<? extends T> more) { items.addAll(more); }
        List<T> ranking() { List<T> c = new ArrayList<>(items); c.sort(order); return c; }
        List<T> top(int k) { List<T> r = ranking(); return r.subList(0, Math.min(k, r.size())); }
    }

    // bounded type: works for any T that knows its own natural order (Comparable<? super T> allows inherited compareTo)
    static <T extends Comparable<? super T>> RankBoard<T> naturalBoard() { return new RankBoard<>(Comparator.naturalOrder()); }

    // generic comparator factory reusable for Team, Player, College, QuizTeam ...
    static <T> Comparator<T> ranking(Function<T, Integer> primaryHigh, Function<T, Integer> secondaryHigh, Function<T, String> nameAZ) {
        return Comparator.comparing(primaryHigh, Comparator.<Integer>reverseOrder())
                         .thenComparing(secondaryHigh, Comparator.<Integer>reverseOrder())
                         .thenComparing(nameAZ);
    }

    static class SubTeam extends Team { SubTeam(String n, int p, int g) { super(n, p, g); } }

    // ---------- alternative 1: Comparable<Team> baked into the class ----------
    static class CTeam implements Comparable<CTeam> {
        final String name; final int points, goalDiff;
        CTeam(String n, int p, int g) { name = n; points = p; goalDiff = g; }
        @Override public int compareTo(CTeam o) {
            int c = Integer.compare(o.points, points);          // NOT subtraction
            if (c != 0) return c;
            c = Integer.compare(o.goalDiff, goalDiff);
            if (c != 0) return c;
            return name.compareTo(o.name);
        }
        @Override public String toString() { return name + "(" + points + "," + goalDiff + ")"; }
    }

    // ---------- faulty comparators ----------
    static final Comparator<Team> SUBTRACTION = (a, b) -> {
        int c = b.points - a.points;                              // overflow-prone
        if (c != 0) return c;
        c = b.goalDiff - a.goalDiff;                              // overflow-prone (goal difference can be negative!)
        if (c != 0) return c;
        return a.name.compareTo(b.name);
    };
    static final Comparator<Team> IGNORES_NAME = (a, b) -> {
        int c = Integer.compare(b.points, a.points);
        return c != 0 ? c : Integer.compare(b.goalDiff, a.goalDiff);   // tie-breaker 3 missing
    };
    static final Comparator<Team> CORRECT = Comparator
        .comparingInt((Team t) -> t.points).reversed()
        .thenComparing(Comparator.comparingInt((Team t) -> t.goalDiff).reversed())
        .thenComparing(t -> t.name);

    static long sink;

    public static void main(String[] args) {
        // ---- Test set A: many ties at every level (hand-checkable) ----
        List<Team> a = new ArrayList<>(List.of(
            new Team("Panthers", 9, 4), new Team("Eagles", 9, 6), new Team("Cobras", 6, 1), new Team("Bisons", 9, 4),
            new Team("Zebras", 6, 1), new Team("Hawks", 6, 3), new Team("Aces", 3, 0), new Team("Wolves", 3, 0), new Team("Lions", 9, 6)));
        System.out.println("Set A (ties at all 3 levels), correct comparator:");
        RankBoard<Team> board = new RankBoard<>(CORRECT);
        board.addAll(a);
        System.out.println("  " + board.ranking());
        System.out.println("  expected by hand: [Eagles(9,6), Lions(9,6), Bisons(9,4), Panthers(9,4), Hawks(6,3), Cobras(6,1), Zebras(6,1), Aces(3,0), Wolves(3,0)]");

        // wildcard: add a List<SubTeam> to RankBoard<Team>
        RankBoard<Team> b2 = new RankBoard<>(CORRECT);
        b2.addAll(List.of(new SubTeam("Sub1", 12, 0)));
        b2.addAll(a);
        System.out.println("  wildcard addAll(List<SubTeam>) -> top 1: " + b2.top(1));

        // ---- Test set B: designed to break faulty comparators ----
        List<Team> b = new ArrayList<>(List.of(
            new Team("Alpha", 5, Integer.MAX_VALUE),   // huge positive goal difference
            new Team("Beta", 5, -5),                   // small negative goal difference
            new Team("Gamma", 5, Integer.MIN_VALUE),
            new Team("Delta", 5, 1)));
        System.out.println("\nSet B (same points, extreme goal differences):");
        System.out.println("  correct      : " + sorted(b, CORRECT));
        System.out.println("  subtraction  : " + sorted(b, SUBTRACTION) + "   <-- WRONG: b.goalDiff - a.goalDiff overflows");
        // direct demonstration of the sign error
        Team alpha = b.get(0), beta = b.get(1);
        System.out.println("  SUBTRACTION.compare(Alpha, Beta) = " + SUBTRACTION.compare(alpha, beta)
            + "  (Alpha has the larger goal difference so it should be NEGATIVE = ranked first); correct = " + CORRECT.compare(alpha, beta));

        // missing tie-breaker: stable sort keeps input order for exact ties -> result depends on input order
        List<Team> t1 = List.of(new Team("Panthers", 9, 4), new Team("Bisons", 9, 4));
        List<Team> t2 = List.of(new Team("Bisons", 9, 4), new Team("Panthers", 9, 4));
        System.out.println("\nIgnoring the name tie-breaker:");
        System.out.println("  input [Panthers, Bisons] -> " + sorted(t1, IGNORES_NAME));
        System.out.println("  input [Bisons, Panthers] -> " + sorted(t2, IGNORES_NAME) + "   <-- ranking depends on input order (not deterministic)");
        System.out.println("  with name tie-breaker    -> " + sorted(t1, CORRECT) + " and " + sorted(t2, CORRECT));

        // Large random data: does the subtraction comparator violate TimSort's contract?
        Random r = new Random(5);
        List<Team> big = new ArrayList<>();
        for (int i = 0; i < 5000; i++) {
            int g = switch (r.nextInt(3)) { case 0 -> Integer.MAX_VALUE - r.nextInt(5); case 1 -> Integer.MIN_VALUE + r.nextInt(5); default -> r.nextInt(11) - 5; };
            big.add(new Team("T" + i, r.nextInt(3), g));
        }
        try { sorted(big, SUBTRACTION); System.out.println("\n5000 extreme teams, subtraction comparator: sort finished without exception (but order is unreliable)"); }
        catch (IllegalArgumentException e) { System.out.println("\n5000 extreme teams, subtraction comparator: " + e.getClass().getSimpleName() + ": " + e.getMessage()); }
        List<Team> ok = sorted(big, CORRECT);
        boolean inOrder = true;
        for (int i = 1; i < ok.size(); i++) if (CORRECT.compare(ok.get(i - 1), ok.get(i)) > 0) inOrder = false;
        System.out.println("5000 extreme teams, correct comparator: sorted & verified pairwise = " + inOrder);

        // ---- Alternatives: Comparable vs 3 stable sorts vs comparator chain ----
        System.out.println("\nAlternatives on Set A:");
        List<CTeam> ct = new ArrayList<>();
        for (Team t : a) ct.add(new CTeam(t.name, t.points, t.goalDiff));
        Collections.sort(ct);
        System.out.println("  Comparable<CTeam>  : " + ct);
        List<Team> three = new ArrayList<>(a);
        three.sort(Comparator.comparing((Team t) -> t.name));                                         // least important first
        three.sort(Comparator.comparingInt((Team t) -> t.goalDiff).reversed());
        three.sort(Comparator.comparingInt((Team t) -> t.points).reversed());
        System.out.println("  3 stable sorts     : " + three);
        System.out.println("  all three identical: " + (three.toString().equals(sorted(a, CORRECT).toString()) && ct.toString().equals(three.toString())));

        // ---- Timing ----
        System.out.println("\nn,chain_ms,comparable_ms,three_sorts_ms (median of 5; sorting a shuffled copy)");
        for (int n : new int[]{10_000, 100_000, 1_000_000}) {
            Random rr = new Random(11);
            List<Team> base = new ArrayList<>(); List<CTeam> cbase = new ArrayList<>();
            for (int i = 0; i < n; i++) { int p = rr.nextInt(30), g = rr.nextInt(41) - 20; String nm = "T" + rr.nextInt(n); base.add(new Team(nm, p, g)); cbase.add(new CTeam(nm, p, g)); }
            double[] c1 = new double[5], c2 = new double[5], c3 = new double[5];
            for (int k = 0; k < 5; k++) {
                List<Team> x = new ArrayList<>(base); long s = System.nanoTime(); x.sort(CORRECT); c1[k] = (System.nanoTime() - s) / 1e6; sink += x.size();
                List<CTeam> y = new ArrayList<>(cbase); s = System.nanoTime(); Collections.sort(y); c2[k] = (System.nanoTime() - s) / 1e6; sink += y.size();
                List<Team> z = new ArrayList<>(base); s = System.nanoTime();
                z.sort(Comparator.comparing((Team t) -> t.name));
                z.sort(Comparator.comparingInt((Team t) -> t.goalDiff).reversed());
                z.sort(Comparator.comparingInt((Team t) -> t.points).reversed());
                c3[k] = (System.nanoTime() - s) / 1e6; sink += z.size();
            }
            Arrays.sort(c1); Arrays.sort(c2); Arrays.sort(c3);
            System.out.printf("%d,%.1f,%.1f,%.1f%n", n, c1[2], c2[2], c3[2]);
        }
        System.out.println("sink=" + sink);
    }

    static List<Team> sorted(List<Team> in, Comparator<Team> c) { List<Team> x = new ArrayList<>(in); x.sort(c); return x; }
}
