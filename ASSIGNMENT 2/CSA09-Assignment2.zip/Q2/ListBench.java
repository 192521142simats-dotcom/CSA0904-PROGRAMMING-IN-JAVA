import java.util.*;

/** Q2 - ArrayList vs LinkedList vs ArrayDeque vs plain array with manual shifting. */
public class ListBench {

    static long sink;
    static final int REPS = 5;

    interface Op { void run(); }

    /** median of REPS runs, in milliseconds; setup is re-run each rep and not timed */
    static double median(java.util.function.Supplier<Op> setup) {
        double[] t = new double[REPS];
        for (int i = 0; i < REPS; i++) {
            Op op = setup.get();
            long s = System.nanoTime();
            op.run();
            t[i] = (System.nanoTime() - s) / 1e6;
        }
        Arrays.sort(t);
        return t[REPS / 2];
    }

    static List<Integer> filled(List<Integer> l, int n) {
        for (int i = 0; i < n; i++) l.add(i);
        return l;
    }

    static final int OPS = 2000;   // fixed number of front/middle/get operations at every size

    public static void main(String[] args) {
        int[] sizes = {10_000, 100_000, 500_000};
        System.out.println("op,size,ArrayList_ms,LinkedList_ms,ArrayDeque_ms,ManualArray_ms");
        for (int n : sizes) {
            // ---- add at end (n adds) ----
            double al = median(() -> { List<Integer> l = new ArrayList<>(); return () -> { for (int i = 0; i < n; i++) l.add(i); sink += l.size(); }; });
            double ll = median(() -> { List<Integer> l = new LinkedList<>(); return () -> { for (int i = 0; i < n; i++) l.add(i); sink += l.size(); }; });
            double ad = median(() -> { Deque<Integer> l = new ArrayDeque<>(); return () -> { for (int i = 0; i < n; i++) l.addLast(i); sink += l.size(); }; });
            double ar = median(() -> { int[] a = new int[n]; return () -> { int c = 0; for (int i = 0; i < n; i++) a[c++] = i; sink += c; }; });
            row("add_end(n adds)", n, al, ll, ad, ar);

            // ---- insert at front (OPS inserts) ----
            al = median(() -> { List<Integer> l = filled(new ArrayList<>(), n); return () -> { for (int i = 0; i < OPS; i++) l.add(0, i); sink += l.size(); }; });
            ll = median(() -> { List<Integer> l = filled(new LinkedList<>(), n); return () -> { for (int i = 0; i < OPS; i++) l.add(0, i); sink += l.size(); }; });
            ad = median(() -> { ArrayDeque<Integer> l = new ArrayDeque<>(); for (int i = 0; i < n; i++) l.addLast(i); return () -> { for (int i = 0; i < OPS; i++) l.addFirst(i); sink += l.size(); }; });
            ar = median(() -> { int[] a = new int[n + OPS]; int[] c = {n}; return () -> { for (int i = 0; i < OPS; i++) { System.arraycopy(a, 0, a, 1, c[0]); a[0] = i; c[0]++; } sink += c[0]; }; });
            row("insert_front(" + OPS + " ops)", n, al, ll, ad, ar);

            // ---- remove at front ----
            al = median(() -> { List<Integer> l = filled(new ArrayList<>(), n); return () -> { for (int i = 0; i < OPS; i++) l.remove(0); sink += l.size(); }; });
            ll = median(() -> { List<Integer> l = filled(new LinkedList<>(), n); return () -> { for (int i = 0; i < OPS; i++) l.remove(0); sink += l.size(); }; });
            ad = median(() -> { ArrayDeque<Integer> l = new ArrayDeque<>(); for (int i = 0; i < n; i++) l.addLast(i); return () -> { for (int i = 0; i < OPS; i++) l.removeFirst(); sink += l.size(); }; });
            ar = median(() -> { int[] a = new int[n]; int[] c = {n}; return () -> { for (int i = 0; i < OPS; i++) { System.arraycopy(a, 1, a, 0, c[0] - 1); c[0]--; } sink += c[0]; }; });
            row("remove_front(" + OPS + " ops)", n, al, ll, ad, ar);

            // ---- insert in the middle ----
            al = median(() -> { List<Integer> l = filled(new ArrayList<>(), n); return () -> { for (int i = 0; i < OPS; i++) l.add(l.size() / 2, i); sink += l.size(); }; });
            ll = median(() -> { List<Integer> l = filled(new LinkedList<>(), n); return () -> { for (int i = 0; i < OPS; i++) l.add(l.size() / 2, i); sink += l.size(); }; });
            ar = median(() -> { int[] a = new int[n + OPS]; int[] c = {n}; return () -> { for (int i = 0; i < OPS; i++) { int m = c[0] / 2; System.arraycopy(a, m, a, m + 1, c[0] - m); a[m] = i; c[0]++; } sink += c[0]; }; });
            row("insert_middle(" + OPS + " ops)", n, al, ll, Double.NaN, ar);

            // ---- remove from middle ----
            al = median(() -> { List<Integer> l = filled(new ArrayList<>(), n); return () -> { for (int i = 0; i < OPS; i++) l.remove(l.size() / 2); sink += l.size(); }; });
            ll = median(() -> { List<Integer> l = filled(new LinkedList<>(), n); return () -> { for (int i = 0; i < OPS; i++) l.remove(l.size() / 2); sink += l.size(); }; });
            row("remove_middle(" + OPS + " ops)", n, al, ll, Double.NaN, Double.NaN);

            // ---- get k-th (random) ----
            final int[] idx = new Random(42).ints(OPS, 0, n).toArray();
            al = median(() -> { List<Integer> l = filled(new ArrayList<>(), n); return () -> { long s = 0; for (int k : idx) s += l.get(k); sink += s; }; });
            ll = median(() -> { List<Integer> l = filled(new LinkedList<>(), n); return () -> { long s = 0; for (int k : idx) s += l.get(k); sink += s; }; });
            ar = median(() -> { int[] a = new int[n]; for (int i = 0; i < n; i++) a[i] = i; return () -> { long s = 0; for (int k : idx) s += a[k]; sink += s; }; });
            row("get_kth(" + OPS + " ops)", n, al, ll, Double.NaN, ar);

            // ---- iterate whole list ----
            al = median(() -> { List<Integer> l = filled(new ArrayList<>(), n); return () -> { long s = 0; for (int x : l) s += x; sink += s; }; });
            ll = median(() -> { List<Integer> l = filled(new LinkedList<>(), n); return () -> { long s = 0; for (int x : l) s += x; sink += s; }; });
            ad = median(() -> { ArrayDeque<Integer> l = new ArrayDeque<>(); for (int i = 0; i < n; i++) l.addLast(i); return () -> { long s = 0; for (int x : l) s += x; sink += s; }; });
            ar = median(() -> { int[] a = new int[n]; for (int i = 0; i < n; i++) a[i] = i; return () -> { long s = 0; for (int x : a) s += x; sink += s; }; });
            row("iterate_all", n, al, ll, ad, ar);
        }

        // ---------- Changed condition: "Up Next" queue ----------
        // Mixed workload: 1/3 addFirst, 1/3 addLast, 1/3 removeFirst, queue kept around size n
        System.out.println();
        System.out.println("UpNext mixed workload (100,000 ops: addFirst / addLast / removeFirst)");
        System.out.println("queue_size,ArrayList_ms,LinkedList_ms,ArrayDeque_ms");
        for (int n : sizes) {
            final int OPS2 = 100_000;
            double al = median(() -> { List<Integer> l = filled(new ArrayList<>(), n); return () -> {
                for (int i = 0; i < OPS2; i++) { switch (i % 3) { case 0: l.add(0, i); break; case 1: l.add(i); break; default: l.remove(0); } } sink += l.size(); }; });
            double ll = median(() -> { LinkedList<Integer> l = (LinkedList<Integer>) filled(new LinkedList<>(), n); return () -> {
                for (int i = 0; i < OPS2; i++) { switch (i % 3) { case 0: l.addFirst(i); break; case 1: l.addLast(i); break; default: l.removeFirst(); } } sink += l.size(); }; });
            double ad = median(() -> { ArrayDeque<Integer> l = new ArrayDeque<>(); for (int i = 0; i < n; i++) l.addLast(i); return () -> {
                for (int i = 0; i < OPS2; i++) { switch (i % 3) { case 0: l.addFirst(i); break; case 1: l.addLast(i); break; default: l.removeFirst(); } } sink += l.size(); }; });
            System.out.printf("%d,%.3f,%.3f,%.3f%n", n, al, ll, ad);
        }
        System.out.println("sink=" + sink);
    }

    static void row(String op, int n, double a, double l, double d, double m) {
        System.out.printf("%s,%d,%s,%s,%s,%s%n", op, n, f(a), f(l), f(d), f(m));
    }

    static String f(double v) { return Double.isNaN(v) ? "n/a" : String.format("%.3f", v); }
}
