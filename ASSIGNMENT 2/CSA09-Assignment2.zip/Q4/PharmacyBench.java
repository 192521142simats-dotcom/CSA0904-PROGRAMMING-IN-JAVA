import java.util.*;

/** Q4 - Pharmacy stock lookup: HashMap vs TreeMap vs LinkedHashMap (+ Hashtable, + sorted array + binarySearch). */
public class PharmacyBench {

    record Medicine(String code, String name, int stock) {}

    static long sink;
    static final int LOOKUPS = 100_000;

    static double median(double[] a) { Arrays.sort(a); return a[a.length / 2]; }

    static String code(int i) { return String.format("MED%08d", i); }

    public static void main(String[] args) {
        System.out.println("n,structure,build_ms,lookup_100k_ms,ns_per_lookup,report_code_order_ms,code_order_correct,report_insertion_order_ms,insertion_order_correct");
        for (int n : new int[]{1_000, 100_000, 1_000_000}) {
            // medicines arrive in SHUFFLED code order, so insertion order != code order
            List<Integer> ids = new ArrayList<>(n);
            for (int i = 0; i < n; i++) ids.add(i);
            Collections.shuffle(ids, new Random(7));
            Medicine[] meds = new Medicine[n];
            for (int i = 0; i < n; i++) meds[i] = new Medicine(code(ids.get(i)), "Drug" + ids.get(i), i % 500);
            String[] insertionCodes = new String[n];
            for (int i = 0; i < n; i++) insertionCodes[i] = meds[i].code();
            String[] sortedCodes = insertionCodes.clone(); Arrays.sort(sortedCodes);
            // lookup keys: random existing codes
            Random rnd = new Random(99);
            String[] keys = new String[LOOKUPS];
            for (int i = 0; i < LOOKUPS; i++) keys[i] = insertionCodes[rnd.nextInt(n)];

            String[] kinds = {"HashMap", "TreeMap", "LinkedHashMap", "Hashtable"};
            for (String kind : kinds) {
                double[] build = new double[5], look = new double[5], rc = new double[5], ri = new double[5];
                boolean codeOk = false, insOk = false;
                for (int rep = 0; rep < 5; rep++) {
                    Map<String, Medicine> m = switch (kind) {
                        case "HashMap" -> new HashMap<>();
                        case "TreeMap" -> new TreeMap<>();
                        case "LinkedHashMap" -> new LinkedHashMap<>();
                        default -> new Hashtable<>();
                    };
                    List<String> insertionLog = new ArrayList<>(n); // extra structure for maps that cannot give insertion order
                    long s = System.nanoTime();
                    for (Medicine md : meds) { m.put(md.code(), md); if (!(m instanceof LinkedHashMap)) insertionLog.add(md.code()); }
                    build[rep] = (System.nanoTime() - s) / 1e6;

                    s = System.nanoTime(); long tot = 0;
                    for (String k : keys) tot += m.get(k).stock();
                    look[rep] = (System.nanoTime() - s) / 1e6; sink += tot;

                    // report 1: all medicines in code order
                    s = System.nanoTime();
                    List<String> codeOrder;
                    if (m instanceof TreeMap) codeOrder = new ArrayList<>(m.keySet());              // natural
                    else { codeOrder = new ArrayList<>(m.keySet()); Collections.sort(codeOrder); } // extra O(n log n) sort
                    rc[rep] = (System.nanoTime() - s) / 1e6;
                    codeOk = codeOrder.equals(Arrays.asList(sortedCodes));

                    // report 2: all medicines in the order they were added
                    s = System.nanoTime();
                    List<String> insOrder;
                    if (m instanceof LinkedHashMap) insOrder = new ArrayList<>(m.keySet());         // natural
                    else insOrder = new ArrayList<>(insertionLog);                                  // needs the extra list
                    ri[rep] = (System.nanoTime() - s) / 1e6;
                    insOk = insOrder.equals(Arrays.asList(insertionCodes));
                    sink += codeOrder.size() + insOrder.size();
                }
                System.out.printf("%d,%s,%.2f,%.2f,%.1f,%.2f,%b,%.2f,%b%n", n, kind, median(build), median(look),
                    median(look) * 1e6 / LOOKUPS, median(rc), codeOk, median(ri), insOk);
            }

            // ---- alternative: sorted array + Arrays.binarySearch ----
            double[] build = new double[5], look = new double[5], rc = new double[5], ins = new double[5];
            for (int rep = 0; rep < 5; rep++) {
                long s = System.nanoTime();
                Medicine[] arr = meds.clone();
                Arrays.sort(arr, Comparator.comparing(Medicine::code));
                build[rep] = (System.nanoTime() - s) / 1e6;
                Comparator<Medicine> byCode = Comparator.comparing(Medicine::code);
                s = System.nanoTime(); long tot = 0;
                for (String k : keys) { int idx = Arrays.binarySearch(arr, new Medicine(k, null, 0), byCode); tot += arr[idx].stock(); }
                look[rep] = (System.nanoTime() - s) / 1e6; sink += tot;
                s = System.nanoTime();
                List<String> co = new ArrayList<>(n); for (Medicine md : arr) co.add(md.code());
                rc[rep] = (System.nanoTime() - s) / 1e6; sink += co.size();
                // cost of 1,000 later insertions keeping the array sorted (shift on each insert)
                Medicine[] grow = Arrays.copyOf(arr, n + 1000); int size = n;
                s = System.nanoTime();
                for (int i = 0; i < 1000; i++) {
                    // random position inside the existing code range (suffix "x" keeps it unique)
                    Medicine nm = new Medicine(code((int) ((i * 7919L) % n)) + "x", "New", 1);
                    int p = Arrays.binarySearch(grow, 0, size, nm, byCode); if (p < 0) p = -p - 1;
                    System.arraycopy(grow, p, grow, p + 1, size - p); grow[p] = nm; size++;
                }
                ins[rep] = (System.nanoTime() - s) / 1e6; sink += size;
            }
            System.out.printf("%d,SortedArray+binarySearch,%.2f,%.2f,%.1f,%.2f,true,n/a(extra list),n/a%n", n, median(build), median(look), median(look) * 1e6 / LOOKUPS, median(rc));
            System.out.printf("   (%d: 1,000 sorted-order insertions into the array took %.3f ms total)%n", n, median(ins));
        }
        System.out.println("sink=" + sink);
    }
}
