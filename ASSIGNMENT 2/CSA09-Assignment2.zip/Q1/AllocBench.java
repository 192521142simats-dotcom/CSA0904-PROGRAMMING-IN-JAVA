import java.lang.management.ManagementFactory;

/** Measures bytes actually allocated per ticket (includes garbage), via per-thread allocation counter. */
public class AllocBench {
    static final com.sun.management.ThreadMXBean TM =
        (com.sun.management.ThreadMXBean) ManagementFactory.getThreadMXBean();

    static long sink;

    static long alloc(Runnable r) {
        long id = Thread.currentThread().getId();
        for (int i = 0; i < 2000; i++) r.run();          // warm-up so JIT is stable
        long b = TM.getThreadAllocatedBytes(id);
        for (int i = 0; i < 100; i++) r.run();
        return (TM.getThreadAllocatedBytes(id) - b) / 100;
    }

    public static void main(String[] a) {
        System.out.println("fields,String+ bytes,StringBuilder bytes,String.join bytes,ratio(+/sb)");
        for (int n : new int[]{10, 50, 200, 2000}) {
            String[] f = TicketBench.fields(n);
            long p = alloc(() -> sink += TicketBench.viaPlus(f).length());
            long s = alloc(() -> sink += TicketBench.viaBuilder(f).length());
            long j = alloc(() -> sink += TicketBench.viaJoin(f).length());
            System.out.printf("%d,%d,%d,%d,%.1f%n", n, p, s, j, p / (double) s);
        }
    }
}
