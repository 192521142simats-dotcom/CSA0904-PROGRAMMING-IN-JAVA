import java.util.StringJoiner;

/**
 * Q1 - Building text under load: String (+), StringBuilder, StringBuffer,
 * plus alternatives String.join and StringJoiner.
 */
public class TicketBench {

    static String[] fields(int n) {
        String[] f = new String[n];
        for (int i = 0; i < n; i++) f[i] = "FIELD" + i + "=value" + i + ";";
        return f;
    }

    static String viaPlus(String[] f) {
        String s = "";
        for (String x : f) s = s + x;          // new String each iteration
        return s;
    }

    static String viaBuilder(String[] f) {
        StringBuilder sb = new StringBuilder();
        for (String x : f) sb.append(x);
        return sb.toString();
    }

    static String viaBuffer(String[] f) {
        StringBuffer sb = new StringBuffer();
        for (String x : f) sb.append(x);
        return sb.toString();
    }

    static String viaJoin(String[] f) {
        return String.join("", f);
    }

    static String viaJoiner(String[] f) {
        StringJoiner j = new StringJoiner("");
        for (String x : f) j.add(x);
        return j.toString();
    }

    interface Builder { String build(String[] f); }

    static long checksum;   // defeats dead-code elimination

    static double timeMs(Builder b, String[] f, int tickets, int reps) {
        // warm-up
        for (int w = 0; w < 3; w++) for (int t = 0; t < Math.max(1, tickets / 10); t++) checksum += b.build(f).length();
        long total = 0;
        for (int r = 0; r < reps; r++) {
            long s = System.nanoTime();
            for (int t = 0; t < tickets; t++) checksum += b.build(f).length();
            total += System.nanoTime() - s;
        }
        return total / (double) reps / 1e6;
    }

    static long usedMem() {
        System.gc(); System.gc();
        Runtime rt = Runtime.getRuntime();
        return rt.totalMemory() - rt.freeMemory();
    }

    public static void main(String[] args) {
        // name, fields per ticket, tickets
        Object[][] workloads = {
            {"W1 short ticket (10 fields x 1 ticket)", 10, 1},
            {"W2 heavy (50 fields x 10,000 tickets)", 50, 10000},
            {"W3 own: very long ticket (2,000 fields x 20 tickets)", 2000, 20},
        };
        String[] names = {"String +", "StringBuilder", "StringBuffer", "String.join", "StringJoiner"};
        Builder[] bs = {TicketBench::viaPlus, TicketBench::viaBuilder, TicketBench::viaBuffer,
                        TicketBench::viaJoin, TicketBench::viaJoiner};

        System.out.println("workload,method,avg_ms,est_intermediate_objects_per_ticket,heap_growth_KB_one_ticket");
        for (Object[] w : workloads) {
            String wn = (String) w[0]; int n = (Integer) w[1]; int tickets = (Integer) w[2];
            String[] f = fields(n);
            int reps = (tickets == 1) ? 2000 : 7;
            for (int i = 0; i < bs.length; i++) {
                int tk = tickets;
                if (tickets == 1) tk = 2000; // repeat a single-ticket build to get measurable time
                double ms = timeMs(bs[i], f, tk, reps) / (tickets == 1 ? 2000.0 : 1.0);
                // estimated intermediate Strings per ticket
                long est = (i == 0) ? n : (i == 1 || i == 2) ? 1 : 1;
                long before = usedMem();
                String keep = bs[i].build(f);
                long after = usedMem();
                System.out.printf("\"%s\",%s,%.5f,%d,%d%n", wn, names[i], ms, est, Math.max(0, (after - before) / 1024));
                checksum += keep.length();
            }
        }

        // Exact chars copied by + for n fields of length L: L*(1+2+...+n) = L*n(n+1)/2 ; builder ~ L*n (amortised)
        System.out.println();
        System.out.println("n,chars_copied_plus,chars_copied_builder_amortised");
        int L = 14;
        for (int n : new int[]{10, 50, 200, 2000}) {
            long plus = (long) L * n * (n + 1) / 2;
            long sb = (long) L * n * 2; // ~2x due to capacity doubling
            System.out.println(n + "," + plus + "," + sb);
        }
        System.out.println("checksum=" + checksum);
    }
}
