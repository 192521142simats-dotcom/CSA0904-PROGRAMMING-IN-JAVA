import java.util.concurrent.*;

/**
 * Q1 design decision: shared booking log appended to by several threads.
 * Shows StringBuilder (unsafe) losing data vs StringBuffer (safe).
 */
public class BookingLog {
    public static void main(String[] args) throws Exception {
        int threads = 8, perThread = 20000;
        for (int round = 1; round <= 3; round++) {
            StringBuilder unsafe = new StringBuilder();
            StringBuffer safe = new StringBuffer();
            ExecutorService ex = Executors.newFixedThreadPool(threads);
            CountDownLatch go = new CountDownLatch(1);
            Future<?>[] fs = new Future<?>[threads];
            for (int t = 0; t < threads; t++) {
                fs[t] = ex.submit(() -> {
                    try { go.await(); } catch (InterruptedException e) { return; }
                    for (int i = 0; i < perThread; i++) {
                        try { unsafe.append('x'); } catch (RuntimeException e) { /* race can throw */ }
                        safe.append('x');
                    }
                });
            }
            go.countDown();
            for (Future<?> f : fs) f.get();
            ex.shutdown();
            System.out.println("Round " + round + ": expected=" + (threads * perThread)
                + "  StringBuilder=" + unsafe.length() + "  StringBuffer=" + safe.length());
        }
    }
}
