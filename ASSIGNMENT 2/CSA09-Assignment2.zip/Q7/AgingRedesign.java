import java.util.*;

/**
 * Q7 - Original (rescan + rebuild every tick) vs Redesign (single static weighted key).
 * Same arrival stream, same doctor rate, same random seed for both.
 */
public class AgingRedesign {

    static class AP {
        final int sev0; int sev; final long arrival; long lastPromo; final boolean zed;
        AP(int s, long a, boolean z) { sev0 = s; sev = s; arrival = a; lastPromo = a; zed = z; }
    }

    static long comparisons;      // operation counter for the comparator
    static long scanVisits;       // patients visited by the periodic aging scan
    static long rebuilds;

    static class Result { double ms; long cmp, visits, rebuilds; long zedServed = -1; double maxWaitHigh; int unservedHigh; double meanWaitS1; int backlog; }

    static final int T = 100;     // original: promote one level per T steps waited; redesign: W = T

    static Result run(boolean redesign, int steps) {
        comparisons = 0; scanVisits = 0; rebuilds = 0;
        Random r = new Random(3);
        Comparator<AP> cmp = redesign
            ? (a, b) -> { comparisons++; int c = Long.compare(a.arrival + (long) T * (a.sev0 - 1), b.arrival + (long) T * (b.sev0 - 1)); return c != 0 ? c : Long.compare(a.arrival, b.arrival); }
            : (a, b) -> { comparisons++; int c = Integer.compare(a.sev, b.sev); return c != 0 ? c : Long.compare(a.arrival, b.arrival); };
        PriorityQueue<AP> q = new PriorityQueue<>(cmp);
        q.add(new AP(5, 0, true));
        Result res = new Result();
        double w1 = 0; int n1 = 0;
        long t0 = System.nanoTime();
        for (long t = 1; t <= steps; t++) {
            // 2 new severity-1/2 patients per tick, plus a severity 3/4/5 patient every 20 ticks
            for (int k = 0; k < 2; k++) q.add(new AP(1 + r.nextInt(2), t, false));
            if (t % 20 == 0) q.add(new AP(3 + r.nextInt(3), t, false));

            if (!redesign) {                                   // the aging rule of the ORIGINAL design
                boolean changed = false;
                for (AP p : q) { scanVisits++; if (p.sev > 1 && t - p.lastPromo >= T) { p.sev--; p.lastPromo = t; changed = true; } }
                if (changed) { List<AP> tmp = new ArrayList<>(q); q = new PriorityQueue<>(cmp); q.addAll(tmp); rebuilds++; }
            }
            AP s = q.poll();                                   // doctor serves one patient per tick
            if (s.zed && res.zedServed < 0) res.zedServed = t;
            if (s.sev0 == 1) { w1 += t - s.arrival; n1++; }
            if (s.sev0 >= 3) res.maxWaitHigh = Math.max(res.maxWaitHigh, t - s.arrival);
        }
        res.ms = (System.nanoTime() - t0) / 1e6;
        res.cmp = comparisons; res.visits = scanVisits; res.rebuilds = rebuilds;
        res.meanWaitS1 = n1 == 0 ? 0 : w1 / n1;
        for (AP p : q) if (p.sev0 >= 3) res.unservedHigh++;
        res.backlog = q.size();
        return res;
    }

    public static void main(String[] args) {
        // warm up JIT
        run(false, 500); run(true, 500);
        System.out.println("ticks,design,time_ms(median of 5),comparator_calls,aging_scan_visits,heap_rebuilds,zed_served_at,max_wait_S3to5_served,S3to5_unserved_at_end,mean_wait_S1,backlog_at_end");
        for (int steps : new int[]{1000, 2000, 4000, 8000, 16000}) {
            for (boolean redesign : new boolean[]{false, true}) {
                double[] ts = new double[5]; Result last = null;
                for (int k = 0; k < 5; k++) { last = run(redesign, steps); ts[k] = last.ms; }
                Arrays.sort(ts);
                System.out.printf("%d,%s,%.1f,%d,%d,%d,%s,%.0f,%d,%.1f,%d%n", steps, redesign ? "REDESIGN(static key)" : "ORIGINAL(rescan)", ts[2],
                    last.cmp, last.visits, last.rebuilds, last.zedServed < 0 ? "never" : String.valueOf(last.zedServed), last.maxWaitHigh, last.unservedHigh, last.meanWaitS1, last.backlog);
            }
        }
    }
}
