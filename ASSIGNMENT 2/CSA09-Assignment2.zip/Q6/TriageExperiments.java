import java.util.*;

/** Q6 - hand-checked instance, why printing a PriorityQueue is misleading, starvation + fair rules, alternatives, growth. */
public class TriageExperiments {

    static final Comparator<Patient> RULE =
        Comparator.comparingInt((Patient p) -> p.severity).thenComparingLong(p -> p.arrival);

    // ---------------- 1. hand-verifiable instance ----------------
    static void handCheck() {
        String[][] in = {{"Ravi","3"},{"Meena","1"},{"John","3"},{"Asha","5"},{"Kumar","1"},{"Lata","2"},{"Dev","2"},{"Zoya","1"}};
        PriorityQueue<Patient> q = new PriorityQueue<>(RULE);
        long c = 0;
        for (String[] r : in) q.add(new Patient(r[0], Integer.parseInt(r[1]), c++));
        System.out.println("== 1. Hand-checked instance (arrival order: Ravi S3, Meena S1, John S3, Asha S5, Kumar S1, Lata S2, Dev S2, Zoya S1)");
        System.out.println("System.out.println(queue)  -> " + q + "   (this is the internal HEAP ARRAY order, not treatment order)");
        System.out.println("Hand-worked order          -> Meena Kumar Zoya | Lata Dev | Ravi John | Asha");
        StringBuilder sb = new StringBuilder(); Patient p;
        while ((p = q.poll()) != null) sb.append(p.name).append(' ');
        System.out.println("Program order (poll loop)  -> " + sb.toString().trim());
        System.out.println("Matches hand-worked order  -> " + sb.toString().trim().equals("Meena Kumar Zoya Lata Dev Ravi John Asha"));
        // proper non-destructive display: sort a copy
        PriorityQueue<Patient> q2 = new PriorityQueue<>(RULE);
        c = 0; for (String[] r : in) q2.add(new Patient(r[0], Integer.parseInt(r[1]), c++));
        List<Patient> view = new ArrayList<>(q2); view.sort(RULE);
        System.out.println("Waiting list display (sorted COPY, queue untouched) -> " + view + ", queue size still " + q2.size());
    }

    // ---------------- 2. starvation simulation ----------------
    static class AP { final String id; final int sev0; int sev; final long arrival; long lastPromo; AP(String i, int s, long a) { id = i; sev0 = s; sev = s; arrival = a; lastPromo = a; } }

    enum Policy { STATIC, PROMOTE_EVERY_T, WEIGHTED_KEY }

    static void starvation() {
        System.out.println("\n== 2. Starvation simulation: 2 new severity-1/2 patients arrive per time step, doctor serves 1 per step; 'Zed' (S5) arrives at t=0");
        System.out.println("policy,zed_served_at_step,mean_wait_S1,mean_wait_S2,patients_still_waiting_at_end");
        int STEPS = 3000; final int T = 100;
        for (Policy pol : Policy.values()) {
            Random r = new Random(3);
            Comparator<AP> cmp;
            if (pol == Policy.WEIGHTED_KEY) cmp = Comparator.comparingLong((AP p) -> p.arrival + (long) T * (p.sev0 - 1)).thenComparingLong(p -> p.arrival);
            else cmp = Comparator.comparingInt((AP p) -> p.sev).thenComparingLong(p -> p.arrival);
            PriorityQueue<AP> q = new PriorityQueue<>(cmp);
            q.add(new AP("Zed", 5, 0));
            long zed = -1; double w1 = 0, w2 = 0; int n1 = 0, n2 = 0;
            for (long t = 1; t <= STEPS; t++) {
                for (int k = 0; k < 2; k++) q.add(new AP("P" + t + "_" + k, 1 + r.nextInt(2), t));
                if (pol == Policy.PROMOTE_EVERY_T) {           // O(n) scan; keys change so heap must be rebuilt
                    boolean changed = false;
                    for (AP p : q) if (p.sev > 1 && t - p.lastPromo >= T) { p.sev--; p.lastPromo = t; changed = true; }
                    if (changed) { List<AP> tmp = new ArrayList<>(q); q = new PriorityQueue<>(cmp); q.addAll(tmp); }
                }
                AP s = q.poll();
                if (s.id.equals("Zed") && zed < 0) zed = t;
                if (s.sev0 == 1) { w1 += t - s.arrival; n1++; } else if (s.sev0 == 2) { w2 += t - s.arrival; n2++; }
            }
            System.out.printf("%s,%s,%.1f,%.1f,%d%n", pol, zed < 0 ? "NEVER (within " + STEPS + " steps)" : String.valueOf(zed), n1 == 0 ? 0 : w1 / n1, n2 == 0 ? 0 : w2 / n2, q.size());
        }
        System.out.println("(wait times are in simulation steps; the system is deliberately overloaded 2:1 so the backlog grows, which is exactly when starvation shows)");
    }

    // ---------------- 3. alternative designs ----------------
    // (a) sorted LinkedList (insert at correct position)
    static class SortedListTriage {
        final LinkedList<Patient> list = new LinkedList<>(); long counter;
        void admit(String n, int sev) {
            Patient p = new Patient(n, sev, counter++);
            ListIterator<Patient> it = list.listIterator();
            while (it.hasNext()) { if (it.next().severity > sev) { it.previous(); break; } }   // O(n) scan
            it.add(p);
        }
        Patient next() { return list.pollFirst(); }                                          // O(1)
    }
    // (b) array of five FIFO queues
    static class BucketTriage {
        @SuppressWarnings("unchecked") final ArrayDeque<Patient>[] qs = new ArrayDeque[5]; long counter;
        BucketTriage() { for (int i = 0; i < 5; i++) qs[i] = new ArrayDeque<>(); }
        void admit(String n, int sev) { qs[sev - 1].addLast(new Patient(n, sev, counter++)); }  // O(1)
        Patient next() { for (ArrayDeque<Patient> q : qs) if (!q.isEmpty()) return q.pollFirst(); return null; } // O(5)=O(1)
    }

    static long sink;
    static void growth() {
        System.out.println("\n== 3. Cost per operation with n patients already waiting (ns per op, median of 5, 1000 admits then 1000 serves)");
        System.out.println("n,PQ_admit,PQ_next,SortedLinkedList_admit,SortedLinkedList_next,FiveQueues_admit,FiveQueues_next");
        final int K = 1000;
        for (int n : new int[]{1_000, 10_000, 100_000, 1_000_000}) {
            double[][] t = new double[6][5];
            for (int rep = 0; rep < 5; rep++) {
                Random r = new Random(rep + 1);
                // prefill each structure with n patients of random severity
                Triage dummy = null;
                PriorityQueue<Patient> pq = new PriorityQueue<>(RULE);
                BucketTriage bt = new BucketTriage();
                SortedListTriage sl = new SortedListTriage();
                int[] sev = new int[n]; for (int i = 0; i < n; i++) sev[i] = 1 + r.nextInt(5);
                long c = 0; for (int i = 0; i < n; i++) { pq.add(new Patient("p", sev[i], c++)); bt.admit("p", sev[i]); }
                // sorted list prefill: bucket-style (already sorted by (severity, arrival)) so setup is O(n)
                long ctr = 0; List<Patient> tmp = new ArrayList<>(n); for (int i = 0; i < n; i++) tmp.add(new Patient("p", sev[i], ctr++)); tmp.sort(RULE); sl.list.addAll(tmp); sl.counter = ctr;
                int[] ks = new int[K]; for (int i = 0; i < K; i++) ks[i] = 1 + r.nextInt(5);
                long s;
                s = System.nanoTime(); for (int k : ks) pq.add(new Patient("x", k, c++)); t[0][rep] = (System.nanoTime() - s) / (double) K;
                s = System.nanoTime(); for (int i = 0; i < K; i++) sink += pq.poll().severity;   t[1][rep] = (System.nanoTime() - s) / (double) K;
                if (n <= 100_000) {
                    s = System.nanoTime(); for (int k : ks) sl.admit("x", k); t[2][rep] = (System.nanoTime() - s) / (double) K;
                    s = System.nanoTime(); for (int i = 0; i < K; i++) sink += sl.next().severity; t[3][rep] = (System.nanoTime() - s) / (double) K;
                } else { t[2][rep] = Double.NaN; t[3][rep] = Double.NaN; }
                s = System.nanoTime(); for (int k : ks) bt.admit("x", k); t[4][rep] = (System.nanoTime() - s) / (double) K;
                s = System.nanoTime(); for (int i = 0; i < K; i++) sink += bt.next().severity;   t[5][rep] = (System.nanoTime() - s) / (double) K;
            }
            StringBuilder sb = new StringBuilder().append(n);
            for (double[] a : t) { Arrays.sort(a); sb.append(',').append(Double.isNaN(a[2]) ? "skipped(too slow)" : String.format("%.0f", a[2])); }
            System.out.println(sb);
        }
        System.out.println("(1,000,000-patient sorted-LinkedList case skipped: each admit scans ~n/2 nodes)");
    }

    static void capacity() {
        System.out.println("\n== 4. City hospital load: 5,000 patients/day");
        double perSec = 5000 / 86400.0;
        System.out.printf("average arrival rate = %.3f patients/second (one every %.1f s)%n", perSec, 1 / perSec);
        PriorityQueue<Patient> pq = new PriorityQueue<>(RULE);
        long c = 0; long s = System.nanoTime();
        for (int i = 0; i < 5000; i++) pq.add(new Patient("p", 1 + (i * 31) % 5, c++));
        long add = System.nanoTime() - s; s = System.nanoTime();
        while (pq.poll() != null) { }
        long rem = System.nanoTime() - s;
        System.out.printf("a whole day (5,000 admits then 5,000 serves) costs %.2f ms in total (admit %.2f ms, serve %.2f ms)%n", (add + rem) / 1e6, add / 1e6, rem / 1e6);
    }

    public static void main(String[] args) {
        handCheck(); starvation(); growth(); capacity();
        System.out.println("sink=" + sink);
    }
}
