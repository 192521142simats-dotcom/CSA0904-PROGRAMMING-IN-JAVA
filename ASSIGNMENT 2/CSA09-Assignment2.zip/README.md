# CSA09 – Programming in Java – Assignment 2 (CO2)

| | |
|---|---|
| **Name** | ______________________ |
| **Register number** | ______________________ |
| **Java version** | OpenJDK 21.0.12.1 (`javac 21.0.12.1`) – replace with the output of `java -version` on your machine |
| **Repository** | `CSA09-<RegisterNumber>-Assignment2` |

The full analysis (predictions, tables, complexity, design arguments) is in **REPORT.md / REPORT.docx**. Raw program output for every task is stored next to its source in the `*_output.txt` files.

## Layout

```
Q1/  String / StringBuilder / StringBuffer     TicketBench, AllocBench, BookingLog
Q2/  ArrayList / LinkedList / ArrayDeque       ListBench
Q3/  hashCode–equals contract                  before/Attendance, after/Attendance, ContractExperiments, DedupBench
Q4/  HashMap / TreeMap / LinkedHashMap         PharmacyBench
Q5/  Generic ranking                           LeaderboardDemo (Complete the Code), RankingExperiments
Q6/  Priority queue triage                     Triage (Complete the Code), TriageExperiments
Q7/  Diagnose, redesign, validate              AgingRedesign, prediction.txt
run_all.sh                                     compiles and runs everything
```

## How to compile and run

Use `unset JAVA_TOOL_OPTIONS` first if your shell prints a "Picked up JAVA_TOOL_OPTIONS" line. Run each command inside the task folder. Benchmarks take a few minutes in total; give them a quiet machine for repeatable numbers.

| Task | Commands | Result |
|---|---|---|
| Q1 | `javac *.java` then `java -Xms512m -Xmx512m TicketBench`, `java AllocBench`, `java BookingLog` | `+` is O(n²): ~170× slower than StringBuilder at 2,000 fields and ~198× more allocation; StringBuilder lost 100–350 of 160,000 shared appends, StringBuffer lost none |
| Q2 | `javac ListBench.java` then `java -Xms1g -Xmx2g ListBench` | ArrayList best for get/append/iterate; front edits grow linearly; ArrayDeque/LinkedList flat for "Up Next" |
| Q3 | `cd before && javac Attendance.java && java Attendance` (prints 3), `cd ../after && javac Attendance.java && java Attendance` (prints 2); then `javac *.java` and `java ContractExperiments`, `java -Xms1g -Xmx3g DedupBench` | Missing `hashCode` → 3 unique; fixed → 2; mutated key lost; TreeSet/HashSet disagree when compareTo ≠ equals |
| Q4 | `javac PharmacyBench.java` then `java -Xms1g -Xmx3g PharmacyBench` | All maps meet the lookup criterion; LinkedHashMap chosen; both reports verified correct |
| Q5 | `javac *.java` then `java LeaderboardDemo`, `java RankingExperiments` | Output `[Eagles(9,6), Bisons(9,4), Panthers(9,4), Cobras(6,1)]`; subtraction comparator proven wrong on overflow data |
| Q6 | `javac *.java` then `java Triage`, `java -Xms1g -Xmx3g TriageExperiments` | Output `Meena(S1) Kumar(S1) Lata(S2) Ravi(S3) John(S3) Asha(S5)`; hand-check matches; starvation shown and fixed; 5,000 patients/day ≈ 1 ms |
| Q7 | `javac AgingRedesign.java` then `java -Xms1g -Xmx3g AgingRedesign` | Static weighted key removes the O(n) rescans: ~250× faster at 8,000 ticks, Zed (S5) served at step 696 |

Or run everything: `bash run_all.sh`.

## Commit plan (one commit per task at minimum)

```
git init && git add README.md && git commit -m "Add README"
git add Q1 && git commit -m "Q1: String/StringBuilder/StringBuffer experiments"
git add Q2 && git commit -m "Q2: List comparison and Up Next queue"
git add Q3 && git commit -m "Q3: hashCode/equals contract experiments"
git add Q4 && git commit -m "Q4: Map comparison for pharmacy inventory"
git add Q5 && git commit -m "Q5: generic leaderboard and comparators"
git add Q6 && git commit -m "Q6: triage priority queue"
git add Q7 && git commit -m "Q7: diagnose, redesign, validate"
git add REPORT.md REPORT.docx && git commit -m "Add report"
git branch -M main && git remote add origin <your-repo-url> && git push -u origin main
```

Add your own output screenshots (run each program on your machine) into each task folder before committing.
