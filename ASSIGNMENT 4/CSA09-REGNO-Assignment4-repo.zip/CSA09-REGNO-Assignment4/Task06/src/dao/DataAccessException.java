package dao;
/** Any database failure, translated from SQLException so upper layers do not depend on JDBC. */
public class DataAccessException extends Exception {
    public DataAccessException(String m, Throwable c) { super(m, c); }
}
