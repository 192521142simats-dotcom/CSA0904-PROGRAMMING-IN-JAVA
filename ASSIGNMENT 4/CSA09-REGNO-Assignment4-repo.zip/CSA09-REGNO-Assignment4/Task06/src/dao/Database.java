package dao;
import java.sql.*;

/** Connection factory. Override with -DDB_URL=... -DDB_USER=... -DDB_PASSWORD=... (e.g. jdbc:mysql://localhost:3306/campus_events). */
public class Database {
    private final String url, user, password;
    public Database() {
        this(System.getProperty("DB_URL", "jdbc:mariadb://localhost:3306/campus_events"),
             System.getProperty("DB_USER", "eventapp"),
             System.getProperty("DB_PASSWORD", "eventpass"));
    }
    public Database(String url, String user, String password) { this.url = url; this.user = user; this.password = password; }
    public Connection open() throws SQLException { return DriverManager.getConnection(url, user, password); }
}
