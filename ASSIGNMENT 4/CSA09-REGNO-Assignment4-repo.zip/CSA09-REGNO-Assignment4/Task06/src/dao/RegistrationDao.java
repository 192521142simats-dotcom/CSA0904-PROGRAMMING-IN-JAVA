package dao;

import model.Event;
import model.Registration;
import java.sql.*;
import java.util.*;
import java.util.function.Consumer;

/** Data-access layer: the ONLY place that contains SQL. All statements are parameterised. */
public class RegistrationDao {
    private static final String SELECT =
        "SELECT r.id, r.reg_no, r.student_name, r.email, r.event_id, e.name, r.registered_at " +
        "FROM registrations r JOIN events e ON e.id = r.event_id ";
    private final Database db;
    public RegistrationDao(Database db) { this.db = db; }

    public List<Event> findEvents() throws DataAccessException {
        try (Connection c = db.open(); Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT id, name FROM events ORDER BY event_date")) {
            List<Event> list = new ArrayList<>();
            while (rs.next()) list.add(new Event(rs.getInt(1), rs.getString(2)));
            return list;
        } catch (SQLException e) { throw new DataAccessException("Could not load events: " + e.getMessage(), e); }
    }

    public boolean exists(String regNo, int eventId) throws DataAccessException {
        try (Connection c = db.open(); PreparedStatement ps = c.prepareStatement("SELECT 1 FROM registrations WHERE reg_no = ? AND event_id = ?")) {
            ps.setString(1, regNo); ps.setInt(2, eventId);
            try (ResultSet rs = ps.executeQuery()) { return rs.next(); }
        } catch (SQLException e) { throw new DataAccessException("Duplicate check failed: " + e.getMessage(), e); }
    }

    /** The UNIQUE(reg_no, event_id) constraint is the final guard even if two clients race. */
    public long insert(String regNo, String name, String email, Event event) throws DataAccessException {
        try (Connection c = db.open(); PreparedStatement ps = c.prepareStatement(
                "INSERT INTO registrations(reg_no, student_name, email, event_id) VALUES (?,?,?,?)", Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, regNo); ps.setString(2, name); ps.setString(3, email); ps.setInt(4, event.id());
            ps.executeUpdate();
            try (ResultSet k = ps.getGeneratedKeys()) { return k.next() ? k.getLong(1) : -1; }
        } catch (SQLIntegrityConstraintViolationException e) {
            throw new DuplicateRegistrationException(regNo, event.name());
        } catch (SQLException e) {
            if (e.getErrorCode() == 1062) throw new DuplicateRegistrationException(regNo, event.name());   // MySQL/MariaDB duplicate key
            throw new DataAccessException("Could not save registration: " + e.getMessage(), e);
        }
    }

    public int count(Event filter) throws DataAccessException {
        String sql = "SELECT COUNT(*) FROM registrations" + (isAll(filter) ? "" : " WHERE event_id = ?");
        try (Connection c = db.open(); PreparedStatement ps = c.prepareStatement(sql)) {
            if (!isAll(filter)) ps.setInt(1, filter.id());
            try (ResultSet rs = ps.executeQuery()) { rs.next(); return rs.getInt(1); }
        } catch (SQLException e) { throw new DataAccessException("Count failed: " + e.getMessage(), e); }
    }

    /** One page of rows: LIMIT/OFFSET keeps memory and transfer small. */
    public List<Registration> findPage(Event filter, int limit, int offset) throws DataAccessException {
        String sql = SELECT + (isAll(filter) ? "" : "WHERE r.event_id = ? ") + "ORDER BY r.id LIMIT ? OFFSET ?";
        try (Connection c = db.open(); PreparedStatement ps = c.prepareStatement(sql)) {
            int i = 1;
            if (!isAll(filter)) ps.setInt(i++, filter.id());
            ps.setInt(i++, limit); ps.setInt(i, offset);
            List<Registration> list = new ArrayList<>(limit);
            try (ResultSet rs = ps.executeQuery()) { while (rs.next()) list.add(map(rs)); }
            return list;
        } catch (SQLException e) { throw new DataAccessException("Could not load registrations: " + e.getMessage(), e); }
    }

    /** Every matching row, handed to a consumer one at a time (used for export). */
    public void forEach(Event filter, Consumer<Registration> sink) throws DataAccessException {
        String sql = SELECT + (isAll(filter) ? "" : "WHERE r.event_id = ? ") + "ORDER BY r.id";
        try (Connection c = db.open(); PreparedStatement ps = c.prepareStatement(sql)) {
            if (!isAll(filter)) ps.setInt(1, filter.id());
            try (ResultSet rs = ps.executeQuery()) { while (rs.next()) sink.accept(map(rs)); }
        } catch (SQLException e) { throw new DataAccessException("Export failed: " + e.getMessage(), e); }
    }

    private static boolean isAll(Event e) { return e == null || e.id() == 0; }
    private static Registration map(ResultSet rs) throws SQLException {
        return new Registration(rs.getLong(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5), rs.getString(6),
                rs.getTimestamp(7).toLocalDateTime());
    }
}
