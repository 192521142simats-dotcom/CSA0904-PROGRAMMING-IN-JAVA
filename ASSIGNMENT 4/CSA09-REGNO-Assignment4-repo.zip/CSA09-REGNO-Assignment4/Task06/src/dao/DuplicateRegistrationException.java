package dao;
public class DuplicateRegistrationException extends DataAccessException {
    public DuplicateRegistrationException(String regNo, String event) {
        super(regNo + " is already registered for \"" + event + "\".", null);
    }
}
