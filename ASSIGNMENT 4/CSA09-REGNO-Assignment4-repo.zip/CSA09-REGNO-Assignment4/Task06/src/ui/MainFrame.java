package ui;

import dao.*;
import model.Event;
import model.Registration;
import service.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.time.format.DateTimeFormatter;
import java.util.List;

/** Main window: menu bar, event filter, paged registrations table, status bar. No SQL here. */
public class MainFrame extends JFrame {
    private static final String[] COLUMNS = {"ID", "Reg No", "Student", "Email", "Event", "Registered at"};
    private final RegistrationService service;
    private final DefaultTableModel model = new DefaultTableModel(COLUMNS, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable table = new JTable(model);
    private final JComboBox<Event> filter = new JComboBox<>();
    private final JButton prev = new JButton("< Prev"), next = new JButton("Next >");
    private final JLabel pageLabel = new JLabel("Page -"), status = new JLabel("Ready");
    private final JProgressBar busy = new JProgressBar();
    private List<Event> events = List.of(Event.ALL);
    private int pageIndex = 0;
    private int loadToken = 0;      // ignore results of superseded loads

    public MainFrame(RegistrationService service) {
        super("Campus Event Registrations");
        this.service = service;
        setJMenuBar(buildMenu());

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.add(new JLabel("Filter by event:")); top.add(filter);
        JButton newBtn = new JButton("New Registration...");
        newBtn.addActionListener(e -> openRegisterDialog());
        top.add(newBtn);

        busy.setIndeterminate(true); busy.setVisible(false); busy.setPreferredSize(new Dimension(120, 14));
        JPanel pager = new JPanel(new FlowLayout(FlowLayout.CENTER));
        pager.add(prev); pager.add(pageLabel); pager.add(next);
        JPanel bottom = new JPanel(new BorderLayout(8, 0));
        bottom.setBorder(BorderFactory.createEmptyBorder(2, 8, 4, 8));
        bottom.add(status, BorderLayout.CENTER); bottom.add(busy, BorderLayout.EAST);
        JPanel south = new JPanel(new BorderLayout());
        south.add(pager, BorderLayout.NORTH); south.add(bottom, BorderLayout.SOUTH);

        add(top, BorderLayout.NORTH); add(new JScrollPane(table), BorderLayout.CENTER); add(south, BorderLayout.SOUTH);
        table.setAutoCreateRowSorter(false); table.setFillsViewportHeight(true);
        int[] w = {50, 100, 140, 210, 140, 140};
        for (int i = 0; i < w.length; i++) table.getColumnModel().getColumn(i).setPreferredWidth(w[i]);

        filter.addActionListener(e -> { pageIndex = 0; loadPage(); });
        prev.addActionListener(e -> { pageIndex--; loadPage(); });
        next.addActionListener(e -> { pageIndex++; loadPage(); });
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(860, 520); setLocationRelativeTo(null);
        loadEventsThenPage();
    }

    private JMenuBar buildMenu() {
        JMenuBar bar = new JMenuBar();
        JMenu file = new JMenu("File"), reg = new JMenu("Registrations"), help = new JMenu("Help");
        file.setMnemonic('F'); reg.setMnemonic('R'); help.setMnemonic('H');
        JMenuItem export = new JMenuItem("Export CSV...");
        export.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E, InputEvent.CTRL_DOWN_MASK));
        export.addActionListener(e -> chooseAndExport());
        JMenuItem exit = new JMenuItem("Exit");
        exit.addActionListener(e -> dispose());
        file.add(export); file.addSeparator(); file.add(exit);
        JMenuItem add = new JMenuItem("New Registration...");
        add.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, InputEvent.CTRL_DOWN_MASK));
        add.addActionListener(e -> openRegisterDialog());
        JMenuItem refresh = new JMenuItem("Refresh");
        refresh.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F5, 0));
        refresh.addActionListener(e -> loadPage());
        reg.add(add); reg.add(refresh);
        JMenuItem about = new JMenuItem("About");
        about.addActionListener(e -> JOptionPane.showMessageDialog(this, "Campus Event Registration\nCSA09 Assignment 4 - Task 6", "About", JOptionPane.INFORMATION_MESSAGE));
        help.add(about);
        bar.add(file); bar.add(reg); bar.add(help);
        return bar;
    }

    private void loadEventsThenPage() {
        setBusy(true, "Loading events...");
        new SwingWorker<List<Event>, Void>() {
            @Override protected List<Event> doInBackground() throws Exception { return service.events(); }
            @Override protected void done() {
                try {
                    events = new java.util.ArrayList<>(); events.add(Event.ALL); events.addAll(get());
                    ActionListener[] ls = filter.getActionListeners();
                    for (ActionListener l : ls) filter.removeActionListener(l);
                    filter.removeAllItems(); for (Event e : events) filter.addItem(e);
                    for (ActionListener l : ls) filter.addActionListener(l);
                    loadPage();
                } catch (Exception ex) { fail(ex); }
            }
        }.execute();
    }

    /** Loads ONE page in the background; the event-dispatch thread only fills 50 rows. */
    public void loadPage() {
        final int token = ++loadToken;
        final Event f = (Event) filter.getSelectedItem();
        final int idx = pageIndex;
        setBusy(true, "Loading...");
        new SwingWorker<Page<Registration>, Void>() {
            @Override protected Page<Registration> doInBackground() throws Exception { return service.page(f, idx); }
            @Override protected void done() {
                if (token != loadToken) return;
                try {
                    Page<Registration> p = get();
                    pageIndex = p.pageIndex();
                    model.setRowCount(0);
                    DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");
                    for (Registration r : p.rows())
                        model.addRow(new Object[]{r.id(), r.regNo(), r.studentName(), r.email(), r.eventName(), r.registeredAt().format(fmt)});
                    pageLabel.setText("Page " + (p.pageIndex() + 1) + " of " + p.pageCount());
                    prev.setEnabled(p.hasPrev()); next.setEnabled(p.hasNext());
                    setBusy(false, p.total() + " registration(s)" + (f == null || f.id() == 0 ? "" : " for " + f.name()));
                } catch (Exception ex) { fail(ex); }
            }
        }.execute();
    }

    public void openRegisterDialog() {
        new RegisterDialog(this, service, events, this::loadPage).setVisible(true);
    }

    private void chooseAndExport() {
        JFileChooser fc = new JFileChooser(); fc.setSelectedFile(new File("registrations.csv"));
        if (fc.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) exportTo(fc.getSelectedFile());
    }

    public void exportTo(File file) {
        final Event f = (Event) filter.getSelectedItem();
        setBusy(true, "Exporting...");
        new SwingWorker<Integer, Void>() {
            @Override protected Integer doInBackground() throws Exception { return service.exportCsv(f, file); }
            @Override protected void done() {
                try { setBusy(false, "Exported " + get() + " row(s) to " + file.getName()); }
                catch (Exception ex) { fail(ex); }
            }
        }.execute();
    }

    private void setBusy(boolean b, String text) { busy.setVisible(b); status.setText(text); status.setForeground(Color.DARK_GRAY); }
    private void fail(Exception ex) {
        Throwable t = ex.getCause() != null ? ex.getCause() : ex;
        busy.setVisible(false); status.setForeground(Color.RED.darker()); status.setText("Error: " + t.getMessage());
    }

    // accessors for the demo driver
    public JComboBox<Event> filterBox() { return filter; }
    public JTable table() { return table; }
    public JLabel statusLabel() { return status; }
}
