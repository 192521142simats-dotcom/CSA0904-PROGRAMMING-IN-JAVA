package ui;

import dao.*;
import service.RegistrationService;
import javax.swing.*;

public class App {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            RegistrationService svc = new RegistrationService(new RegistrationDao(new Database()));
            new MainFrame(svc).setVisible(true);
        });
    }
}
