package ui;

import dao.*;
import model.Event;
import service.*;
import javax.swing.*;
import java.awt.*;
import java.util.List;

/** Registration form. Validation messages are shown inline; the INSERT runs in a SwingWorker. */
public class RegisterDialog extends JDialog {
    private final JTextField regNo = new JTextField(16), name = new JTextField(16), email = new JTextField(16);
    private final JComboBox<Event> event = new JComboBox<>();
    private final JButton register = new JButton("Register"), close = new JButton("Close");
    private final JLabel message = new JLabel(" ");
    private final RegistrationService service;
    private final Runnable onSuccess;

    public RegisterDialog(Frame owner, RegistrationService service, List<Event> events, Runnable onSuccess) {
        super(owner, "New Registration", true);
        this.service = service; this.onSuccess = onSuccess;
        event.addItem(null);
        for (Event e : events) if (e.id() != 0) event.addItem(e);
        event.setRenderer(new DefaultListCellRenderer() {
            @Override public Component getListCellRendererComponent(JList<?> l, Object v, int i, boolean s, boolean f) {
                return super.getListCellRendererComponent(l, v == null ? "-- select event --" : v, i, s, f);
            }
        });
        JPanel form = new JPanel(new GridLayout(4, 2, 6, 8));
        form.add(new JLabel("Register No:")); form.add(regNo);
        form.add(new JLabel("Student name:")); form.add(name);
        form.add(new JLabel("Email:")); form.add(email);
        form.add(new JLabel("Event:")); form.add(event);
        form.setBorder(BorderFactory.createEmptyBorder(12, 12, 6, 12));
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttons.add(register); buttons.add(close);
        JPanel south = new JPanel(new BorderLayout());
        message.setBorder(BorderFactory.createEmptyBorder(0, 12, 0, 12));
        south.add(message, BorderLayout.CENTER); south.add(buttons, BorderLayout.SOUTH);
        add(form, BorderLayout.CENTER); add(south, BorderLayout.SOUTH);
        register.addActionListener(e -> submit());
        close.addActionListener(e -> dispose());
        getRootPane().setDefaultButton(register);
        setMinimumSize(new Dimension(420, 270));
        pack(); setLocationRelativeTo(owner);
    }

    /** Called by the Register button (and by the demo driver). */
    public void submit() {
        register.setEnabled(false);
        show("Saving...", Color.DARK_GRAY);
        final String r = regNo.getText(), n = name.getText(), m = email.getText();
        final Event ev = (Event) event.getSelectedItem();
        new SwingWorker<Long, Void>() {
            @Override protected Long doInBackground() throws Exception { return service.register(r, n, m, ev); }
            @Override protected void done() {
                register.setEnabled(true);
                try {
                    long id = get();
                    show("Registered successfully (id " + id + ").", new Color(0, 120, 0));
                    regNo.setText(""); name.setText(""); email.setText("");
                    onSuccess.run();
                } catch (java.util.concurrent.ExecutionException ex) {
                    Throwable t = ex.getCause();
                    if (t instanceof ValidationException v) show("<html>" + String.join("<br>", v.errors()) + "</html>", Color.RED.darker());
                    else if (t instanceof DuplicateRegistrationException d) show("Duplicate: " + d.getMessage(), Color.RED.darker());
                    else show("Error: " + t.getMessage(), Color.RED.darker());
                } catch (InterruptedException ex) { Thread.currentThread().interrupt(); }
                pack();
            }
        }.execute();
    }

    private void show(String text, Color c) { message.setForeground(c); message.setText(text); }

    // field access for the demo driver
    public JTextField regNoField() { return regNo; }
    public JTextField nameField() { return name; }
    public JTextField emailField() { return email; }
    public JComboBox<Event> eventBox() { return event; }
    public JLabel messageLabel() { return message; }
}
