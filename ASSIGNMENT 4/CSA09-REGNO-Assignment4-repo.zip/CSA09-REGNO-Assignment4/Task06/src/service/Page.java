package service;
import java.util.List;
public record Page<T>(List<T> rows, int total, int pageIndex, int pageSize) {
    public int pageCount() { return Math.max(1, (total + pageSize - 1) / pageSize); }
    public boolean hasPrev() { return pageIndex > 0; }
    public boolean hasNext() { return pageIndex + 1 < pageCount(); }
}
