package service;

import dao.*;
import model.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.Pattern;

/** Business rules: validation, duplicate prevention, paging and export. Contains no Swing and no SQL. */
public class RegistrationService {
    public static final int PAGE_SIZE = 50;
    private static final Pattern REG_NO = Pattern.compile("[A-Za-z0-9]{6,15}");
    private static final Pattern NAME = Pattern.compile("[A-Za-z][A-Za-z .'-]{1,59}");
    private static final Pattern EMAIL = Pattern.compile("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}");
    private final RegistrationDao dao;
    public RegistrationService(RegistrationDao dao) { this.dao = dao; }

    public List<Event> events() throws DataAccessException { return dao.findEvents(); }

    public List<String> validate(String regNo, String name, String email, Event event) {
        List<String> errors = new ArrayList<>();
        if (regNo == null || regNo.isBlank()) errors.add("Register number is required.");
        else if (!REG_NO.matcher(regNo.trim()).matches()) errors.add("Register number must be 6-15 letters/digits.");
        if (name == null || name.isBlank()) errors.add("Name is required.");
        else if (!NAME.matcher(name.trim()).matches()) errors.add("Name may contain only letters, spaces and . ' -");
        if (email == null || email.isBlank()) errors.add("Email is required.");
        else if (!EMAIL.matcher(email.trim()).matches()) errors.add("Email address is not valid.");
        if (event == null || event.id() == 0) errors.add("Select an event.");
        return errors;
    }

    /** Blocking (database call) - always invoked from a SwingWorker. */
    public long register(String regNo, String name, String email, Event event)
            throws ValidationException, DuplicateRegistrationException, DataAccessException {
        List<String> errors = validate(regNo, name, email, event);
        if (!errors.isEmpty()) throw new ValidationException(errors);
        regNo = regNo.trim().toUpperCase(); name = name.trim(); email = email.trim().toLowerCase();
        if (dao.exists(regNo, event.id())) throw new DuplicateRegistrationException(regNo, event.name());
        return dao.insert(regNo, name, email, event);       // unique constraint still guards against races
    }

    public Page<Registration> page(Event filter, int pageIndex) throws DataAccessException {
        int total = dao.count(filter);
        int maxIndex = Math.max(0, (total + PAGE_SIZE - 1) / PAGE_SIZE - 1);
        int idx = Math.min(Math.max(0, pageIndex), maxIndex);
        return new Page<>(dao.findPage(filter, PAGE_SIZE, idx * PAGE_SIZE), total, idx, PAGE_SIZE);
    }

    /** Writes all matching registrations as CSV; returns the number of rows written. */
    public int exportCsv(Event filter, File file) throws DataAccessException, IOException {
        int[] n = {0};
        try (PrintWriter w = new PrintWriter(file, StandardCharsets.UTF_8)) {
            w.println("id,reg_no,student_name,email,event,registered_at");
            dao.forEach(filter, r -> {
                w.println(r.id() + "," + csv(r.regNo()) + "," + csv(r.studentName()) + "," + csv(r.email()) + "," + csv(r.eventName()) + "," + r.registeredAt());
                n[0]++;
            });
        }
        return n[0];
    }
    private static String csv(String s) { return "\"" + s.replace("\"", "\"\"") + "\""; }
}
