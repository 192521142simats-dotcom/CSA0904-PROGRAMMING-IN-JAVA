package model;
import java.time.LocalDateTime;
public record Registration(long id, String regNo, String studentName, String email, int eventId, String eventName, LocalDateTime registeredAt) { }
