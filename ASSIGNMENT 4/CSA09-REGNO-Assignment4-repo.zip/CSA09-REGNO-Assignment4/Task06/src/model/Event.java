package model;
public record Event(int id, String name) {
    public static final Event ALL = new Event(0, "All events");
    @Override public String toString() { return name; }
}
