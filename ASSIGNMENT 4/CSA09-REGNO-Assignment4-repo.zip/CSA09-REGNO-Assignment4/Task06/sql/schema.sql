-- Campus Event Registration - schema and seed data (MySQL 8 / MariaDB 10.x)
CREATE DATABASE IF NOT EXISTS campus_events CHARACTER SET utf8mb4;
USE campus_events;

DROP TABLE IF EXISTS registrations;
DROP TABLE IF EXISTS events;

CREATE TABLE events (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(80) NOT NULL UNIQUE,
  event_date  DATE        NOT NULL,
  venue       VARCHAR(60) NOT NULL
);

CREATE TABLE registrations (
  id            BIGINT AUTO_INCREMENT PRIMARY KEY,
  reg_no        VARCHAR(15)  NOT NULL,
  student_name  VARCHAR(60)  NOT NULL,
  email         VARCHAR(100) NOT NULL,
  event_id      INT          NOT NULL,
  registered_at TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_reg_event FOREIGN KEY (event_id) REFERENCES events(id),
  -- Rule: a student may register only once for the same event (enforced by the database itself)
  CONSTRAINT uq_student_event UNIQUE (reg_no, event_id),
  INDEX idx_event (event_id)
);

INSERT INTO events(name, event_date, venue) VALUES
  ('Cultural Night',      '2026-12-05', 'Main Auditorium'),
  ('Inter-College Dance', '2026-12-06', 'Open Air Theatre'),
  ('Music Fest',          '2026-12-07', 'Seminar Hall'),
  ('Drama Competition',   '2026-12-08', 'Mini Auditorium'),
  ('Art Exhibition',      '2026-12-09', 'Library Foyer');

INSERT INTO registrations(reg_no, student_name, email, event_id) VALUES
  ('CSA091001', 'Anitha Raj',     'anitha.raj@simats.edu',     1),
  ('CSA091002', 'Karthik Kumar',  'karthik.kumar@simats.edu',  1),
  ('CSA091003', 'Divya Menon',    'divya.menon@simats.edu',    2),
  ('CSA091004', 'Rahul Sharma',   'rahul.sharma@simats.edu',   3),
  ('CSA091005', 'Fathima Begum',  'fathima.b@simats.edu',       3),
  ('CSA091006', 'Suresh Babu',    'suresh.babu@simats.edu',    4),
  ('CSA091001', 'Anitha Raj',     'anitha.raj@simats.edu',     3);
