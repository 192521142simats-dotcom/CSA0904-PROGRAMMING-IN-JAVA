import dao.*;
import model.*;
import javax.swing.table.DefaultTableModel;
import java.util.*;

/** 100,000 registrations: load everything into a table model vs one 50-row page (LIMIT/OFFSET). */
public class Task6Bench {
    static long used() { for (int i = 0; i < 4; i++) { System.gc(); try { Thread.sleep(60); } catch (Exception e) { } } Runtime r = Runtime.getRuntime(); return r.totalMemory() - r.freeMemory(); }

    public static void main(String[] a) throws Exception {
        RegistrationDao dao = new RegistrationDao(new Database("jdbc:mariadb://localhost:3306/campus_events_bench", "eventapp", "eventpass"));
        String[] cols = {"ID", "Reg No", "Student", "Email", "Event", "Registered at"};
        int total = dao.count(Event.ALL);
        System.out.println("rows in table: " + total);
        for (int w = 0; w < 2; w++) { dao.findPage(Event.ALL, 50, 0); }        // JIT / connection warm-up

        // ---- A: load everything ----
        long m0 = used();
        long t0 = System.nanoTime();
        List<Registration> all = dao.findPage(Event.ALL, total, 0);
        long tQuery = System.nanoTime();
        DefaultTableModel big = new DefaultTableModel(cols, 0);
        for (Registration r : all) big.addRow(new Object[]{r.id(), r.regNo(), r.studentName(), r.email(), r.eventName(), r.registeredAt().toString()});
        long tModel = System.nanoTime();
        long m1 = used();
        System.out.printf("A) LOAD ALL  : query+fetch+map %.0f ms, build table model %.0f ms, TOTAL %.0f ms, heap held %.1f MB (%d rows)%n",
                (tQuery - t0) / 1e6, (tModel - tQuery) / 1e6, (tModel - t0) / 1e6, (m1 - m0) / 1048576.0, big.getRowCount());
        System.out.printf("   -> if run on the event-dispatch thread the window would be frozen for ~%.0f ms; even in a SwingWorker the final model fill (%.0f ms) blocks it.%n",
                (tModel - t0) / 1e6, (tModel - tQuery) / 1e6);
        big = null; all = null;

        // ---- B: paged ----
        used();
        long p0 = used();
        int[] offsets = {0, 50_000, 99_950};
        for (int off : offsets) {
            long s = System.nanoTime();
            List<Registration> page = dao.findPage(Event.ALL, 50, off);
            long q = System.nanoTime();
            DefaultTableModel small = new DefaultTableModel(cols, 0);
            for (Registration r : page) small.addRow(new Object[]{r.id(), r.regNo(), r.studentName(), r.email(), r.eventName(), r.registeredAt().toString()});
            long e = System.nanoTime();
            System.out.printf("B) PAGE offset %-6d: query in worker thread %.2f ms, EDT fills %d rows in %.3f ms%n", off, (q - s) / 1e6, small.getRowCount(), (e - q) / 1e6);
        }
        long cs = System.nanoTime(); dao.count(Event.ALL); System.out.printf("B) COUNT(*) for page label: %.2f ms%n", (System.nanoTime() - cs) / 1e6);
        long p1 = used();
        System.out.printf("B) heap held for one page (50 rows): ~%.3f MB (measurement noise level)%n", Math.max(0, p1 - p0) / 1048576.0);
    }
}
