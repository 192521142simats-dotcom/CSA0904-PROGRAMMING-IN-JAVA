import dao.*;
import model.Event;
import service.*;
import java.io.File;
import java.util.List;

/** Headless test cases for the service + DAO layers against the real database. */
public class Task6ServiceTest {
    static int failed = 0;
    static void check(String name, boolean ok) { System.out.println((ok ? "PASS  " : "FAIL  ") + name); if (!ok) failed++; }

    public static void main(String[] a) throws Exception {
        RegistrationService s = new RegistrationService(new RegistrationDao(new Database()));
        List<Event> events = s.events();
        Event e1 = events.get(0), e2 = events.get(1);
        String id = "TST" + (System.currentTimeMillis() % 1_000_000);

        long rid = s.register(id, "Test Student", "test.student@simats.edu", e1);
        check("TC1 normal registration accepted (id " + rid + ")", rid > 0);

        try { s.register(id, "Test Student", "test.student@simats.edu", e1); check("TC2 duplicate rejected", false); }
        catch (DuplicateRegistrationException ex) { check("TC2 duplicate rejected: " + ex.getMessage(), true); }

        check("TC3 same student, different event allowed", s.register(id, "Test Student", "test.student@simats.edu", e2) > 0);

        try { s.register(id.toLowerCase(), "Test Student", "x@y.com", e1); check("TC4 duplicate with different letter case rejected", false); }
        catch (DuplicateRegistrationException ex) { check("TC4 duplicate with different letter case rejected", true); }

        for (Object[] t : new Object[][]{
                {"", "Name", "a@b.com", e1, "empty register number"},
                {"AB", "Name", "a@b.com", e1, "short register number"},
                {"CSA09999", "", "a@b.com", e1, "empty name"},
                {"CSA09999", "R2D2 3PO", "a@b.com", e1, "digits in name"},
                {"CSA09999", "Name", "not-an-email", e1, "bad email"},
                {"CSA09999", "Name", "a@b.com", null, "no event selected"},
                {"CSA09999", "Name", "a@b.com", Event.ALL, "'All events' used as event"},
                {"x'); DROP TABLE registrations;--", "Name", "a@b.com", e1, "SQL-injection text in register number"}}) {
            try { s.register((String) t[0], (String) t[1], (String) t[2], (Event) t[3]); check("TC invalid: " + t[4] + " rejected", false); }
            catch (ValidationException ex) { check("TC invalid: " + t[4] + " rejected -> " + ex.errors(), true); }
        }
        check("registrations table still exists after injection attempt", s.page(Event.ALL, 0).total() > 0);

        // database-level guard: bypass the service pre-check and insert directly
        try { new RegistrationDao(new Database()).insert(id, "Test Student", "t@s.edu", e1); check("TC5 DB unique constraint blocks direct duplicate insert", false); }
        catch (DuplicateRegistrationException ex) { check("TC5 DB unique constraint blocks direct duplicate insert", true); }

        Page<?> p = s.page(e1, 0);
        check("paging: page size <= " + RegistrationService.PAGE_SIZE + " (got " + p.rows().size() + ", total " + p.total() + ")", p.rows().size() <= RegistrationService.PAGE_SIZE);
        check("filter returns only the selected event", s.page(e1, 0).rows().stream().allMatch(r -> ((model.Registration) r).eventId() == e1.id()));
        File f = new File("exported_registrations.csv");
        int n = s.exportCsv(Event.ALL, f);
        check("CSV export wrote " + n + " rows to " + f.getName(), n == s.page(Event.ALL, 0).total() && f.length() > 0);

        System.out.println(failed == 0 ? "ALL TESTS PASSED" : failed + " TEST(S) FAILED");
        System.exit(failed);
    }
}
