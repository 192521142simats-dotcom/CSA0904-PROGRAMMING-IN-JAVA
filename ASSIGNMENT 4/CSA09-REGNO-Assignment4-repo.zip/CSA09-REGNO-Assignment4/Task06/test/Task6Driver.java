import dao.*;
import model.Event;
import service.RegistrationService;
import ui.*;
import javax.swing.*;
import java.io.File;
import java.util.List;

/** Demonstrates normal, invalid and duplicate registrations in the real GUI and records screenshots. */
public class Task6Driver {
    static void ui(Runnable r) throws Exception { SwingUtilities.invokeAndWait(r); Shot.wait(300); }

    public static void main(String[] args) throws Exception {
        RegistrationService svc = new RegistrationService(new RegistrationDao(new Database()));
        MainFrame[] mf = new MainFrame[1];
        ui(() -> { mf[0] = new MainFrame(svc); mf[0].setLocation(40, 40); mf[0].setVisible(true); });
        Shot.wait(1500);
        Shot.capture(mf[0], "screenshots/t6_1_main_window.png");
        System.out.println("status after load: " + mf[0].statusLabel().getText());

        ui(() -> mf[0].getJMenuBar().getMenu(0).doClick());
        Shot.capture(mf[0], "screenshots/t6_2_menu_bar_file_menu.png");
        ui(() -> mf[0].getJMenuBar().getMenu(0).doClick());
        ui(() -> mf[0].getJMenuBar().getMenu(1).doClick());
        Shot.capture(mf[0], "screenshots/t6_3_menu_bar_registrations_menu.png");
        ui(() -> mf[0].getJMenuBar().getMenu(1).doClick());

        ui(() -> mf[0].filterBox().setSelectedIndex(3));         // Music Fest
        Shot.wait(1000);
        Shot.capture(mf[0], "screenshots/t6_4_filter_music_fest.png");
        System.out.println("status after filter: " + mf[0].statusLabel().getText());
        ui(() -> mf[0].filterBox().setSelectedIndex(0));
        Shot.wait(800);

        // open the modal registration dialog without blocking the driver thread
        List<Event> events = svc.events();
        RegisterDialog[] d = new RegisterDialog[1];
        ui(() -> { d[0] = new RegisterDialog(mf[0], svc, events, mf[0]::loadPage); d[0].setLocation(300, 160); });
        SwingUtilities.invokeLater(() -> d[0].setVisible(true));
        Shot.wait(800);

        System.out.println("== invalid input ==");
        ui(() -> { d[0].regNoField().setText("AB"); d[0].nameField().setText(""); d[0].emailField().setText("not-an-email"); d[0].submit(); });
        Shot.wait(800);
        Shot.capture(d[0], "screenshots/t6_5_invalid_input_rejected.png");
        System.out.println(d[0].messageLabel().getText());

        System.out.println("== normal registration ==");
        ui(() -> { d[0].regNoField().setText("CSA092001"); d[0].nameField().setText("Priya Nair"); d[0].emailField().setText("priya.nair@simats.edu"); d[0].eventBox().setSelectedIndex(1); d[0].submit(); });
        Shot.wait(1000);
        Shot.capture(d[0], "screenshots/t6_6_normal_registration_success.png");
        System.out.println(d[0].messageLabel().getText());

        System.out.println("== duplicate registration ==");
        ui(() -> { d[0].regNoField().setText("csa092001"); d[0].nameField().setText("Priya Nair"); d[0].emailField().setText("priya.nair@simats.edu"); d[0].eventBox().setSelectedIndex(1); d[0].submit(); });
        Shot.wait(1000);
        Shot.capture(d[0], "screenshots/t6_7_duplicate_rejected.png");
        System.out.println(d[0].messageLabel().getText());

        ui(() -> d[0].dispose());
        Shot.wait(1000);
        Shot.capture(mf[0], "screenshots/t6_8_table_shows_new_registration.png");
        System.out.println("status after registration: " + mf[0].statusLabel().getText());

        mf[0].exportTo(new File("registrations_export.csv"));
        Shot.wait(1000);
        Shot.capture(mf[0], "screenshots/t6_9_export_csv.png");
        System.out.println("status after export: " + mf[0].statusLabel().getText());
        System.exit(0);
    }
}
