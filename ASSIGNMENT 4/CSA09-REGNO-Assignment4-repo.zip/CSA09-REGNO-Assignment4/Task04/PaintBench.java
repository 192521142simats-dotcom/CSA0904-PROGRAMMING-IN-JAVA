import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.*;
import java.util.List;

/** Time per repaint: redraw n stored points (O(n)) vs copy one pre-rendered image (O(w*h), independent of n). */
public class PaintBench {
    public static void main(String[] a) {
        int W = 1920, H = 1080;
        BufferedImage target = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB);
        Random rnd = new Random(1);
        System.out.printf("%-10s %-24s %-24s %-22s %-22s%n", "n clicks", "redraw n points (us)", "copy image (us)", "points memory (KB)", "image memory (KB)");
        for (int n : new int[]{10, 100, 1000, 10000, 100000}) {
            List<Point> pts = new ArrayList<>();
            BufferedImage canvas = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB);
            Graphics2D cg = canvas.createGraphics();
            for (int i = 0; i < n; i++) { Point p = new Point(rnd.nextInt(W), rnd.nextInt(H)); pts.add(p); cg.fillOval(p.x - 3, p.y - 3, 6, 6); }
            cg.dispose();
            Graphics2D g = target.createGraphics();
            for (int i = 0; i < 20; i++) { for (Point p : pts) g.fillOval(p.x - 3, p.y - 3, 6, 6); g.drawImage(canvas, 0, 0, null); }
            int reps = Math.max(5, 200000 / Math.max(n, 1000));
            long t0 = System.nanoTime();
            for (int i = 0; i < reps; i++) for (Point p : pts) g.fillOval(p.x - 3, p.y - 3, 6, 6);
            double listUs = (System.nanoTime() - t0) / 1e3 / reps;
            t0 = System.nanoTime();
            for (int i = 0; i < 200; i++) g.drawImage(canvas, 0, 0, null);
            double imgUs = (System.nanoTime() - t0) / 1e3 / 200;
            g.dispose();
            System.out.printf("%-10d %-24.1f %-24.1f %-22d %-22d%n", n, listUs, imgUs, n * 24L / 1024, W * H * 4L / 1024);
        }
    }
}
