import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;

/** Alternative: dots are painted once onto an off-screen image; paint() only copies that image. */
public class DrawPad extends Frame {
    private BufferedImage canvas;
    private int count = 0;
    private final Label status = new Label("Clicks: 0");

    public DrawPad() {
        super("Draw Pad (BufferedImage)");
        add(status, BorderLayout.SOUTH);
        canvas = new BufferedImage(1920, 1080, BufferedImage.TYPE_INT_ARGB);   // fixed w x h => O(w*h) memory
        addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                Graphics2D g = canvas.createGraphics();
                g.setColor(Color.BLACK); g.fillOval(e.getX() - 3, e.getY() - 3, 6, 6); g.dispose();
                status.setText("Clicks: " + (++count));
                repaint();
            }
        });
        addWindowListener(new WindowAdapter() { @Override public void windowClosing(WindowEvent e) { dispose(); } });
        setSize(400, 300);
    }
    @Override public void paint(Graphics g) { g.drawImage(canvas, 0, 0, null); }   // O(1) in n
    public static void main(String[] a) { new DrawPad().setVisible(true); }
}
