import java.awt.*;
import java.awt.event.*;

public class DrawPad extends Frame {
    public DrawPad() {
        addMouseListener(new MouseAdapter() {
            @Override public void mouseclicked(MouseEvent e) { }   // misspelt on purpose
        });
    }
}
