import java.awt.*;
import java.awt.event.InputEvent;
import java.awt.image.BufferedImage;
import javax.swing.SwingUtilities;

/**
 * Drives whichever DrawPad is first on the classpath: clicks three times, screenshots,
 * minimises + restores the window, screenshots again and reports whether the dots survived.
 * Usage: java -cp <variant dir>:<driver dir>:<tools> Task4Driver <label>
 */
public class Task4Driver {
    static boolean dark(Robot r, Point p) { Color c = r.getPixelColor(p.x, p.y); return c.getRed() < 90 && c.getGreen() < 90 && c.getBlue() < 90; }

    public static void main(String[] args) throws Exception {
        String label = args[0];
        Frame[] f = new Frame[1];
        SwingUtilities.invokeAndWait(() -> {
            try { f[0] = (Frame) Class.forName("DrawPad").getDeclaredConstructor().newInstance(); } catch (Exception e) { throw new RuntimeException(e); }
            f[0].setLocation(100, 100); f[0].setVisible(true);
        });
        Shot.wait(800);
        Robot robot = new Robot();
        Point origin = f[0].getLocationOnScreen();
        Point[] clicks = { new Point(80, 90), new Point(200, 150), new Point(320, 100) };
        for (Point c : clicks) {
            robot.mouseMove(origin.x + c.x, origin.y + c.y); robot.delay(150);
            robot.mousePress(InputEvent.BUTTON1_DOWN_MASK); robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK); robot.delay(300);
        }
        robot.mouseMove(origin.x + 5, origin.y + 5);   // move pointer away so it doesn't hide a dot
        Shot.wait(400);
        String lbl = labelText(f[0]);
        int vis1 = 0; for (Point c : clicks) if (dark(robot, new Point(origin.x + c.x, origin.y + c.y))) vis1++;
        System.out.println("[" + label + "] BEFORE minimise: label=\"" + lbl + "\", dots visible " + vis1 + "/3");
        Shot.capture(f[0], "screenshots/" + label + "_before_minimise.png");

        SwingUtilities.invokeAndWait(() -> f[0].setExtendedState(Frame.ICONIFIED)); Shot.wait(1200);
        System.out.println("[" + label + "] window minimised (state=" + f[0].getExtendedState() + ")");
        SwingUtilities.invokeAndWait(() -> f[0].setExtendedState(Frame.NORMAL)); Shot.wait(1500);
        origin = f[0].getLocationOnScreen();
        int vis2 = 0; for (Point c : clicks) if (dark(robot, new Point(origin.x + c.x, origin.y + c.y))) vis2++;
        System.out.println("[" + label + "] AFTER restore:   label=\"" + labelText(f[0]) + "\", dots visible " + vis2 + "/3");
        Shot.capture(f[0], "screenshots/" + label + "_after_minimise.png");
        System.exit(0);
    }
    static String labelText(Container c) {
        for (Component x : c.getComponents()) if (x instanceof Label l) return l.getText();
        return "?";
    }
}
