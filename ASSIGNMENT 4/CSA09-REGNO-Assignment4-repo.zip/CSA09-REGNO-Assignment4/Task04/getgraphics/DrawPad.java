import java.awt.*;
import java.awt.event.*;

public class DrawPad extends Frame {
  int count = 0; Label status = new Label("Clicks: 0");
  public DrawPad() {
    add(status, BorderLayout.SOUTH);
    addMouseListener(new MouseAdapter() {
      @Override public void mouseClicked(MouseEvent e) {          // defect 1 fixed: correct name
        count++; status.setText("Clicks: " + count);              // label updated
        Graphics g = getGraphics(); g.fillOval(e.getX() - 3, e.getY() - 3, 6, 6);   // still drawn only once!
        g.dispose();
      }
    });
    setSize(400, 300);
  }
}
