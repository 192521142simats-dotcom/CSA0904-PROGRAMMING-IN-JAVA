import os, re
from docx import Document
from docx.shared import Pt, Inches, RGBColor, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from PIL import Image

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
def P(*a): return os.path.join(ROOT, *a)
def rd(*a):
    with open(P(*a)) as f: return f.read().rstrip()

doc = Document()
sec = doc.sections[0]
sec.left_margin = sec.right_margin = Cm(2.2); sec.top_margin = sec.bottom_margin = Cm(2)
st = doc.styles["Normal"]; st.font.name = "Calibri"; st.font.size = Pt(10.5)
for lvl, sz in ((1, 17), (2, 13.5), (3, 11.5)):
    h = doc.styles[f"Heading {lvl}"]; h.font.name = "Calibri"; h.font.size = Pt(sz); h.font.color.rgb = RGBColor(0x1F, 0x3A, 0x6E)

def shade(cell, color):
    tcPr = cell._tc.get_or_add_tcPr(); shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear"); shd.set(qn("w:color"), "auto"); shd.set(qn("w:fill"), color); tcPr.append(shd)

def H(text, lvl=1): return doc.add_heading(text, lvl)
def para(text="", bold=False, italic=False, size=None, align=None):
    p = doc.add_paragraph(); 
    parts = re.split(r"(\*\*[^*]+\*\*)", text)
    for part in parts:
        if part.startswith("**") and part.endswith("**"):
            r = p.add_run(part[2:-2]); r.bold = True
        else:
            r = p.add_run(part); r.bold = bold
        r.italic = italic
        if size: r.font.size = Pt(size)
    if align: p.alignment = align
    p.paragraph_format.space_after = Pt(4)
    return p
def bullets(items, style="List Bullet"):
    for t in items:
        p = doc.add_paragraph(style=style)
        parts = re.split(r"(\*\*[^*]+\*\*)", t)
        for part in parts:
            if part.startswith("**") and part.endswith("**"): p.add_run(part[2:-2]).bold = True
            else: p.add_run(part)
        p.paragraph_format.space_after = Pt(2)
def code(text, size=8.5):
    t = doc.add_table(rows=1, cols=1); t.alignment = WD_TABLE_ALIGNMENT.CENTER
    c = t.rows[0].cells[0]; shade(c, "F3F4F6")
    c.paragraphs[0].text = ""
    lines = text.split("\n")
    for i, line in enumerate(lines):
        p = c.paragraphs[0] if i == 0 else c.add_paragraph()
        r = p.add_run(line if line else " "); r.font.name = "Consolas"; r.font.size = Pt(size)
        r._element.rPr.rFonts.set(qn("w:eastAsia"), "Consolas")
        p.paragraph_format.space_after = Pt(0)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)
def table(rows, widths=None, header=True, size=9):
    t = doc.add_table(rows=len(rows), cols=len(rows[0])); t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, row in enumerate(rows):
        for j, val in enumerate(row):
            c = t.cell(i, j); c.text = ""
            p = c.paragraphs[0]; r = p.add_run(str(val)); r.font.size = Pt(size)
            if header and i == 0: r.bold = True; shade(c, "DCE6F5")
            p.paragraph_format.space_after = Pt(0)
    if widths:
        t.autofit = False
        for j, w in enumerate(widths): t.columns[j].width = Inches(w)
        for row in t.rows:
            for j, w in enumerate(widths): row.cells[j].width = Inches(w)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)
FIG = [0]
def img(path, caption, maxw=6.2, scale=96):
    full = P(path); im = Image.open(full); w = min(maxw, im.width / scale)
    doc.add_picture(full, width=Inches(w)); doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
    FIG[0] += 1
    p = para(f"Figure {FIG[0]}. {caption}", italic=True, size=9, align=WD_ALIGN_PARAGRAPH.CENTER)
def imgs_side(items, maxw=3.0):
    """items: list of (path, caption) placed in one row table."""
    t = doc.add_table(rows=2, cols=len(items)); t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for j, (path, cap) in enumerate(items):
        full = P(path); im = Image.open(full); w = min(maxw, im.width / 96)
        c = t.cell(0, j); c.paragraphs[0].add_run().add_picture(full, width=Inches(w)); c.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        FIG[0] += 1
        cp = t.cell(1, j).paragraphs[0]; r = cp.add_run(f"Figure {FIG[0]}. {cap}"); r.italic = True; r.font.size = Pt(8.5); cp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    doc.add_paragraph().paragraph_format.space_after = Pt(2)
def pagebreak(): doc.add_page_break()

# ------------------------------------------------------------------ COVER
for _ in range(3): doc.add_paragraph()
para("SIMATS ENGINEERING", bold=True, size=18, align=WD_ALIGN_PARAGRAPH.CENTER)
para("PROGRAMMING IN JAVA (CSA09)", bold=True, size=14, align=WD_ALIGN_PARAGRAPH.CENTER)
para("ASSIGNMENT 4 – CO4", bold=True, size=16, align=WD_ALIGN_PARAGRAPH.CENTER)
para("EVENT-DRIVEN GUI DESIGN", bold=True, size=16, align=WD_ALIGN_PARAGRAPH.CENTER)
doc.add_paragraph()
table([["Student name", "[YOUR NAME]"], ["Register number", "[YOUR REGISTER NUMBER]"],
       ["Java version used", "OpenJDK 21 (javac / java 21.0.12)"],
       ["GitHub repository", "https://github.com/[your-username]/CSA09-[RegisterNumber]-Assignment4"],
       ["Total marks", "50"]], widths=[1.9, 4.6], header=False, size=11)
para("Contents: Task 1 (GUI design review) · Task 2 (requirement to event-driven design) · Task 3 (sketch to layout) · Task 4 (event-handling forensics) · Task 5 (event-handling styles) · Task 6 (design challenge: Swing + JDBC) · Evidence index", italic=True, align=WD_ALIGN_PARAGRAPH.CENTER)
para("Pseudocode convention: the SIMATS “Standard for Algorithmic Pseudocode” document was not part of the assignment PDF, so all pseudocode uses the common form ALGORITHM / INPUT / OUTPUT / BEGIN … END with numbered, indented steps and ← for assignment.", italic=True, size=9, align=WD_ALIGN_PARAGRAPH.CENTER)
para("All programs were compiled and executed (OpenJDK 21, Xvfb virtual display + openbox window manager for the GUI screenshots, MariaDB 10.11 – a MySQL-compatible server – for JDBC). Every measurement quoted in this report was produced by the benchmark programs stored in the repository; the raw output files are named in each section.", italic=True, size=9, align=WD_ALIGN_PARAGRAPH.CENTER)
pagebreak()

# ------------------------------------------------------------------ TASK 1
H("Task 1 – GUI Design Review (K4, 6 marks)")
H("Task 1.1 – Diagnose the design (2 marks)", 2)
para("The junior developer’s FeeWindow has eleven deficiencies; the most serious are listed first.")
table([
 ["#", "Deficiency", "What the user experiences / what can go wrong"],
 ["1", "No separation of interface and logic: validation, SQL, JDBC connection and the bank wait are all inside actionPerformed().", "Nothing can be unit-tested without opening a window and a database; any change (new rule, new database) means editing GUI code; the business rule cannot be reused from another screen."],
 ["2", "Strings compared with ==: e.getActionCommand() == \"Pay\".", "== compares references, not text. It only works by accident of string interning; if the label is changed, localised, or built at run time the Pay branch is silently skipped."],
 ["3", "Receipt button has no behaviour and falls into the else branch.", "Pressing Receipt (or any non-Pay button) executes the else branch and wipes the register number and amount that the user typed. The Receipt feature simply does not exist."],
 ["4", "No handling of empty / invalid input: Double.parseDouble(amount.getText()) is unguarded; negative, zero, NaN and huge amounts are accepted.", "Empty or non-numeric text throws NumberFormatException on the event thread – the click does nothing visible and a stack trace goes to the console. A negative payment would be written to the database."],
 ["5", "SQL built by string concatenation: \"INSERT … VALUES('\" + regNo.getText() + \"',\" …", "SQL injection: a register number such as x'); DROP TABLE fees;-- corrupts or destroys data. A name containing an apostrophe simply crashes the statement."],
 ["6", "Database work and Thread.sleep(3000) run on the event-dispatch thread (EDT).", "The whole window freezes for the connection time plus 3 s: no repaint, the Pay button stays ‘pressed’, the title bar shows “Not Responding”, the user clicks again and pays twice."],
 ["7", "Unhandled checked exceptions: DriverManager.getConnection, executeUpdate (SQLException) and Thread.sleep (InterruptedException).", "The code does not even compile as written; if the exceptions were swallowed with an empty catch, failed payments would look successful."],
 ["8", "Connection and Statement are never closed.", "Every payment leaks a database connection; after a few dozen payments the server refuses new connections."],
 ["9", "Feedback only through System.out.println(\"Paid\").", "The receptionist never sees any confirmation or error – the message goes to a console nobody is watching."],
 ["10", "The window is not wired up: the components are never added to the frame, no listener is registered (addActionListener is never called), no layout is set and there is no WindowListener.", "An empty frame appears; even if it were visible, no button would respond, and the close button does nothing so the program cannot be shut down normally."],
 ["11", "Pay button is not disabled while a payment is running.", "Double-clicking creates duplicate payment rows."]],
 widths=[0.3, 2.6, 3.6], size=8.5)

H("Task 1.2 – Repair the design (3 marks)", 2)
para("The window now only collects input and shows results. Validation and payment live in FeeService, persistence is behind a PaymentRepository interface, and the slow work runs in a SwingWorker so the EDT is never blocked.")
img("report/diagrams/t1_classes.png", "Class structure of the redesigned fee window (source: Task01/*.java).", maxw=6.3, scale=110)
para("Rewritten event handling (Task01/FeeWindow.java). Each button has its own Action – no shared listener, no string comparison:", bold=True)
code('''payBtn = new JButton(new AbstractAction("Pay") {
    @Override public void actionPerformed(ActionEvent e) { onPay(); } });
clearBtn = new JButton(new AbstractAction("Clear") {
    @Override public void actionPerformed(ActionEvent e) { regNo.setText(""); amount.setText(""); show("", false); } });
receiptBtn = new JButton(new AbstractAction("Receipt") {
    @Override public void actionPerformed(ActionEvent e) { onReceipt(); } });

private void onPay() {
    String err = service.validate(regNo.getText(), amount.getText());   // fast, on EDT
    if (err != null) { show(err, true); return; }                         // user feedback
    payBtn.setEnabled(false);                                             // no double payment
    show("Processing payment...", false);
    new SwingWorker<Receipt, Void>() {
        @Override protected Receipt doInBackground() throws Exception {   // background thread
            return service.pay(regNo.getText(), amount.getText()); }
        @Override protected void done() {                                  // back on the EDT
            payBtn.setEnabled(true);
            try { show("Payment successful - receipt #" + get().id(), false); }
            catch (Exception ex) { show("Payment failed: " + ex.getCause().getMessage(), true); }
        }
    }.execute();
}''')
para("FeeService.pay() validates (register number 6–15 letters/digits, amount > 0 and ≤ 500 000, not NaN/Infinity), then calls repository.save(). JdbcPaymentRepository uses a PreparedStatement and try-with-resources, so injection and connection leaks are both removed; checked exceptions are converted into one PaymentException that the window shows as text.")
para("Execution evidence (Task01/test_output.txt – headless, no window, with the real database): 15 tests PASS, including empty/non-numeric/negative/NaN/huge amounts, SQL-injection text rejected, and two rows inserted into MariaDB table fees_db.fees through JdbcPaymentRepository.")
code(rd("Task01", "test_output.txt"), size=8)
imgs_side([("Task01/screenshots/t1_1_invalid_input.png", "Tests 1.1 #4/#9: invalid amount \"abc\" is rejected with a visible message (no exception)."),
           ("Task01/screenshots/t1_2_processing_window_responsive.png", "Tests #6/#11: 1.5 s bank wait – Pay disabled, status shown.")], maxw=3.1)
imgs_side([("Task01/screenshots/t1_3_paid.png", "Test #9: confirmation after the payment completes."),
           ("Task01/screenshots/t1_4_receipt_dialog.png", "Test #3: Receipt button now shows the receipt in a dialog.")], maxw=3.1)
para("Responsiveness proof (Task01/driver_output.txt): while the 1.5 s payment ran, a Swing timer on the EDT kept firing – “EDT ticks while payment was in progress: 17” (≈ 1.8 s / 100 ms) – so the window stayed live. In the original design this number would be 0.")

H("Task 1.3 – Design defence (1 mark)", 2)
defence = ("FeeService has no Swing code, so validation and payment rules are tested with plain method calls and an in-memory repository, "
           "as the 15 headless tests show. The window contains only layout and event wiring, so changing a rule or the database touches one class. "
           "PreparedStatements and try-with-resources remove injection and leaks in one place, and the SwingWorker keeps the interface responsive. "
           "Each button owns a small Action, so no string comparison or shared if-else chain can break.")
para(defence)
para(f"(Word count: {len(defence.split())} – limit 100.)", italic=True, size=9)

H("Alternative concept and complexity analysis", 2)
para("**Alternative:** the original design uses one listener and an if–else chain over the command string. The alternative (used in my redesign) gives each button its own listener object or a Swing Action, so the event goes straight to the handler registered on the source button.")
code('''ALGORITHM DispatchChain(command)              ALGORITHM DispatchDirect(button)
 1. FOR i ← 1 TO k DO                          1. listener ← button.listener     // field read
 2.   IF command = name[i] THEN                2. listener.actionPerformed(e)
 3.     run handler[i]; RETURN
 4. END FOR                                    Time: O(1)    Space: k listener objects = O(k)
Time: O(k) comparisons (worst/average), Space: O(1) extra''')
para("Measured with Task01/DispatchBench.java (2 000 000 dispatches of the worst-case, last, command; output in Task01/dispatch_bench_output.txt):")
table([["k buttons", "if–else chain (ns / event)", "own listener (ns / event)", "listener objects"],
       ["3", "5.2", "0.28", "3"], ["10", "23.9", "0.29", "10"], ["100", "188", "0.28", "100"], ["1 000", "1 679", "0.28", "1 000"], ["10 000", "16 948", "0.41", "10 000"]],
      widths=[1.2, 2.0, 2.0, 1.4])
para("**Analysis.** The chain costs O(k) string comparisons per event (time grows linearly with k: ×10 buttons ≈ ×9–10 time), the per-button listener costs O(1) (≈ 0.3 ns, flat). The price is space: k listener objects ≈ 16 bytes each (measured in Task 5’s ListenerBench), i.e. O(k) memory versus O(1) for the single listener. For a real fee window k = 3, so the time difference (≈ 5 ns) is irrelevant; the decisive advantages are maintainability and the removal of the == / fall-through bugs, not speed.")
pagebreak()

# ------------------------------------------------------------------ TASK 2
H("Task 2 – From Requirement to Event-Driven Design (K4, 8 marks)")
para("Hospital Outpatient Appointment Desk. Implementation: Task02/AppointmentDesk.java (Swing), DoctorDirectory.java (Map<String, List<Doctor>> loaded once), AppointmentService.java (rules). Everything below was produced by running Task02/Task2Driver.java.")
H("Task 2.1 – Model the events (2 marks)", 2)
table([
 ["Event source", "Event object", "Listener interface", "Action taken"],
 ["Department JComboBox", "ItemEvent (stateChange = SELECTED)", "ItemListener.itemStateChanged()", "refreshDoctors(): clear doctor list and refill from Map for the chosen department"],
 ["Doctor JComboBox", "ItemEvent / ActionEvent", "(read when booking – no handler needed)", "Selected Doctor object is read in bookAppointment()"],
 ["Time-slot JComboBox", "ItemEvent / ActionEvent", "(read when booking – no handler needed)", "Selected slot is read in bookAppointment()"],
 ["Patient-ID JTextField", "DocumentEvent", "DocumentListener (insert/remove/changedUpdate)", "bookingInProgress ← text is not blank"],
 ["Book JButton", "ActionEvent", "ActionListener.actionPerformed()", "Validate; if OK confirm booking, else show error in status label"],
 ["AppointmentDesk JFrame (close button)", "WindowEvent (WINDOW_CLOSING)", "WindowListener via WindowAdapter.windowClosing()", "If bookingInProgress ask JOptionPane confirmation; dispose() only if Yes"],
 ["JFrame (life cycle)", "WindowEvent (OPENED, ACTIVATED, DEACTIVATED, ICONIFIED, DEICONIFIED, CLOSED)", "WindowAdapter overrides", "Logged (trace); windowClosed releases resources"]],
 widths=[1.4, 1.5, 1.8, 1.9], size=8.5)
H("Task 2.2 – Component hierarchy (2 marks)", 2)
img("report/diagrams/t2_tree.png", "Containment tree of the appointment desk with the AWT/Swing class used for every node.", maxw=6.4, scale=100)
H("Task 2.3 – Handler logic (3 marks)", 2)
code('''ALGORITHM RefreshDoctors                                    // (a) department changed
INPUT : selectedDept (String or none), directory : Map<String, List<Doctor>>
OUTPUT: doctor combo box shows only the doctors of selectedDept
BEGIN
  1. doctorBox.removeAllItems()
  2. IF selectedDept = none THEN statusLabel ← ""; RETURN
  3. list ← directory.get(selectedDept)            // O(1) hash lookup, no database call
  4. FOR EACH doctor d IN list DO doctorBox.addItem(d)
  5. statusLabel ← ""                              // clear any old message
END

ALGORITHM BookAppointment                                   // (b) Book pressed
INPUT : patientId, dept, doctor, slot, bookedSet
OUTPUT: confirmation or error message in statusLabel
BEGIN
  1. IF patientId does not match "P" followed by 4-8 digits THEN error ← "Patient ID must look like P1001"; GOTO 8
  2. IF dept = none   THEN error ← "Select a department";  GOTO 8
  3. IF doctor = none THEN error ← "Select a doctor";      GOTO 8
  4. IF slot = none   THEN error ← "Select a time slot";   GOTO 8
  5. key ← doctor.id + "|" + slot
  6. IF key IN bookedSet THEN error ← doctor + " already booked at " + slot; GOTO 8
  7. bookedSet.add(key); statusLabel ← "Appointment confirmed for ..." (green);
     bookingInProgress ← FALSE; clear patientId; RETURN
  8. statusLabel ← "ERROR: " + error (red); RETURN   // nothing is stored
END''')
img("Task02/screenshots/t2_2_cardiology_doctors.png", "Test of (a): department Cardiology lists exactly its three doctors.", maxw=3.1)
imgs_side([("Task02/screenshots/t2_3_paediatrics_doctors.png", "Test of (a): changing to Paediatrics replaces the list."),
           ("Task02/screenshots/t2_4_error_bad_id.png", "Test of (b) step 1: invalid patient ID rejected.")], maxw=3.0)
imgs_side([("Task02/screenshots/t2_5_confirmation.png", "Test of (b) step 7: confirmation shown."),
           ("Task02/screenshots/t2_6_conflict.png", "Test of (b) step 6: same doctor + slot refused.")], maxw=3.0)
H("Task 2.4 – Trace the event sequence (1 mark)", 2)
para("Actual call order printed by the running program (Task02/event_trace_output.txt):")
code(rd("Task02", "event_trace_output.txt"), size=8)
para("Reading the trace: the constructor builds the tree and registers the listeners; setVisible(true) makes the peer, after which the toolkit posts windowActivated and then windowOpened (this order is what the JDK produced; windowOpened fires only once, the first time the window is shown). Typing in the patient field fires the DocumentListener on every keystroke. Pressing the close button does not close the window – it only delivers windowClosing (setDefaultCloseOperation(DO_NOTHING_ON_CLOSE)); my handler asks for confirmation and calls dispose(), which produces windowDeactivated and finally windowClosed.")
table([["Applet method", "When called", "Equivalent in this Swing/AWT application"],
       ["init()", "Once, when the applet is loaded", "Constructor (builds components, registers listeners)"],
       ["start()", "After init and every time the page becomes visible", "setVisible(true) → windowOpened / windowDeiconified"],
       ["paint(Graphics)", "Whenever the area must be redrawn", "paint()/paintComponent() – identical, called by the system"],
       ["stop()", "When the page is hidden", "windowIconified / windowDeactivated"],
       ["destroy()", "When the applet is unloaded", "windowClosing (decision) → dispose() → windowClosed"]],
      widths=[1.3, 2.2, 3.0], size=8.5)
para("The main difference: an applet’s life cycle is called by the browser/appletviewer; for a frame the program itself creates the window, and the close/iconify life cycle is observed through WindowEvents rather than overridden methods.")
H("Alternative concept and complexity analysis", 2)
para("**Alternative:** fetch the doctor list from the database on every department change instead of caching it in Map<String, List<Doctor>>:")
code('''ALGORITHM RefreshDoctorsFromDB(dept)
  1. DISABLE doctorBox; show "loading..."
  2. rows ← SELECT name FROM doctors WHERE department = ?   // in a SwingWorker, not on the EDT
  3. ON COMPLETION (EDT): fill doctorBox with rows; ENABLE doctorBox''')
para("Measured with Task02/DoctorBench.java against MariaDB (d = 20 departments, m = 2 000 doctors; output: Task02/doctor_bench_output.txt):")
table([["Design", "Time per department change", "One-time cost", "Memory"],
       ["Map loaded once", "0.27 µs (O(1) lookup + copy of m/d = 100 items)", "127 ms to load all m rows at start-up", "O(m + d) – all 2 000 doctors stay in memory"],
       ["SQL query, connection kept open", "129 µs", "none", "O(m/d) – only the 100 rows returned (transient)"],
       ["SQL query, new connection each time", "1 232 µs (≈ 1.2 ms)", "none", "O(m/d) transient + connection"]],
      widths=[1.7, 2.1, 1.5, 1.7], size=8.5)
para("**Analysis.** Map: lookup is O(1) and filling the combo box is O(m/d) for both designs; the database design adds O(log m + m/d) index search plus network/connection latency, so it is roughly 480× (open connection) to 4 500× (new connection) slower per change in this test, and it must run in a background worker to keep the UI responsive. Memory: the Map keeps O(m) doctors (+ O(d) keys) for the whole session; per-query fetching holds only O(m/d) at a time. The Map is better for a small, rarely changing list (doctors); the query is better when the list is huge or changes often (a doctor leaves – the cache would be stale, so refresh the Map periodically or on a ‘Refresh’ action).")
pagebreak()

# ------------------------------------------------------------------ TASK 3
H("Task 3 – From Sketch to Layout (K4, 9 marks)")
H("Task 3.1 – Choose the layout managers (3 marks)", 2)
table([
 ["Container", "Layout manager", "Justification with respect to the resizing requirement"],
 ["Frame (whole screen)", "BorderLayout", "Only BorderLayout lets ONE region (CENTER) take all the extra space while NORTH and SOUTH keep their preferred height – exactly the required behaviour."],
 ["header Panel (NORTH)", "BorderLayout", "Stacks the title (NORTH) above the search row (CENTER); the header as a whole keeps its preferred height."],
 ["searchRow Panel", "FlowLayout (CENTER)", "TextField, Choice and Button should keep their natural size and stay in a row; FlowLayout never stretches components and re-centres them when the width changes (wraps only if the window becomes too narrow)."],
 ["Results area (CENTER)", "– (java.awt.List directly in CENTER)", "A component in CENTER is stretched in both directions; so the results area grows with the window."],
 ["footer Panel (SOUTH)", "BorderLayout", "Buttons row in CENTER and the status Label in SOUTH – both keep their preferred height."],
 ["buttonRow Panel", "FlowLayout (CENTER)", "Prev/Next/Reserve keep their size and stay centred."],
 ["Not used", "GridLayout, CardLayout", "GridLayout forces equal-sized cells (buttons would stretch and the results would not dominate). CardLayout shows one panel at a time – no use here (it would suit a multi-screen wizard)."]],
 widths=[1.5, 1.4, 3.6], size=8.5)
H("Task 3.2 – Nested containers (2 marks)", 2)
img("report/diagrams/t3_nested.png", "Nested panel structure with the layout manager of every container (red arrow = region that grows).", maxw=6.3, scale=100)
H("Task 3.3 – Implementation (3 marks)", 2)
para("Task03/LibrarySearch.java (AWT: Frame, Panel, Label, TextField, Choice, Button, java.awt.List). It contains a 16-book catalogue, a keyword + category search, paging (5 results per page, Prev/Next) and Reserve. Key structure:")
code('''setLayout(new BorderLayout());                       // Frame
Panel searchRow = new Panel(new FlowLayout(FlowLayout.CENTER, 8, 6));
searchRow.add(label); searchRow.add(query); searchRow.add(category); searchRow.add(search);
Panel header = new Panel(new BorderLayout());
header.add(title, BorderLayout.NORTH); header.add(searchRow, BorderLayout.CENTER);
Panel buttonRow = new Panel(new FlowLayout(FlowLayout.CENTER, 10, 6));
buttonRow.add(prev); buttonRow.add(next); buttonRow.add(reserve);
Panel footer = new Panel(new BorderLayout());
footer.add(buttonRow, BorderLayout.CENTER); footer.add(status, BorderLayout.SOUTH);
add(header, BorderLayout.NORTH); add(list, BorderLayout.CENTER); add(footer, BorderLayout.SOUTH);''')
H("Task 3.4 – Resizing behaviour (1 mark)", 2)
para("Task03/Task3Driver.java searched for “java”, reserved a book, then resized the window to three sizes and printed the size of one component of each region (Task03/resize_measurements.txt):")
code(rd("Task03", "resize_measurements.txt").replace("saved screenshots", "saved screenshots"), size=8)
table([["Window", "Search row (button 55×23)", "Results list", "Prev button / Status", "As designed?"],
       ["420 × 300", "unchanged 55 × 23", "418 × 147", "41×23 / 418×21", "Yes – list is the only region that differs"],
       ["720 × 460", "unchanged 55 × 23", "718 × 307 (+160 h)", "41×23 / 718×21", "Yes – list grew by exactly the extra height"],
       ["1050 × 640", "unchanged 55 × 23", "1048 × 487 (+340 h)", "41×23 / 1048×21", "Yes – every non-list region kept its height"]],
      widths=[0.9, 1.5, 1.5, 1.4, 1.5], size=8.5)
img("Task03/screenshots/t3_small_420x300.png", "Test 3.4 – small window 420×300: results list is short, search row and buttons unchanged.", maxw=3.6)
img("Task03/screenshots/t3_medium_720x460.png", "Test 3.4 – medium window 720×460: only the results list has grown.", maxw=5.2)
img("Task03/screenshots/t3_large_1050x640.png", "Test 3.4 – large window 1050×640: results list fills the extra space; the title bar, search row, buttons and status keep their size.", maxw=6.3)
H("Alternative concept and complexity analysis", 2)
para("**Alternative:** build the same screen with GridBagLayout (one panel, constraints with weightx/weighty/fill) or absolute positioning (setLayout(null) + setBounds). Both are implemented in Task03/LayoutVariants.java.")
code('''GridBagLayout : g.gridy=2; g.gridwidth=6; g.fill=BOTH; g.weightx=1; g.weighty=1; add(list, g);  // list takes spare space
Absolute      : list.setBounds(10, 75, 520, 200);   // fixed – never changes unless code recomputes it on resize''')
imgs_side([("Task03/screenshots/t3_alt_gridbag_1000x620.png", "GridBagLayout resized to 1000×620: resizes correctly, but needs weight/fill constraints per component."),
           ("Task03/screenshots/t3_alt_absolute_1000x620.png", "Absolute positioning resized to 1000×620: nothing moves or grows – the screen stays 540 px wide.")], maxw=3.1)
para("Measured layout time per validate() (Task03/layout_bench_output.txt; 5 000 repetitions after warm-up):")
table([["Design (real 9-component screen)", "Container objects", "Layout time (µs)"],
       ["Nested Border/Flow panels", "5", "158.8"], ["GridBagLayout", "1", "79.6"], ["Absolute (null)", "1", "23.3"]], widths=[3.2, 1.6, 1.6])
table([["n rows of [TextField][Button]", "Nested (µs)", "GridBag (µs)", "Absolute (µs)"],
       ["10", "169", "31", "21"], ["100", "1 799", "269", "139"], ["500", "7 574", "2 947", "1 833"], ["1 000", "16 328", "7 266", "6 697"]], widths=[2.4, 1.3, 1.3, 1.3])
para("**Analysis.** All three are O(n) in the number of components for one layout pass (every child is positioned once); GridBagLayout has the largest constant per component (it builds a grid matrix and does weight distribution – worst case it re-iterates slack distribution), BorderLayout/FlowLayout are cheap per component but nesting adds one container object, one layout call and one validation per panel: space is O(n + p) with p panels (5 containers here against 1). Absolute positioning does no computation (cheapest, 23 µs) but cannot adapt to resizing, fonts, DPI or locale. In my measurement nested panels were slowest because the cost is dominated by per-container overhead for tiny containers (a limitation: the numbers are from one JVM run and in micro-seconds, so absolute values are only indicative; the ordering stayed the same at n = 10…1 000). In practice 0.16 ms per resize is invisible, so the nested BorderLayout/FlowLayout design wins on readability and correct resizing with the fewest constraints to maintain.")
pagebreak()

# ------------------------------------------------------------------ TASK 4
H("Task 4 – Event-Handling Forensics (K4, 7 marks)")
para("All variants are in Task04/: broken/ (original), getgraphics/ (first defect fixed), final DrawPad.java (Complete-the-Code answer), buffered/ (alternative), override_demo/ (compile-time check). Task04/Task4Driver.java clicks three times with a java.awt.Robot, takes a screenshot, minimises the window (window manager), restores it and takes another screenshot; it also reads three pixels to report whether each dot is still visible (Task04/run_output.txt).")
H("Task 4.1 – Locate the defect (2 marks)", 2)
bullets(["**Click never handled:** the method is named mouseclicked (lower-case c). The listener interface method is mouseClicked. Java is case-sensitive, so the anonymous class merely adds an unrelated method; MouseAdapter’s empty mouseClicked() is what the system calls, so nothing is ever drawn.",
         "**Label never changes:** even if the method were called, the body only does count++; it never calls status.setText(...), so the label keeps its original text “Clicks: 0”. (The dot drawing is also fragile – see 4.2.)"])
para("Evidence (original program under the driver): label = “Clicks: 0” and dots visible 0/3 after three real mouse clicks.")
code(rd("Task04", "run_output.txt").split("[t4_getgraphics]")[0], size=8)
imgs_side([("Task04/screenshots/t4_broken_before_minimise.png", "Original program after 3 clicks: no dots, label still “Clicks: 0” (Task 4.1).")], maxw=3.2)
H("Task 4.2 – Failing interaction (2 marks)", 2)
para("After correcting only the name (getgraphics/DrawPad.java) the program counts clicks and shows dots – until the window is repainted. **Interaction:** (1) open the window, (2) click three times (three dots appear, label “Clicks: 3”), (3) minimise the window, (4) restore it. **Result:** the dots are gone, the label still says 3 (run_output.txt: dots visible 3/3 before, 0/3 after).")
para("**Why:** getGraphics() returns a temporary graphics context; pixels painted through it are not remembered anywhere. When a window is restored, uncovered or resized, the system calls paint(Graphics), and the program’s paint() does not draw the dots, so the window is cleared. All drawing must be done in paint() from stored state.")
code("\n".join(l for l in rd("Task04", "run_output.txt").split("\n") if l.startswith("[t4_getgraphics]")), size=8)
imgs_side([("Task04/screenshots/t4_getgraphics_before_minimise.png", "getGraphics() version, BEFORE minimise: 3 dots, “Clicks: 3”."),
           ("Task04/screenshots/t4_getgraphics_after_minimise.png", "Same version, AFTER minimise + restore: dots lost (Task 4.2).")], maxw=3.1)
H("Task 4.3 – Repair the program (2 marks) and Complete the Code", 2)
para("TODO 1 and TODO 2 completed in Task04/DrawPad.java (only the TODO regions were changed):")
code('''@Override public void mouseClicked(MouseEvent e) {        // TODO 1
    points.add(e.getPoint());                              // store the point
    status.setText("Clicks: " + points.size());            // update the label
    repaint();                                             // ask the system to call paint()
}
@Override public void paint(Graphics g) {                  // TODO 2
    for (Point p : points) g.fillOval(p.x - 3, p.y - 3, 6, 6);   // 6 x 6 circle centred on the point
}''')
code("\n".join(l for l in rd("Task04", "run_output.txt").split("\n") if l.startswith("[t4_final]")), size=8)
imgs_side([("Task04/screenshots/t4_final_before_minimise.png", "Repaired DrawPad BEFORE minimising: 3 dots, “Clicks: 3”."),
           ("Task04/screenshots/t4_final_after_minimise.png", "Repaired DrawPad AFTER minimise + restore: all 3 dots survive.")], maxw=3.1)
H("Task 4.4 – Prevent recurrence (1 mark)", 2)
para("@Override tells the compiler “this method must override or implement a method of a supertype”. With @Override on the misspelt method, compilation stops. I removed the annotation’s protection in the original and then put it back on the misspelt name (Task04/override_demo/DrawPad.java); recorded compiler message (Task04/override_compile_error.txt):")
code(rd("Task04", "override_compile_error.txt"), size=8.5)
para("(When the annotation is absent the same file compiles without any warning – which is exactly how the original defect reached the users.) A good habit: always write @Override on every listener/adapter method, and let the IDE flag missing ones.")
H("Alternative concept and complexity analysis", 2)
para("**Alternative:** draw each dot once onto an off-screen BufferedImage; paint() only copies the image (Task04/buffered/DrawPad.java, screenshots t4_buffered_*.png – dots also survive minimise/restore, 3/3).")
code('''mouseClicked: g2 ← canvas.createGraphics(); g2.fillOval(x-3, y-3, 6, 6); repaint()   // O(1) per click
paint(g)    : g.drawImage(canvas, 0, 0, null)                                          // copy one image''')
para("Measured with Task04/PaintBench.java at 1920×1080 (output: Task04/paint_bench_output.txt):")
code(rd("Task04", "paint_bench_output.txt"), size=8)
para("**Analysis.** Time per repaint: repainting stored points is O(n) (about 0.8 µs per dot: 10 dots 20 µs … 100 000 dots 83.9 ms – too slow for animation); copying the image costs O(w × h) = constant in n (1.8–4.5 ms here; its cost is mostly the full-screen copy). Break-even at n ≈ 2 000 clicks. Space: stored points need O(n) (24 bytes each ≈ 2.3 MB for 100 000 points); the image needs O(w × h) = 8.1 MB at 1920×1080 regardless of n – for a drawing pad with few clicks the point list is smaller and keeps the data (can undo, save as vector, resize without losing detail); for thousands of strokes the image gives constant paint time, but the pixels cannot be edited afterwards and the canvas must be re-created on a bigger window.")
pagebreak()

# ------------------------------------------------------------------ TASK 5
H("Task 5 – Same Screen, Different Event-Handling Styles (K5, 7 marks)")
H("Task 5.1 – Four implementations (3 marks)", 2)
para("Task05/v1_original/ConvA…ConvD.java: same currency converter (INR → USD/EUR, rates 0.012 / 0.011), the Convert action written in four styles; window closing by a WindowAdapter in all four.")
table([["Style", "How the Convert button is connected"],
       ["(a) frame implements ActionListener", "class ConvA extends JFrame implements ActionListener {…}\nconvertButton.addActionListener(this);\n@Override public void actionPerformed(ActionEvent e) { convert(); }"],
       ["(b) named inner class", "private class ConvertListener implements ActionListener { @Override public void actionPerformed(ActionEvent e) { convert(); } }\nconvertButton.addActionListener(new ConvertListener());"],
       ["(c) anonymous inner class", "convertButton.addActionListener(new ActionListener() {\n    @Override public void actionPerformed(ActionEvent e) { convert(); } });"],
       ["(d) lambda", "convertButton.addActionListener(e -> convert());"]], widths=[1.8, 4.7], size=8.5)
para("Verification (Task05/styles_verification_output.txt, driver clicks the real button): all four give “12.00 USD” for 1000 INR and “Invalid amount” for “xyz”.")
H("Task 5.2 – Change the requirement (2 marks)", 2)
para("New requirement: also convert on Enter in the amount field, and show the result in a dialog. Versions in Task05/v2_changed/. Verified with the driver: Enter → “24.00 USD” + 1 dialog; button → 1 dialog; in v1 Enter did nothing (“(nothing)”).")
code(rd("Task05", "change_effort.txt"), size=8.5)
table([["Style", "Wiring change only (add Enter trigger)", "Body change (dialog; same in all)", "Places edited", "Total lines (diff)"],
       ["(a) frame is listener", "+1 line: amount.addActionListener(this);", "+7 / −2 in convert()", "2", "+8 / −2"],
       ["(b) named inner class", "+3 / −1: keep listener in a variable and add to both sources", "same", "2", "+10 / −3"],
       ["(c) anonymous class", "+5 / −3: the anonymous object has to be assigned to a variable first (or the 3-line class duplicated)", "same", "3", "+11 / −4"],
       ["(d) lambda", "+3 / −1: store lambda in ActionListener variable and add to both sources", "same", "2", "+10 / −3"]],
      widths=[1.3, 2.3, 1.3, 0.7, 0.9], size=8.5)
para("Observation: the dialog change is the same in all four because the behaviour lives in convert(); the style only affects how the second trigger is attached. (a) is the cheapest because the frame already IS the listener for every source; (c) is the most awkward because the anonymous listener has no name to share.")
H("Task 5.3 – Compare the styles (2 marks)", 2)
table([["Criterion", "(a) frame implements", "(b) named inner class", "(c) anonymous class", "(d) lambda"],
       ["Readability", "Poor when several components: one actionPerformed needs if/else on e.getSource()", "Good – handler has a name, but more code", "OK for 1-3 lines; noisy if long", "Best for one-liners (e -> convert())"],
       ["Access to the frame’s fields", "Direct (it is the frame) – but exposes actionPerformed publicly", "Direct (inner classes see private members)", "Direct", "Direct (captures this)"],
       ["Reuse of the handler", "One handler for all sources only via source check", "Best – a named class can be attached to many components, even reused in other classes", "Poor – no name; must store in a variable", "Good via a variable or method reference"],
       ["Ease of change", "Every new button grows the same method", "Each handler is isolated", "Local; adding a trigger needs refactoring (measured)", "Smallest diff for simple changes"]],
      widths=[1.1, 1.4, 1.4, 1.3, 1.3], size=8)
para("**Recommendation for a large application:** lambdas / method references that only delegate to a controller or service method (button.addActionListener(e -> controller.convert())), combined with Swing Actions for commands that appear in several places (button, menu, shortcut). The handler stays one line, the logic is in a testable method, and there is no giant shared actionPerformed. Named inner classes are my second choice when a handler needs its own state or to be reused; implementing ActionListener on the frame does not scale (the single actionPerformed grows with every control, the same defect as Task 1).")
H("Complete the Code – Converter.java (lambda style)", 2)
code('''// TODO 1
ActionListener onConvert = e -> convert();
convertButton.addActionListener(onConvert);     // button
amount.addActionListener(onConvert);            // Enter key in the text field
// TODO 2
try {
    double inr = Double.parseDouble(amount.getText().trim());
    if (Double.isNaN(inr) || Double.isInfinite(inr) || inr < 0) throw new NumberFormatException();
    String cur = (String) target.getSelectedItem();
    result.setText(String.format("%.2f %s", inr * rate(cur), cur));
} catch (NumberFormatException ex) { result.setText("Invalid amount"); }''')
code(rd("Task05", "converter_output.txt"), size=8)
imgs_side([("Task05/screenshots/t5_valid_conversion.png", "Test: valid conversion – “5000” + Enter key → 60.00 USD (TODO 1 and 2)."),
           ("Task05/screenshots/t5_invalid_amount.png", "Test: invalid amount “abc” + Convert button → “Invalid amount”.")], maxw=3.0)
H("Alternative concept and complexity analysis", 2)
para("**Alternative:** a method reference (this::convert – needs a method with signature void convert(ActionEvent)) or ONE shared Swing Action used by the button, a menu item and a keyboard shortcut:")
code('''Action convertAction = new AbstractAction("Convert") {
    { putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("ctrl ENTER")); }
    @Override public void actionPerformed(ActionEvent e) { convert(); } };
button.setAction(convertAction); menuItem.setAction(convertAction);          // same object
amount.addActionListener(convertAction);                                      // Enter key
// (method reference form:)  button.addActionListener(this::convertEvent);''')
para("Measured with Task05/ListenerBench.java (retained heap per listener object, 100 000 instances; Task05/listener_bench_output.txt):")
table([["Style", "Listener objects for t triggers", "Heap per object (measured)", "Work to add a new trigger"],
       ["(a) frame implements", "0 extra (frame itself)", "–", "1 line, but the single actionPerformed must tell sources apart if actions differ"],
       ["(b) named inner class", "1 shared, or t if new instances", "15.6 B", "1 line (reuse the instance) – 3 lines to share"],
       ["(c) anonymous class", "t (one per registration) or 1 if stored", "16.2 B", "3-5 lines of refactoring"],
       ["(d) lambda", "t (or 1 if stored)", "16.5 B", "1-3 lines"],
       ["method reference this::convert", "t (a new lambda per use)", "≈ 16–32 B", "1 line"],
       ["ONE shared Action", "1 in total, for any t", "≈ 16–40 B once", "1 line per trigger (setAction); text, icon, shortcut and enabled-state are shared, so disabling the Action disables every trigger"]],
      widths=[1.5, 1.6, 1.2, 2.2], size=8.5)
para("**Analysis.** Space: the per-listener objects are 16 bytes each – O(t) for t triggers, versus O(1) for a single shared Action; both are negligible in absolute terms (the cost of 1 000 listeners ≈ 16 KB). The real saving is work and consistency: with a shared Action, adding a trigger is one call and enabling/disabling or renaming happens in one place; with the four styles each new trigger is another registration (and, for anonymous classes, a refactoring). Time cost at run time is O(1) dispatch in every style.")
pagebreak()

# ------------------------------------------------------------------ TASK 6
H("Task 6 – Design Challenge: Campus Event Registration Desktop Application (K5, 13 marks)")
H("Stage 1 – Interpret the problem (2 marks)", 2)
para("**Users:** (1) Student/volunteer – registers a student for an event through a form (data entry operator at the cultural-committee desk); (2) Committee member – views, filters and exports registrations. **Screens:** Main window (menu bar, event filter, paged registrations table, status bar), Registration dialog, Save-file chooser, About dialog. **Data:** events(id, name, event_date, venue); registrations(id, reg_no, student_name, email, event_id, registered_at). **Rules:** all form fields mandatory and valid; a student may register once per event (but for several different events); data stored in MySQL; UI must not freeze while the database is busy.")
table([["ID", "Testable requirement", "Test (Task06/test)"],
       ["R1", "Given a valid register number, name, email and event, when Register is pressed, a row is stored and the success message shows the new id.", "TC1; GUI demo t6_6"],
       ["R2", "Given an empty/short register number, empty or non-alphabetic name, malformed email or no event, nothing is stored and every violated rule is listed.", "TC invalid ×8; GUI demo t6_5"],
       ["R3", "Registering the same register number (any letter case) twice for the same event is rejected with a message naming the student and the event.", "TC2, TC4; GUI demo t6_7"],
       ["R4", "The same student may register for a different event.", "TC3"],
       ["R5", "The database itself refuses duplicates, even if the application check is bypassed.", "TC5 (UNIQUE constraint)"],
       ["R6", "The table shows at most 50 registrations per page; Prev/Next, a page counter and a total are shown.", "paging test; GUI t6_1"],
       ["R7", "Choosing an event in the filter shows only that event’s registrations.", "filter test; t6_4"],
       ["R8", "Export CSV writes every registration of the current filter to a file.", "export test; t6_9"],
       ["R9", "No database call runs on the event-dispatch thread; a busy indicator is shown while loading.", "design inspection (SwingWorker in every handler)"],
       ["R10", "User input is never concatenated into SQL (injection text is harmless).", "TC injection"]],
      widths=[0.4, 4.6, 1.5], size=8.5)
H("Stage 2 – Screens and event flow (2 marks)", 2)
para("Main window layout: menu bar (File ▸ Export CSV… Ctrl+E, Exit; Registrations ▸ New Registration… Ctrl+N, Refresh F5; Help ▸ About) · top panel (“Filter by event” JComboBox + “New Registration…” button) · centre JTable in JScrollPane · bottom: pager (Prev / Page x of y / Next), status label and an indeterminate JProgressBar.")
img("Task06/screenshots/t6_1_main_window.png", "Screen 1 – main window after start-up (requirement R6: 7 rows, page 1 of 1).", maxw=6.3)
imgs_side([("Task06/screenshots/t6_2_menu_bar_file_menu.png", "Menu bar – File menu (Stage 2: JMenuBar with accelerator keys)."),
           ("Task06/screenshots/t6_3_menu_bar_registrations_menu.png", "Menu bar – Registrations menu.")], maxw=3.15)
img("report/diagrams/t6_flow.png", "Flow between the screens and dialogs.", maxw=6.4, scale=100)
H("Stage 3 – Critical design decisions (2 marks)", 2)
table([["Concern", "Where it happens", "How"],
       ["Input validation", "service.RegistrationService.validate() – called by the dialog’s worker; the same rules protect any other client", "Regular expressions + presence checks; ALL errors are collected and shown together in the dialog (inline, red) instead of stopping at the first."],
       ["Duplicate checking", "Two levels: RegistrationService.register() → dao.exists(); and the database constraint UNIQUE(reg_no, event_id)", "The pre-check gives a friendly message; the constraint is the final guard against two desks registering the same student at the same moment (error 1062 → DuplicateRegistrationException)."],
       ["Database access", "Only dao.RegistrationDao (parameterised SQL, try-with-resources) through dao.Database", "UI and service contain no SQL and no java.sql imports, so the database can be replaced or mocked."],
       ["Keeping the EDT free", "ui.MainFrame.loadPage(), exportTo(), loadEventsThenPage() and RegisterDialog.submit() all use SwingWorker", "doInBackground() calls the service (blocking JDBC); done() runs on the EDT and only fills 50 table rows. A load token ignores answers of superseded requests; a JProgressBar shows ‘busy’; the Register button is disabled while saving."]],
      widths=[1.3, 2.6, 2.6], size=8.5)
H("Stage 4 – Classes and handlers (4 marks)", 2)
img("report/diagrams/t6_classes.png", "Class diagram – three layers: UI (Swing), service, data access (JDBC).", maxw=5.2, scale=120)
code('''ALGORITHM OnRegister                                         // Register button pressed (EDT)
INPUT : regNo, name, email, event (from the form)
OUTPUT: success/err message in the dialog; table refreshed on success
BEGIN
  1. registerButton.setEnabled(false); message ← "Saving..."
  2. START background worker (SwingWorker.doInBackground):
  3.    errors ← service.validate(regNo, name, email, event)
  4.    IF errors is not empty THEN THROW ValidationException(errors)
  5.    normalise: regNo ← upper(trim(regNo)); email ← lower(trim(email))
  6.    IF dao.exists(regNo, event.id) THEN THROW DuplicateRegistration
  7.    id ← dao.insert(regNo, name, email, event)   // UNIQUE constraint = last guard
  8.    RETURN id
  9. WHEN worker finishes (EDT, SwingWorker.done):
 10.    registerButton.setEnabled(true)
 11.    IF success THEN message ← "Registered (id)" (green); clear form; mainFrame.loadPage()
 12.    ELSE IF ValidationException THEN message ← all errors listed (red)
 13.    ELSE IF DuplicateRegistration THEN message ← "Duplicate: ..." (red)
 14.    ELSE message ← "Error: " + cause
END

ALGORITHM OnFilter                                           // filter combo / Prev / Next / F5
INPUT : selectedEvent (or ALL), pageIndex
OUTPUT: table shows one page
BEGIN
  1. token ← ++loadToken; progressBar.show(); status ← "Loading..."
  2. START background worker:
  3.    total ← dao.count(selectedEvent)
  4.    pageIndex ← clamp(pageIndex, 0, lastPage(total))
  5.    rows ← dao.findPage(selectedEvent, 50, pageIndex × 50)    // SELECT ... LIMIT 50 OFFSET ...
  6.    RETURN Page(rows, total, pageIndex)
  7. WHEN worker finishes (EDT):
  8.    IF token ≠ loadToken THEN RETURN                // an older request – ignore
  9.    table.clear(); FOR EACH row IN page.rows DO table.addRow(row)
 10.    pageLabel ← "Page i of n"; Prev.enabled ← i > 1; Next.enabled ← i < n
 11.    progressBar.hide(); status ← total + " registration(s)"
END''')
H("Stage 5 – Implementation and demonstration (3 marks)", 2)
para("Source: Task06/src/{model,dao,service,ui}; SQL: Task06/sql/schema.sql (tables, UNIQUE and FOREIGN KEY constraints, seed data) and sql/bench_seed.sql. Build/run: javac -d out $(find src -name '*.java'); java -cp out:mariadb-java-client.jar ui.App (for MySQL use Connector/J and -DDB_URL=jdbc:mysql://localhost:3306/campus_events). The application was run against MariaDB 10.11, a drop-in MySQL-protocol server.")
para("Headless test cases against the real database (Task06/test_output.txt): 17 checks, all PASS:", bold=True)
code(rd("Task06", "test_output.txt"), size=7.5)
para("GUI demonstration of the three required cases (Task06/demo_output.txt):", bold=True)
img("Task06/screenshots/t6_4_filter_music_fest.png", "Requirement R7: filter “Music Fest” shows only its 3 registrations; status bar “3 registration(s) for Music Fest”.", maxw=5.2)
imgs_side([("Task06/screenshots/t6_5_invalid_input_rejected.png", "INVALID input (R2): all four rule violations are listed; nothing stored."),
           ("Task06/screenshots/t6_6_normal_registration_success.png", "NORMAL registration (R1): saved, id 8, form cleared.")], maxw=3.15)
imgs_side([("Task06/screenshots/t6_7_duplicate_rejected.png", "DUPLICATE registration (R3): CSA092001 again for Cultural Night is rejected (typed in lower-case – still caught)."),
           ("Task06/screenshots/t6_8_table_shows_new_registration.png", "Main table refreshed automatically: now 8 registrations (new row id 8).")], maxw=3.15)
img("Task06/screenshots/t6_9_export_csv.png", "Requirement R8: Export – status bar “Exported 8 row(s) to registrations_export.csv” (file: Task06/registrations_export.csv).", maxw=5.2)
H("Alternative concept and complexity analysis", 2)
para("**Alternative:** load all registrations into the JTable at once (SELECT * FROM registrations; one table model with every row), instead of one page of 50 rows per SwingWorker run using LIMIT/OFFSET.")
code('''ALGORITHM LoadAll                                        ALGORITHM LoadPage(i)
 1. rows ← SELECT * FROM registrations   // N rows    1. rows ← SELECT ... ORDER BY id LIMIT 50 OFFSET 50·i
 2. FOR EACH row DO tableModel.addRow(row)             2. FOR EACH of ≤ 50 rows DO tableModel.addRow(row)
Time O(N) per load, Space O(N)                         Time O(OFFSET + 50) in the DB, O(50) on the EDT; Space O(50)''')
para("Measured with Task06/test/Task6Bench.java on 100 000 rows (sql/bench_seed.sql; output Task06/bench_output.txt, JVM heap limit 1 GB):")
code(rd("Task06", "bench_output.txt"), size=7.5)
table([["Approach (100 000 rows)", "Load time", "EDT blocked for", "Heap held by the table data", "Responsiveness"],
       ["Load everything", "617 ms (513 query/fetch/map + 104 table model)", "≈ 617 ms if done on the EDT; ≥ 104 ms even inside a SwingWorker (building the model)", "≈ 38.6 MB for 6 string columns (≈ 390 B per row, grows linearly with N)", "Window freezes during the load; time and memory grow with every new registration"],
       ["One page of 50 via SwingWorker", "140–205 ms in the worker thread (includes opening a new connection, ≈ 125 ms of it – see Task 2 bench); COUNT(*) 9.7 ms", "0.07–0.2 ms to fill 50 rows", "≈ 20 KB (50 rows) – constant", "Window always responsive; progress bar shown while the worker runs"]],
      widths=[1.3, 1.5, 1.4, 1.3, 1.0], size=8)
para("**Analysis.** Loading all rows is O(N) in time (fetch + build model) and O(N) in memory – 38.6 MB at 100 000 rows, ≈ 390 MB at one million, and the user waits for the whole load before seeing anything; a scrollable table with 100 000 rows is also unusable for finding a student. Paging is O(1) in what the UI handles (50 rows, ≈ 0.1 ms on the EDT) and O(1) memory in the UI; in the database LIMIT/OFFSET still has to skip OFFSET rows, so a deep page costs O(OFFSET + 50) (offset 99 950 was the slowest, 205 ms, vs 139 ms at 50 000) – for very deep paging a keyset query (WHERE id > lastId LIMIT 50) would remove that growth. The additional per-page cost in this measurement was dominated by opening a new JDBC connection for every call; a connection pool (e.g. HikariCP) would remove ≈ 125 ms, giving single-digit-millisecond pages. Result: paging with a SwingWorker keeps the window responsive at any N; loading everything makes load time, memory and freezes grow with N.")
pagebreak()

# ------------------------------------------------------------------ EVIDENCE INDEX
H("Evidence index – each screenshot linked to the requirement it demonstrates")
table([
 ["Screenshot file", "Requirement / test shown"],
 ["Task01/screenshots/t1_1_invalid_input.png", "1.1 #4, #9 – invalid amount handled with visible feedback"],
 ["Task01/screenshots/t1_2_processing_window_responsive.png", "1.1 #6, #11 – work off the EDT, Pay disabled while processing"],
 ["Task01/screenshots/t1_3_paid.png", "1.1 #9 – confirmation shown to the user"],
 ["Task01/screenshots/t1_4_receipt_dialog.png", "1.1 #3 – Receipt button now implemented"],
 ["Task02/screenshots/t2_1…t2_6", "2.3 (a) doctor list refresh; 2.3 (b) validation, confirmation and conflict message"],
 ["Task03/screenshots/t3_small/medium/large_*.png", "3.4 – results area grows, other regions keep size (three window sizes)"],
 ["Task03/screenshots/t3_alt_*.png", "Alternative – GridBagLayout vs absolute positioning on resize"],
 ["Task04/screenshots/t4_broken_*.png", "4.1 – original program: no dots, count stays 0"],
 ["Task04/screenshots/t4_getgraphics_*.png", "4.2 – dots disappear after minimise + restore"],
 ["Task04/screenshots/t4_final_*.png", "4.3 / Complete the Code – before and after minimising"],
 ["Task04/screenshots/t4_buffered_*.png", "Alternative – BufferedImage version survives minimise"],
 ["Task05/screenshots/t5_valid_conversion.png, t5_invalid_amount.png", "5 Complete the Code – valid conversion (Enter key path) and invalid amount"],
 ["Task06/screenshots/t6_1…t6_9", "Stage 2 main window and menus; Stage 5 invalid (R2), normal (R1), duplicate (R3), filter (R7), refresh, export (R8)"]],
 widths=[3.3, 3.2], size=8.5)

out = P("report", "CSA09_Assignment4_Report.docx")
doc.save(out); print("saved", out, "figures:", FIG[0])
