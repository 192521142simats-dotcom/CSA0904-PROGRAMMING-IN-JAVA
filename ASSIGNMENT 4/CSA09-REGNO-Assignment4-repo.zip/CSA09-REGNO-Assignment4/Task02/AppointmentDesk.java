import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.function.Supplier;

/**
 * Hospital outpatient appointment desk.
 * Every event method writes a line to the trace log so the call sequence can be shown (Task 2.4).
 */
public class AppointmentDesk extends JFrame {
    static final String[] SLOTS = {"09:00", "09:30", "10:00", "10:30", "11:00", "11:30"};
    static boolean trace = false;
    static void log(String s) { if (trace) System.out.println("  -> " + s); }

    private final DoctorDirectory directory;
    private final AppointmentService service = new AppointmentService();
    private final JTextField patientId = new JTextField(12);
    private final JComboBox<String> dept = new JComboBox<>();
    private final JComboBox<Doctor> doctor = new JComboBox<>();
    private final JComboBox<String> slot = new JComboBox<>(SLOTS);
    private final JButton book = new JButton("Book Appointment");
    private final JLabel status = new JLabel(" ");
    private boolean bookingInProgress = false;
    Supplier<Boolean> confirmClose = () -> JOptionPane.showConfirmDialog(this,
            "A booking is in progress. Close anyway?", "Confirm close", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;

    public AppointmentDesk(DoctorDirectory directory) {
        super("Outpatient Appointment Desk");
        log("AppointmentDesk() constructor");
        this.directory = directory;
        JPanel form = new JPanel(new GridLayout(5, 2, 6, 8));
        form.setBorder(BorderFactory.createEmptyBorder(12, 12, 4, 12));
        form.add(new JLabel("Patient ID:")); form.add(patientId);
        form.add(new JLabel("Department:")); form.add(dept);
        form.add(new JLabel("Doctor:")); form.add(doctor);
        form.add(new JLabel("Time slot:")); form.add(slot);
        form.add(new JLabel()); form.add(book);
        JPanel south = new JPanel(new FlowLayout(FlowLayout.LEFT));
        south.add(status);
        add(form, BorderLayout.CENTER); add(south, BorderLayout.SOUTH);

        dept.addItem(null);                       // "no selection" placeholder
        for (String d : directory.departments()) dept.addItem(d);
        dept.setSelectedIndex(0);

        // (1) ItemListener on the department combo box -> refresh doctors
        dept.addItemListener(e -> { if (e.getStateChange() == ItemEvent.SELECTED) refreshDoctors(); });
        // (2) ActionListener on Book button
        book.addActionListener(e -> bookAppointment());
        // (3) DocumentListener: typing a patient ID means a booking is in progress
        patientId.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            void changed() { bookingInProgress = !patientId.getText().isBlank(); log("DocumentListener.changedUpdate -> bookingInProgress=" + bookingInProgress); }
            public void insertUpdate(javax.swing.event.DocumentEvent e) { changed(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { changed(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { changed(); }
        });
        // (4) WindowListener (via WindowAdapter) - all lifecycle methods logged
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override public void windowOpened(WindowEvent e) { log("windowOpened"); }
            @Override public void windowActivated(WindowEvent e) { log("windowActivated"); }
            @Override public void windowDeactivated(WindowEvent e) { log("windowDeactivated"); }
            @Override public void windowIconified(WindowEvent e) { log("windowIconified"); }
            @Override public void windowDeiconified(WindowEvent e) { log("windowDeiconified"); }
            @Override public void windowClosing(WindowEvent e) {
                log("windowClosing (bookingInProgress=" + bookingInProgress + ")");
                if (!bookingInProgress || confirmClose.get()) dispose();
            }
            @Override public void windowClosed(WindowEvent e) { log("windowClosed"); }
        });
        pack();
        log("pack() done; constructor returns");
    }

    private void refreshDoctors() {
        log("ItemListener.itemStateChanged -> refreshDoctors()");
        doctor.removeAllItems();
        String d = (String) dept.getSelectedItem();
        if (d != null) for (Doctor x : directory.doctorsIn(d)) doctor.addItem(x);
        status.setText(" ");
    }

    private void bookAppointment() {
        log("ActionListener.actionPerformed -> bookAppointment()");
        String r = service.book(patientId.getText().trim(), (String) dept.getSelectedItem(),
                (Doctor) doctor.getSelectedItem(), (String) slot.getSelectedItem());
        boolean ok = r.startsWith("OK");
        status.setForeground(ok ? new Color(0, 110, 0) : Color.RED.darker());
        status.setText(r);
        if (ok) { bookingInProgress = false; patientId.setText(""); bookingInProgress = false; }
        pack();
    }

    // accessors for the driver
    JTextField patientIdField() { return patientId; }
    JComboBox<String> deptBox() { return dept; }
    JComboBox<Doctor> doctorBox() { return doctor; }
    JComboBox<String> slotBox() { return slot; }
    JButton bookButton() { return book; }
    JLabel statusLabel() { return status; }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AppointmentDesk(DoctorDirectory.sample()).setVisible(true));
    }
}
