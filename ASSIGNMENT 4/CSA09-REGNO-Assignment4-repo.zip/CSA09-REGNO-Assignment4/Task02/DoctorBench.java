import java.sql.*;
import java.util.*;

/** Compares the two designs for "department changed": cached Map lookup vs a SQL query each time. */
public class DoctorBench {
    public static void main(String[] a) throws Exception {
        String url = "jdbc:mariadb://localhost:3306/hospital";
        Map<String, List<String>> map = new HashMap<>();
        long t0 = System.nanoTime();
        try (Connection c = DriverManager.getConnection(url, "eventapp", "eventpass");
             Statement st = c.createStatement(); ResultSet rs = st.executeQuery("SELECT name, department FROM doctors")) {
            while (rs.next()) map.computeIfAbsent(rs.getString(2), k -> new ArrayList<>()).add(rs.getString(1));
        }
        double loadMs = (System.nanoTime() - t0) / 1e6;
        int d = map.size(), m = map.values().stream().mapToInt(List::size).sum();
        System.out.printf("d=%d departments, m=%d doctors; one-time load of the Map = %.1f ms%n", d, m, loadMs);

        int N = 2000;
        String[] depts = map.keySet().toArray(new String[0]);
        long sink = 0;
        for (int i = 0; i < 20000; i++) sink += map.get(depts[i % d]).size();          // warm-up
        t0 = System.nanoTime();
        for (int i = 0; i < N * 50; i++) sink += new ArrayList<>(map.get(depts[i % d])).size();
        double mapUs = (System.nanoTime() - t0) / 1e3 / (N * 50);

        try (Connection c = DriverManager.getConnection(url, "eventapp", "eventpass");
             PreparedStatement ps = c.prepareStatement("SELECT name FROM doctors WHERE department = ?")) {
            for (int i = 0; i < 200; i++) { ps.setString(1, depts[i % d]); try (ResultSet r = ps.executeQuery()) { while (r.next()) sink++; } }
            t0 = System.nanoTime();
            for (int i = 0; i < N; i++) {
                ps.setString(1, depts[i % d]);
                try (ResultSet r = ps.executeQuery()) { List<String> l = new ArrayList<>(); while (r.next()) l.add(r.getString(1)); sink += l.size(); }
            }
        }
        double dbOpenUs = (System.nanoTime() - t0) / 1e3 / N;

        t0 = System.nanoTime();
        int M = 200;
        for (int i = 0; i < M; i++) {
            try (Connection c = DriverManager.getConnection(url, "eventapp", "eventpass");
                 PreparedStatement ps = c.prepareStatement("SELECT name FROM doctors WHERE department = ?")) {
                ps.setString(1, depts[i % d]);
                try (ResultSet r = ps.executeQuery()) { while (r.next()) sink++; }
            }
        }
        double dbNewUs = (System.nanoTime() - t0) / 1e3 / M;
        System.out.printf("Per department change:%n  Map lookup (copy 100 items)       : %10.2f us%n  SQL query, connection kept open   : %10.2f us%n  SQL query, new connection each time: %9.2f us%n", mapUs, dbOpenUs, dbNewUs);
        System.out.printf("Memory: Map holds %d Doctor entries (O(m)); per-query design keeps only the %d rows of the selected department (O(m/d)).%n", m, m / d);
        System.out.println("(sink=" + sink + ")");
    }
}
