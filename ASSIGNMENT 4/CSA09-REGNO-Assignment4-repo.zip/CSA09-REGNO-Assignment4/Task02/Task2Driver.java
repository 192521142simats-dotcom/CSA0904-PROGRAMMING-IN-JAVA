import javax.swing.*;

/** Runs the desk, prints the event trace and captures screenshots. */
public class Task2Driver {
    static void ui(Runnable r) throws Exception { SwingUtilities.invokeAndWait(r); Shot.wait(250); }
    public static void main(String[] a) throws Exception {
        AppointmentDesk.trace = true;
        AppointmentDesk[] w = new AppointmentDesk[1];
        System.out.println("== open ==");
        ui(() -> { w[0] = new AppointmentDesk(DoctorDirectory.sample()); w[0].setLocation(100, 100);
                   System.out.println("  -> setVisible(true) called"); w[0].setVisible(true); });
        Shot.wait(600);
        Shot.capture(w[0], "screenshots/t2_1_initial.png");
        System.out.println("== select department Cardiology ==");
        ui(() -> w[0].deptBox().setSelectedItem("Cardiology"));
        Shot.capture(w[0], "screenshots/t2_2_cardiology_doctors.png");
        System.out.println("== change department to Paediatrics ==");
        ui(() -> w[0].deptBox().setSelectedItem("Paediatrics"));
        Shot.capture(w[0], "screenshots/t2_3_paediatrics_doctors.png");
        System.out.println("== book with bad patient id ==");
        ui(() -> { w[0].patientIdField().setText("12"); w[0].bookButton().doClick(); });
        Shot.capture(w[0], "screenshots/t2_4_error_bad_id.png");
        System.out.println("== valid booking ==");
        ui(() -> { w[0].patientIdField().setText("P10234"); w[0].bookButton().doClick(); });
        Shot.capture(w[0], "screenshots/t2_5_confirmation.png");
        System.out.println("== same doctor/slot again (conflict) ==");
        ui(() -> { w[0].patientIdField().setText("P20001"); w[0].bookButton().doClick(); });
        Shot.capture(w[0], "screenshots/t2_6_conflict.png");
        System.out.println("== close while booking in progress (user answers YES) ==");
        w[0].confirmClose = () -> { System.out.println("  -> confirm dialog shown, user clicks Yes"); return true; };
        ui(() -> w[0].dispatchEvent(new java.awt.event.WindowEvent(w[0], java.awt.event.WindowEvent.WINDOW_CLOSING)));
        Shot.wait(300);
        System.exit(0);
    }
}
