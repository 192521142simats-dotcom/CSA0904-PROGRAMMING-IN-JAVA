import java.util.*;

/** Validation + booking rules (no GUI code). */
public class AppointmentService {
    private final Set<String> booked = new HashSet<>();   // key: doctor|slot
    public String book(String patientId, String dept, Doctor doctor, String slot) {
        if (patientId == null || !patientId.matches("P\\d{4,8}")) return "ERROR: Patient ID must look like P1001 (P + 4-8 digits).";
        if (dept == null) return "ERROR: Select a department.";
        if (doctor == null) return "ERROR: Select a doctor.";
        if (slot == null) return "ERROR: Select a time slot.";
        if (!booked.add(doctor.id() + "|" + slot)) return "ERROR: " + doctor + " is already booked at " + slot + ".";
        return "OK: Appointment confirmed for " + patientId + " with " + doctor + " (" + dept + ") at " + slot + ".";
    }
}
