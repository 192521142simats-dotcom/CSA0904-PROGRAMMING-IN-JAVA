import java.util.*;

/** Loaded ONCE into Map<String, List<Doctor>>; department change = O(1) map lookup. */
public class DoctorDirectory {
    private final Map<String, List<Doctor>> byDept = new LinkedHashMap<>();
    public DoctorDirectory(List<Doctor> all) {
        for (Doctor d : all) byDept.computeIfAbsent(d.department(), k -> new ArrayList<>()).add(d);
    }
    public Set<String> departments() { return byDept.keySet(); }
    public List<Doctor> doctorsIn(String dept) { return byDept.getOrDefault(dept, List.of()); }

    public static DoctorDirectory sample() {
        List<Doctor> l = new ArrayList<>();
        String[][] data = {
            {"Cardiology", "Dr. Meera Nair", "Dr. R. Subramanian", "Dr. Anil Kapoor"},
            {"Orthopaedics", "Dr. S. Karthik", "Dr. Farah Khan"},
            {"Paediatrics", "Dr. Lakshmi Iyer", "Dr. John Mathew", "Dr. P. Devi"},
            {"Dermatology", "Dr. Aisha Rahman", "Dr. V. Gopal"}};
        int id = 1;
        for (String[] row : data) for (int i = 1; i < row.length; i++) l.add(new Doctor(id++, row[i], row[0]));
        return new DoctorDirectory(l);
    }
}
