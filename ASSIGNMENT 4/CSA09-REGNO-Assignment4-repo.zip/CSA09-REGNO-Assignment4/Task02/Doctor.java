public record Doctor(int id, String name, String department) {
    @Override public String toString() { return name; }
}
