CREATE DATABASE IF NOT EXISTS hospital;
USE hospital;
DROP TABLE IF EXISTS doctors;
CREATE TABLE doctors (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(60), department VARCHAR(40), INDEX(department));
-- 20 departments x 100 doctors = 2000 doctors
INSERT INTO doctors(name, department)
SELECT CONCAT('Dr. D', d.n, '-', m.n), CONCAT('Dept', d.n)
FROM (SELECT seq n FROM seq_1_to_20) d, (SELECT seq n FROM seq_1_to_100) m;
