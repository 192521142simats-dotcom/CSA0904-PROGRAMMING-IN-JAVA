import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/** Style (b): a named inner class. */
public class ConvB extends JFrame {
    private final JTextField amount = new JTextField(10);
    private final JComboBox<String> target = new JComboBox<>(new String[]{"USD", "EUR"});
    private final JLabel result = new JLabel(" ");
    private final JButton convertButton = new JButton("Convert");

    public ConvB() {
        super("Converter (b) named inner class");
        setLayout(new FlowLayout());
        add(new JLabel("INR")); add(amount); add(target); add(convertButton); add(result);
        ConvertListener listener = new ConvertListener();
        convertButton.addActionListener(listener);
        amount.addActionListener(listener);
        addWindowListener(new WindowAdapter() { @Override public void windowClosing(WindowEvent e) { dispose(); } });
        pack();
    }
    private class ConvertListener implements ActionListener {
        @Override public void actionPerformed(ActionEvent e) { convert(); }
    }

    private void convert() {
        try {
            double inr = Double.parseDouble(amount.getText().trim());
            String cur = (String) target.getSelectedItem();
            String text = String.format("%.2f %s", inr * (cur.equals("USD") ? 0.012 : 0.011), cur);
            result.setText(text);
            JOptionPane.showMessageDialog(this, text, "Result", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException ex) {
            result.setText("Invalid amount");
            JOptionPane.showMessageDialog(this, "Invalid amount", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    public static void main(String[] a) { SwingUtilities.invokeLater(() -> new ConvB().setVisible(true)); }
}
