import java.awt.event.*;
import java.util.*;
import java.util.function.Supplier;

/** Rough retained-heap cost per registered listener for each style (100,000 instances of each). */
public class ListenerBench {
    int hits;
    void convert() { hits++; }
    class Named implements ActionListener { @Override public void actionPerformed(ActionEvent e) { convert(); } }
    static long used() { for (int i = 0; i < 5; i++) { System.gc(); try { Thread.sleep(50); } catch (Exception e) { } } Runtime r = Runtime.getRuntime(); return r.totalMemory() - r.freeMemory(); }
    static void measure(String name, Supplier<ActionListener> s) {
        int n = 100_000; Object[] keep = new Object[n];
        long before = used();
        for (int i = 0; i < n; i++) keep[i] = s.get();
        long after = used();
        System.out.printf("%-42s %6.1f bytes per listener object%n", name, (after - before) / (double) n);
        if (keep[0] == null) System.out.println();
    }
    public static void main(String[] a) {
        ListenerBench b = new ListenerBench();
        measure("(b) named inner class (captures this)", () -> b.new Named());
        measure("(c) anonymous inner class (captures this)", () -> new ActionListener() { @Override public void actionPerformed(ActionEvent e) { b.convert(); } });
        measure("(d) lambda capturing this (e -> convert())", () -> e -> b.convert());
        measure("method reference b::convert-style (captures b)", () -> { Runnable r = b::convert; return e -> r.run(); });
        ActionListener shared = e -> b.convert();
        System.out.println("(d') ONE shared lambda/Action reused for button + Enter + menu item: 1 object total, regardless of triggers");
        System.out.println("(a) frame implements ActionListener: 0 extra objects (the frame is the listener)");
    }
}
