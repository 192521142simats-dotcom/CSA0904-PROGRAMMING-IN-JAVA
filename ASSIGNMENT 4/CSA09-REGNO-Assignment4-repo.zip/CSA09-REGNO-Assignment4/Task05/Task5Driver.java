import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;

/** (1) screenshots of Converter: valid + invalid; (2) verifies every style, before and after the change. */
public class Task5Driver {
    static <T> T find(Container c, Class<T> type) {
        for (Component x : c.getComponents()) {
            if (type.isInstance(x)) return type.cast(x);
            if (x instanceof Container cc) { T r = find(cc, type); if (r != null) return r; }
        }
        return null;
    }
    static JButton convertBtn(Container c) {
        for (Component x : c.getComponents()) {
            if (x instanceof JButton b && "Convert".equals(b.getText())) return b;
            if (x instanceof Container cc) { JButton r = convertBtn(cc); if (r != null) return r; }
        }
        return null;
    }
    static void ui(Runnable r) throws Exception { SwingUtilities.invokeAndWait(r); Shot.wait(250); }

    public static void main(String[] args) throws Exception {
        if (args[0].equals("shots")) {
            Converter[] w = new Converter[1];
            ui(() -> { w[0] = new Converter(); w[0].setLocation(100, 100); w[0].setVisible(true); });
            Shot.wait(500);
            ui(() -> { w[0].amountField().setText("5000"); w[0].amountField().postActionEvent(); });   // Enter key path
            System.out.println("5000 INR -> USD (Enter pressed): " + w[0].resultLabel().getText());
            Shot.capture(w[0], "screenshots/t5_valid_conversion.png");
            ui(() -> { w[0].amountField().setText("abc"); convertBtn(w[0].getContentPane()).doClick(); });
            System.out.println("'abc' (button clicked): " + w[0].resultLabel().getText());
            Shot.capture(w[0], "screenshots/t5_invalid_amount.png");
            ui(() -> { w[0].amountField().setText("1000"); w[0].targetBox().setSelectedItem("EUR"); convertBtn(w[0].getContentPane()).doClick(); });
            System.out.println("1000 INR -> EUR (button clicked): " + w[0].resultLabel().getText());
            System.exit(0);
        }
        // verify mode: arg1 = "v1" or "v2"
        boolean v2 = args[1].equals("v2");
        java.util.List<String> dialogs = java.util.Collections.synchronizedList(new java.util.ArrayList<>());
        new Thread(() -> { while (true) { Shot.wait(50);
            for (Window x : Window.getWindows()) if (x instanceof JDialog d && d.isShowing()) {
                JOptionPane p = find(d.getContentPane(), JOptionPane.class);
                dialogs.add(String.valueOf(p == null ? "?" : p.getMessage()));
                SwingUtilities.invokeLater(d::dispose); } } }) {{ setDaemon(true); }}.start();
        for (String n : new String[]{"ConvA", "ConvB", "ConvC", "ConvD"}) {
            JFrame[] f = new JFrame[1];
            ui(() -> { try { f[0] = (JFrame) Class.forName(n).getDeclaredConstructor().newInstance(); } catch (Exception e) { throw new RuntimeException(e); } f[0].setVisible(true); });
            JTextField tf = find(f[0].getContentPane(), JTextField.class);
            JButton bt = convertBtn(f[0].getContentPane());
            JLabel res = null;
            for (Component c : f[0].getContentPane().getComponents()) if (c instanceof JLabel l && !l.getText().equals("INR")) res = l;
            final JLabel rl = res;
            dialogs.clear();
            ui(() -> { tf.setText("1000"); bt.doClick(); });
            Shot.wait(400);
            String viaButton = rl.getText(); int d1 = dialogs.size(); dialogs.clear();
            ui(() -> { rl.setText(" "); tf.setText("2000"); tf.postActionEvent(); });
            Shot.wait(400);
            String viaEnter = rl.getText(); int d2 = dialogs.size();
            ui(() -> { tf.setText("xyz"); bt.doClick(); }); Shot.wait(400);
            System.out.printf("%s %s: button -> \"%s\" (dialogs=%d) | Enter -> \"%s\" (dialogs=%d) | invalid -> \"%s\"%n", n, v2 ? "v2" : "v1", viaButton, d1, viaEnter.isBlank() ? "(nothing)" : viaEnter, d2, rl.getText());
            ui(f[0]::dispose);
        }
        System.exit(0);
    }
}
