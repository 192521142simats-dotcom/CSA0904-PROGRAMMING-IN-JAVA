#!/bin/bash
# Usage: tools/xrun.sh <command...>   - runs a GUI command inside Xvfb with the openbox window manager.
Xvfb :99 -screen 0 1280x800x24 >/dev/null 2>&1 &
XP=$!
export DISPLAY=:99
sleep 1
openbox >/dev/null 2>&1 &
OP=$!
sleep 1
"$@" 2>&1 | grep -v "Picked up JAVA_TOOL_OPTIONS"
kill $OP $XP 2>/dev/null
