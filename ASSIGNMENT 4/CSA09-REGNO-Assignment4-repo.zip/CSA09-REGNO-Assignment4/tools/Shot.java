import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import javax.swing.SwingUtilities;

/** Screenshot helper used by the demo drivers (captures a window incl. its title bar). */
public class Shot {
    public static void wait(int ms) { try { Thread.sleep(ms); } catch (InterruptedException e) { } }

    public static void capture(Window w, String file) throws Exception {
        final Rectangle[] r = new Rectangle[1];
        Runnable calc = () -> {
            Insets in = w.getInsets();
            Point p = w.getLocationOnScreen();
            r[0] = new Rectangle(p.x - in.left, p.y - in.top, w.getWidth() + in.left + in.right, w.getHeight() + in.top + in.bottom);
        };
        if (SwingUtilities.isEventDispatchThread()) calc.run(); else SwingUtilities.invokeAndWait(calc);
        wait(300);
        Rectangle screen = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
        BufferedImage img = new Robot().createScreenCapture(r[0].intersection(screen));
        new File(file).getAbsoluteFile().getParentFile().mkdirs();
        ImageIO.write(img, "png", new File(file));
        System.out.println("saved " + file + " (" + img.getWidth() + "x" + img.getHeight() + ")");
    }
}
