import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public record Receipt(long id, String regNo, double amount, LocalDateTime paidAt) {
    @Override public String toString() {
        return String.format("RECEIPT #%d | Reg No: %s | Amount: Rs. %.2f | %s",
                id, regNo, amount, paidAt.format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss")));
    }
}
