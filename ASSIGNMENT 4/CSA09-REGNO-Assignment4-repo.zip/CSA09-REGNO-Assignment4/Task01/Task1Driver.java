import javax.swing.*;

/** Produces the Task 1 screenshots (validation error, in-progress, paid, receipt). */
public class Task1Driver {
    public static void main(String[] a) throws Exception {
        FeeService svc = new FeeService(new InMemoryPaymentRepository(1500));
        FeeWindow[] w = new FeeWindow[1];
        SwingUtilities.invokeAndWait(() -> { w[0] = new FeeWindow(svc); w[0].setLocation(100, 100); w[0].setVisible(true); });
        Shot.wait(600);
        run(() -> { w[0].regNoField().setText("CSA09"); w[0].amountField().setText("abc"); w[0].payButton().doClick(); });
        Shot.capture(w[0], "screenshots/t1_1_invalid_input.png");
        run(() -> { w[0].regNoField().setText("CSA091234"); w[0].amountField().setText("1500.50"); w[0].payButton().doClick(); });
        Shot.wait(200);
        Shot.capture(w[0], "screenshots/t1_2_processing_window_responsive.png");
        // prove the EDT is free during the 1.5 s "bank wait": a Swing timer still fires
        long[] ticks = {0};
        Timer t = new Timer(100, e -> ticks[0]++); t.start();
        Shot.wait(1800); t.stop();
        System.out.println("EDT ticks while payment was in progress: " + ticks[0] + " (non-zero = UI stayed responsive)");
        Shot.capture(w[0], "screenshots/t1_3_paid.png");
        new Thread(() -> { try { Shot.wait(800);
            Shot.capture(java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().getActiveWindow(), "screenshots/t1_4_receipt_dialog.png");
            SwingUtilities.invokeLater(() -> { for (java.awt.Window x : java.awt.Window.getWindows()) if (x instanceof JDialog) x.dispose(); });
        } catch (Exception ex) { ex.printStackTrace(); } }).start();
        run(() -> clickReceipt(w[0]));
        Shot.wait(1500);
        System.exit(0);
    }
    static void clickReceipt(JFrame f) { find(f.getContentPane(), "Receipt").doClick(); }
    static JButton find(java.awt.Container c, String text) {
        for (java.awt.Component x : c.getComponents()) {
            if (x instanceof JButton b && b.getText().equals(text)) return b;
            if (x instanceof java.awt.Container cc) { JButton r = find(cc, text); if (r != null) return r; }
        }
        return null;
    }
    static void run(Runnable r) throws Exception { SwingUtilities.invokeLater(r); Shot.wait(300); }
}
