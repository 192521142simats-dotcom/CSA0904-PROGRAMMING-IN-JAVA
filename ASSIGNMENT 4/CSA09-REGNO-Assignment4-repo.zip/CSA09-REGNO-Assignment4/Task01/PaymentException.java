/** Checked exception raised by the data/payment layer; the UI turns it into a message. */
public class PaymentException extends Exception {
    public PaymentException(String message, Throwable cause) { super(message, cause); }
    public PaymentException(String message) { super(message); }
}
