/** Headless tests - no window needed, which is the point of the redesign. */
public class FeeServiceTest {
    static int failed = 0;
    static void check(String name, boolean ok) { System.out.println((ok ? "PASS  " : "FAIL  ") + name); if (!ok) failed++; }

    public static void main(String[] args) throws Exception {
        InMemoryPaymentRepository repo = new InMemoryPaymentRepository(0);
        FeeService s = new FeeService(repo);
        check("valid input accepted", s.validate("CSA091234", "1500.50") == null);
        check("empty reg no rejected", s.validate("", "100") != null);
        check("bad reg no rejected", s.validate("a b", "100") != null);
        check("empty amount rejected", s.validate("CSA091234", "") != null);
        check("non-numeric amount rejected", s.validate("CSA091234", "abc") != null);
        check("negative amount rejected", s.validate("CSA091234", "-5") != null);
        check("NaN rejected", s.validate("CSA091234", "NaN") != null);
        check("huge amount rejected", s.validate("CSA091234", "9999999") != null);
        check("SQL-injection text rejected by validation", s.validate("x'); DROP TABLE fees;--", "10") != null);
        check("no receipt before payment", s.lastReceipt() == null);
        Receipt r = s.pay("CSA091234", "1500.50");
        check("pay returns receipt", r != null && r.amount() == 1500.50 && repo.count() == 1);
        check("lastReceipt remembered", s.lastReceipt() == r);
        try { s.pay("", "10"); check("invalid pay throws", false); }
        catch (PaymentException e) { check("invalid pay throws: " + e.getMessage(), repo.count() == 1); }

        if (args.length > 0 && args[0].equals("jdbc")) {
            FeeService js = new FeeService(new JdbcPaymentRepository("jdbc:mariadb://localhost:3306/fees_db", "eventapp", "eventpass"));
            Receipt jr = js.pay("CSA091234", "2500");
            check("JDBC pay stored row id=" + jr.id(), jr.id() > 0);
            Receipt inj = js.pay("CSA09INJ01", "1");
            check("JDBC second row id=" + inj.id(), inj.id() > jr.id());
        }
        System.out.println(failed == 0 ? "ALL TESTS PASSED" : failed + " TEST(S) FAILED");
        System.exit(failed);
    }
}
