import java.sql.*;

/** JDBC implementation: PreparedStatement (no SQL injection) and try-with-resources (no leaks). */
public class JdbcPaymentRepository implements PaymentRepository {
    private final String url, user, password;
    public JdbcPaymentRepository(String url, String user, String password) {
        this.url = url; this.user = user; this.password = password;
    }

    @Override public long save(String regNo, double amount) throws PaymentException {
        String sql = "INSERT INTO fees(reg_no, amount) VALUES (?, ?)";
        try (Connection c = DriverManager.getConnection(url, user, password);
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, regNo);
            ps.setDouble(2, amount);
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) { return keys.next() ? keys.getLong(1) : -1; }
        } catch (SQLException e) {
            throw new PaymentException("Payment could not be saved: " + e.getMessage(), e);
        }
    }
}
