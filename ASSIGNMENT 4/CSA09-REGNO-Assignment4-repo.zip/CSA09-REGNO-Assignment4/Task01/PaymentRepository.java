/** Persistence abstraction so FeeService can be tested without a database. */
public interface PaymentRepository {
    /** Stores a payment and returns its generated id. */
    long save(String regNo, double amount) throws PaymentException;
}
