import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * View only: collects input and shows results. One listener (Action) per button;
 * the payment runs in a SwingWorker so the window stays responsive.
 */
public class FeeWindow extends JFrame {
    private final JTextField regNo = new JTextField(15);
    private final JTextField amount = new JTextField(15);
    private final JLabel status = new JLabel(" ");
    private final JButton payBtn, clearBtn, receiptBtn;
    private final FeeService service;

    public FeeWindow(FeeService service) {
        super("Student Fee Payment");
        this.service = service;
        payBtn = new JButton(new AbstractAction("Pay") {
            @Override public void actionPerformed(ActionEvent e) { onPay(); }
        });
        clearBtn = new JButton(new AbstractAction("Clear") {
            @Override public void actionPerformed(ActionEvent e) { regNo.setText(""); amount.setText(""); show("", false); }
        });
        receiptBtn = new JButton(new AbstractAction("Receipt") {
            @Override public void actionPerformed(ActionEvent e) { onReceipt(); }
        });
        JPanel form = new JPanel(new GridLayout(2, 2, 6, 6));
        form.add(new JLabel("Register No:")); form.add(regNo);
        form.add(new JLabel("Amount (Rs.):")); form.add(amount);
        JPanel buttons = new JPanel(new FlowLayout());
        buttons.add(payBtn); buttons.add(clearBtn); buttons.add(receiptBtn);
        setLayout(new BorderLayout(8, 8));
        ((JComponent) getContentPane()).setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(form, BorderLayout.NORTH); add(buttons, BorderLayout.CENTER); add(status, BorderLayout.SOUTH);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        pack(); setMinimumSize(getSize());
    }

    private void onPay() {
        String err = service.validate(regNo.getText(), amount.getText());
        if (err != null) { show(err, true); return; }
        payBtn.setEnabled(false);
        show("Processing payment...", false);
        new SwingWorker<Receipt, Void>() {
            @Override protected Receipt doInBackground() throws Exception {
                return service.pay(regNo.getText(), amount.getText());
            }
            @Override protected void done() {
                payBtn.setEnabled(true);
                try { show("Payment successful - receipt #" + get().id(), false); }
                catch (Exception ex) { show("Payment failed: " + (ex.getCause() != null ? ex.getCause().getMessage() : ex.getMessage()), true); }
            }
        }.execute();
    }

    private void onReceipt() {
        Receipt r = service.lastReceipt();
        if (r == null) show("No payment has been made yet.", true);
        else JOptionPane.showMessageDialog(this, r.toString(), "Receipt", JOptionPane.INFORMATION_MESSAGE);
    }

    private void show(String msg, boolean error) {
        status.setForeground(error ? Color.RED.darker() : new Color(0, 110, 0));
        status.setText(msg);
    }

    JTextField regNoField() { return regNo; }
    JTextField amountField() { return amount; }
    JButton payButton() { return payBtn; }
    JLabel statusLabel() { return status; }

    public static void main(String[] args) {
        PaymentRepository repo = args.length > 0 && args[0].equals("jdbc")
                ? new JdbcPaymentRepository("jdbc:mariadb://localhost:3306/fees_db", "eventapp", "eventpass")
                : new InMemoryPaymentRepository(1500);
        SwingUtilities.invokeLater(() -> new FeeWindow(new FeeService(repo)).setVisible(true));
    }
}
