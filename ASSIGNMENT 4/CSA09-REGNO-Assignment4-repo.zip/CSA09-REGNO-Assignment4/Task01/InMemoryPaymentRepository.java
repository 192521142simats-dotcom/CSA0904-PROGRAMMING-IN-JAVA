import java.util.ArrayList;
import java.util.List;

/** Test/demo repository; optional delay simulates a slow bank confirmation. */
public class InMemoryPaymentRepository implements PaymentRepository {
    private final List<String> rows = new ArrayList<>();
    private final long delayMillis;
    public InMemoryPaymentRepository(long delayMillis) { this.delayMillis = delayMillis; }

    @Override public synchronized long save(String regNo, double amount) throws PaymentException {
        try { Thread.sleep(delayMillis); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); throw new PaymentException("Interrupted", e); }
        rows.add(regNo + "," + amount);
        return rows.size();
    }
    public synchronized int count() { return rows.size(); }
}
