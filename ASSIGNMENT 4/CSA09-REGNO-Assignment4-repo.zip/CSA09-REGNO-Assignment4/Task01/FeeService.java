import java.time.LocalDateTime;
import java.util.regex.Pattern;

/** Application logic: validation + payment. No AWT/Swing classes are used here. */
public class FeeService {
    private static final Pattern REG_NO = Pattern.compile("[A-Za-z0-9]{6,15}");
    public static final double MAX_AMOUNT = 500_000;

    private final PaymentRepository repository;
    private Receipt lastReceipt;

    public FeeService(PaymentRepository repository) { this.repository = repository; }

    /** @return null when valid, otherwise a user-readable message. */
    public String validate(String regNo, String amountText) {
        if (regNo == null || regNo.isBlank()) return "Register number is required.";
        if (!REG_NO.matcher(regNo.trim()).matches())
            return "Register number must be 6-15 letters/digits.";
        if (amountText == null || amountText.isBlank()) return "Amount is required.";
        double a;
        try { a = Double.parseDouble(amountText.trim()); }
        catch (NumberFormatException e) { return "Amount must be a number."; }
        if (Double.isNaN(a) || Double.isInfinite(a) || a <= 0) return "Amount must be greater than zero.";
        if (a > MAX_AMOUNT) return "Amount must not exceed " + (long) MAX_AMOUNT + ".";
        return null;
    }

    /** Validates and pays. Blocking - call from a background thread. */
    public Receipt pay(String regNo, String amountText) throws PaymentException {
        String error = validate(regNo, amountText);
        if (error != null) throw new PaymentException(error);
        double amount = Double.parseDouble(amountText.trim());
        long id = repository.save(regNo.trim(), amount);
        lastReceipt = new Receipt(id, regNo.trim(), amount, LocalDateTime.now());
        return lastReceipt;
    }

    /** @return the latest receipt, or null if nothing has been paid yet. */
    public Receipt lastReceipt() { return lastReceipt; }
}
