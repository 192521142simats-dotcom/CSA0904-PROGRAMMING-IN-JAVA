import java.util.*;
import java.util.function.IntConsumer;

/** Measures dispatching one event among k buttons: if-else chain on command vs per-button listener. */
public class DispatchBench {
    static long sink;
    public static void main(String[] a) {
        int[] ks = {3, 10, 100, 1000, 10000};
        int N = 2_000_000;
        System.out.printf("%-8s %-22s %-22s %-16s%n", "k", "if-else chain (ns/ev)", "own listener (ns/ev)", "objects (k)");
        for (int k : ks) {
            String[] cmds = new String[k];
            for (int i = 0; i < k; i++) cmds[i] = "Cmd" + i;
            IntConsumer[] listeners = new IntConsumer[k];
            for (int i = 0; i < k; i++) { final int id = i; listeners[i] = x -> sink += id + x; }
            // worst case for chain: last command
            String last = cmds[k - 1];
            for (int w = 0; w < 3; w++) { chain(cmds, last, N / 4); direct(listeners, k - 1, N / 4); }
            long t0 = System.nanoTime(); chain(cmds, last, N); long t1 = System.nanoTime();
            direct(listeners, k - 1, N); long t2 = System.nanoTime();
            System.out.printf("%-8d %-22.2f %-22.2f %-16d%n", k, (t1 - t0) / (double) N, (t2 - t1) / (double) N, k);
        }
        System.out.println("(sink=" + sink + ")");
    }
    static void chain(String[] cmds, String cmd, int n) {
        for (int j = 0; j < n; j++) {
            for (int i = 0; i < cmds.length; i++) {
                if (cmds[i].equals(cmd)) { sink += i; break; }
            }
        }
    }
    static void direct(IntConsumer[] l, int idx, int n) { for (int j = 0; j < n; j++) l[idx].accept(j); }
}
