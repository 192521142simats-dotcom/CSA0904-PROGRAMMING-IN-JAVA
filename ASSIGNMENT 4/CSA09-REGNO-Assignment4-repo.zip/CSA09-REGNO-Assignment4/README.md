# CSA09 – Programming in Java – Assignment 4 (CO4: Event-Driven GUI Design)

| | |
|---|---|
| **Name** | [YOUR NAME] |
| **Register number** | [YOUR REGISTER NUMBER] |
| **Java version** | OpenJDK 21 (`javac 21.0.12`) – any JDK 17+ works |
| **Report** | `report/CSA09_Assignment4_Report.docx` (and `.pdf`) |

Every program in this repository was compiled and executed; screenshots were taken from the running windows
(Xvfb virtual display + openbox window manager) and are linked to the requirement they show in the report's *Evidence index*.
Each task has its own folder with source, outputs (`*_output.txt`) and `screenshots/`.

## Prerequisites
* JDK 17+ (`java`, `javac`).
* Tasks 1 (JDBC test only) and 6 need a MySQL-compatible server and its JDBC driver
  (tested with MariaDB 10.11 + `mariadb-java-client`; for MySQL use Connector/J and `-DDB_URL=jdbc:mysql://localhost:3306/campus_events`).
* Screenshot drivers use `java.awt.Robot`; on a headless machine run them with `tools/xrun.sh <command>` (needs `Xvfb` and `openbox`).

```bash
# one-time: compile the screenshot helper and create the database user
javac -d tools tools/Shot.java
mysql -uroot -e "CREATE USER 'eventapp'@'localhost' IDENTIFIED BY 'eventpass'; GRANT ALL ON *.* TO 'eventapp'@'localhost';"
JDBC=/usr/share/java/mariadb-java-client.jar     # path to your JDBC driver jar
```

## Task 1 – GUI design review (`Task01/`)
```bash
cd Task01 && javac -cp .:../tools *.java
mysql -uroot < fees.sql
java -cp .:$JDBC FeeServiceTest jdbc          # 15 headless tests (incl. 2 real INSERTs)
java DispatchBench                            # if-else chain vs own listener, k = 3 … 10000
java FeeWindow                                # the window (add argument jdbc to use MySQL)
../tools/xrun.sh java -cp .:../tools Task1Driver   # screenshots
```
Result: redesign = `FeeWindow` (view) + `FeeService` (rules) + `PaymentRepository` (JDBC / in-memory); all tests pass; the window stays responsive during a 1.5 s payment (17 EDT ticks).

## Task 2 – Appointment desk (`Task02/`)
```bash
cd Task02 && javac -cp .:../tools:$JDBC *.java && mysql -uroot < hospital.sql
../tools/xrun.sh java -cp .:../tools Task2Driver      # event trace + 6 screenshots
java -cp .:$JDBC DoctorBench                          # Map vs SQL query per department change
```
Result: event trace in `event_trace_output.txt`; Map lookup 0.27 µs vs 129 µs (open connection) vs 1 232 µs (new connection).

## Task 3 – Library search layout (`Task03/`)
```bash
cd Task03 && javac -cp .:../tools *.java
java LibrarySearch                                    # the screen
../tools/xrun.sh java -cp .:../tools Task3Driver      # three window sizes + measurements
java LayoutVariants                                   # nested vs GridBag vs absolute timing
../tools/xrun.sh java -cp .:../tools Task3VariantShots
```
Result: only the results list grows (418×147 → 718×307 → 1048×487); search row, buttons and status keep their size.

## Task 4 – DrawPad forensics (`Task04/`)
```bash
cd Task04
for v in broken getgraphics buffered; do javac -d $v $v/DrawPad.java; done
javac -d final DrawPad.java; javac -cp ../tools -d driver Task4Driver.java
../tools/xrun.sh java -cp final:driver:../tools Task4Driver t4_final      # also: broken / getgraphics / buffered
javac override_demo/DrawPad.java                      # compiler error: "method does not override or implement a method from a supertype"
javac PaintBench.java && java -Djava.awt.headless=true PaintBench
```
Result: original 0/3 dots and “Clicks: 0”; `getGraphics()` version loses the dots after minimise (3/3 → 0/3); repaired version keeps them (3/3 → 3/3).

## Task 5 – Four event-handling styles (`Task05/`)
```bash
cd Task05
javac -d v1_original/classes v1_original/*.java; javac -d v2_changed/classes v2_changed/*.java
javac -cp ../tools -d . Converter.java Task5Driver.java
../tools/xrun.sh java -cp .:../tools Task5Driver shots          # Complete-the-Code screenshots
../tools/xrun.sh java -cp v1_original/classes:.:../tools Task5Driver verify v1
../tools/xrun.sh java -cp v2_changed/classes:.:../tools Task5Driver verify v2
```
Result: all four styles behave identically; change effort is in `change_effort.txt`.

## Task 6 – Campus Event Registration (`Task06/`)
```bash
cd Task06
mysql -uroot < sql/schema.sql                          # database campus_events + seed data
mkdir -p out && javac -cp ../tools -d out $(find src -name '*.java')
java -cp out:$JDBC ui.App                              # run the application
javac -cp out -d out test/Task6ServiceTest.java && java -cp out:$JDBC Task6ServiceTest     # 17 test cases
javac -cp out:../tools -d out test/Task6Driver.java && ../tools/xrun.sh java -cp out:../tools:$JDBC Task6Driver   # GUI demo
mysql -uroot < sql/bench_seed.sql                      # 100 000 rows in campus_events_bench
javac -cp out -d out test/Task6Bench.java && java -Xmx1g -cp out:$JDBC Task6Bench
```
Result: normal, invalid and duplicate registrations demonstrated; load-all 617 ms / 38.6 MB vs 50-row page 0.1 ms on the event thread.

## Commit history
One commit per task (`git log --oneline`).
