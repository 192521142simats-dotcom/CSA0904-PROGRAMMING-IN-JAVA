import java.awt.*;
import javax.swing.SwingUtilities;

/** Resizes the screen to three sizes, records region sizes and takes screenshots (Task 3.4). */
public class Task3Driver {
    public static void main(String[] a) throws Exception {
        LibrarySearch[] w = new LibrarySearch[1];
        SwingUtilities.invokeAndWait(() -> { w[0] = new LibrarySearch(); w[0].setLocation(60, 60); w[0].setVisible(true); });
        Shot.wait(600);
        SwingUtilities.invokeAndWait(() -> { w[0].queryField().setText("java"); w[0].searchButton().dispatchEvent(new java.awt.event.ActionEvent(w[0].searchButton(), java.awt.event.ActionEvent.ACTION_PERFORMED, "Search")); });
        SwingUtilities.invokeAndWait(() -> { w[0].resultList().select(1); w[0].reserveButton().dispatchEvent(new java.awt.event.ActionEvent(w[0].reserveButton(), java.awt.event.ActionEvent.ACTION_PERFORMED, "Reserve")); });
        int[][] sizes = {{420, 300}, {720, 460}, {1050, 640}};
        String[] names = {"small_420x300", "medium_720x460", "large_1050x640"};
        System.out.printf("%-16s %-18s %-18s %-18s %-18s%n", "window", "Search button", "Results list", "Prev button", "Status label");
        for (int i = 0; i < 3; i++) {
            final int k = i;
            SwingUtilities.invokeAndWait(() -> { w[0].setSize(sizes[k][0], sizes[k][1]); w[0].validate(); });
            Shot.wait(500);
            StringBuilder sb = new StringBuilder();
            for (Component c : w[0].regions()) sb.append(String.format("%-19s", c.getWidth() + " x " + c.getHeight()));
            System.out.printf("%-16s %s%n", sizes[i][0] + "x" + sizes[i][1], sb);
            Shot.capture(w[0], "screenshots/t3_" + names[i] + ".png");
        }
        System.exit(0);
    }
}
