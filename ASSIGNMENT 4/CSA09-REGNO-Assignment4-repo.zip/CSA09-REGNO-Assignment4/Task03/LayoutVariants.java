import java.awt.*;
import java.util.concurrent.atomic.AtomicInteger;

/** Same screen built three ways: nested Border/Flow panels, GridBagLayout, and absolute positioning. */
public class LayoutVariants {
    static int containers(Container c) {
        int n = 1;
        for (Component x : c.getComponents()) if (x instanceof Container cc) n += containers(cc);
        return n;
    }

    static Frame nested() {
        Frame f = new Frame("nested");
        f.setLayout(new BorderLayout());
        Panel header = new Panel(new BorderLayout());
        header.add(new Label("TITLE", Label.CENTER), BorderLayout.NORTH);
        Panel row = new Panel(new FlowLayout());
        row.add(new TextField(18)); row.add(new Choice()); row.add(new Button("Search"));
        header.add(row, BorderLayout.CENTER);
        Panel footer = new Panel(new BorderLayout());
        Panel buttons = new Panel(new FlowLayout());
        buttons.add(new Button("Prev")); buttons.add(new Button("Next")); buttons.add(new Button("Reserve"));
        footer.add(buttons, BorderLayout.CENTER); footer.add(new Label("status"), BorderLayout.SOUTH);
        f.add(header, BorderLayout.NORTH); f.add(new java.awt.List(8), BorderLayout.CENTER); f.add(footer, BorderLayout.SOUTH);
        return f;
    }

    static Frame gridBag() {
        Frame f = new Frame("gridbag");
        f.setLayout(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(4, 4, 4, 4);
        g.gridx = 0; g.gridy = 0; g.gridwidth = 6; g.fill = GridBagConstraints.HORIZONTAL; g.weightx = 1;
        f.add(new Label("TITLE", Label.CENTER), g);
        g.gridy = 1; g.gridwidth = 1; g.fill = GridBagConstraints.NONE; g.weightx = 0;
        g.gridx = 0; f.add(new TextField(18), g); g.gridx = 1; f.add(new Choice(), g); g.gridx = 2; f.add(new Button("Search"), g);
        g.gridx = 0; g.gridy = 2; g.gridwidth = 6; g.fill = GridBagConstraints.BOTH; g.weightx = 1; g.weighty = 1;
        f.add(new java.awt.List(8), g);
        g.gridy = 3; g.gridwidth = 1; g.weighty = 0; g.weightx = 0; g.fill = GridBagConstraints.NONE;
        g.gridx = 0; f.add(new Button("Prev"), g); g.gridx = 1; f.add(new Button("Next"), g); g.gridx = 2; f.add(new Button("Reserve"), g);
        g.gridx = 0; g.gridy = 4; g.gridwidth = 6; g.fill = GridBagConstraints.HORIZONTAL; f.add(new Label("status"), g);
        return f;
    }

    static Frame absolute() {
        Frame f = new Frame("absolute");
        f.setLayout(null);
        Label t = new Label("TITLE", Label.CENTER); t.setBounds(0, 0, 540, 30);
        TextField tf = new TextField(18); tf.setBounds(20, 40, 200, 24);
        Choice c = new Choice(); c.setBounds(230, 40, 120, 24);
        Button s = new Button("Search"); s.setBounds(360, 40, 70, 24);
        java.awt.List l = new java.awt.List(8); l.setBounds(10, 75, 520, 200);
        Button p = new Button("Prev"), n = new Button("Next"), r = new Button("Reserve");
        p.setBounds(150, 285, 60, 24); n.setBounds(220, 285, 60, 24); r.setBounds(290, 285, 80, 24);
        Label st = new Label("status"); st.setBounds(10, 315, 520, 20);
        for (Component x : new Component[]{t, tf, c, s, l, p, n, r, st}) f.add(x);
        return f;
    }

    /** Wide panel with n copies of the search row to see how layout time scales with component count. */
    static double layoutMicros(Frame f, int reps) {
        f.setSize(900, 600); f.addNotify();
        for (int i = 0; i < 300; i++) { f.invalidate(); f.validate(); }
        long t0 = System.nanoTime();
        for (int i = 0; i < reps; i++) { f.setSize(900 + (i % 2), 600); f.invalidate(); f.validate(); }
        return (System.nanoTime() - t0) / 1e3 / reps;
    }

    static Frame scaled(String kind, int rows) {
        Frame f = new Frame(kind);
        if (kind.equals("nested")) {
            f.setLayout(new GridLayout(rows, 1));
            for (int i = 0; i < rows; i++) { Panel p = new Panel(new FlowLayout()); p.add(new TextField(8)); p.add(new Button("B")); f.add(p); }
        } else if (kind.equals("gridbag")) {
            f.setLayout(new GridBagLayout());
            GridBagConstraints g = new GridBagConstraints(); g.weightx = 1;
            for (int i = 0; i < rows; i++) { g.gridy = i; g.gridx = 0; f.add(new TextField(8), g); g.gridx = 1; f.add(new Button("B"), g); }
        } else {
            f.setLayout(null);
            for (int i = 0; i < rows; i++) { TextField t = new TextField(8); t.setBounds(10, i * 4, 100, 3); Button b = new Button("B"); b.setBounds(120, i * 4, 50, 3); f.add(t); f.add(b); }
        }
        return f;
    }

    public static void main(String[] args) throws Exception {
        System.out.println("== Real screen (9 components) ==");
        System.out.printf("%-10s %-12s %-22s%n", "design", "containers", "layout time (us/validate)");
        Object[][] designs = {{"nested", nested()}, {"gridbag", gridBag()}, {"absolute", absolute()}};
        for (Object[] d : designs) {
            Frame f = (Frame) d[1];
            System.out.printf("%-10s %-12d %-22.1f%n", d[0], containers(f), layoutMicros(f, 5000));
        }
        System.out.println("\n== Scaling: n rows of [TextField][Button] ==");
        System.out.printf("%-8s %-14s %-14s %-14s%n", "rows n", "nested (us)", "gridbag (us)", "absolute (us)");
        for (int n : new int[]{10, 100, 500, 1000}) {
            double a = layoutMicros(scaled("nested", n), 300), b = layoutMicros(scaled("gridbag", n), 300), c = layoutMicros(scaled("absolute", n), 300);
            System.out.printf("%-8d %-14.1f %-14.1f %-14.1f%n", n, a, b, c);
        }
        System.exit(0);
    }
}
