import java.awt.*;
/** Screenshots showing how the absolute-position design fails to resize. */
public class Task3VariantShots {
    public static void main(String[] a) throws Exception {
        for (String kind : new String[]{"gridbag", "absolute"}) {
            Frame f = kind.equals("gridbag") ? LayoutVariants.gridBag() : LayoutVariants.absolute();
            f.setSize(560, 380); f.setLocation(60, 60); f.setVisible(true); Shot.wait(500);
            f.setSize(1000, 620); f.validate(); Shot.wait(500);
            Shot.capture(f, "screenshots/t3_alt_" + kind + "_1000x620.png");
            f.dispose();
        }
        System.exit(0);
    }
}
