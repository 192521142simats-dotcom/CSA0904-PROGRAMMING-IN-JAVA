import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Campus Library Search screen (AWT).
 *
 * Frame                      BorderLayout
 *  |- NORTH   Panel header   BorderLayout
 *  |    |- NORTH  Label title
 *  |    '- CENTER Panel searchRow  FlowLayout  [TextField][Choice][Search]
 *  |- CENTER  List results   (takes ALL extra space)
 *  '- SOUTH   Panel footer   BorderLayout
 *       |- CENTER Panel buttonRow FlowLayout   [Prev][Next][Reserve]
 *       '- SOUTH  Label status
 */
public class LibrarySearch extends Frame {
    record Book(String title, String author, String category) { }
    static final Book[] CATALOGUE = {
        new Book("Head First Java", "Sierra & Bates", "Computer Science"),
        new Book("Effective Java", "Joshua Bloch", "Computer Science"),
        new Book("Introduction to Algorithms", "Cormen et al.", "Computer Science"),
        new Book("Database System Concepts", "Silberschatz", "Computer Science"),
        new Book("Operating System Concepts", "Galvin", "Computer Science"),
        new Book("Java: The Complete Reference", "Herbert Schildt", "Computer Science"),
        new Book("Engineering Mathematics", "B. S. Grewal", "Mathematics"),
        new Book("Linear Algebra Done Right", "Sheldon Axler", "Mathematics"),
        new Book("Discrete Mathematics", "Kenneth Rosen", "Mathematics"),
        new Book("Calculus", "James Stewart", "Mathematics"),
        new Book("Fundamentals of Physics", "Halliday & Resnick", "Physics"),
        new Book("Concepts of Modern Physics", "Arthur Beiser", "Physics"),
        new Book("Wings of Fire", "A. P. J. Abdul Kalam", "Biography"),
        new Book("The Story of My Experiments with Truth", "M. K. Gandhi", "Biography"),
        new Book("Digital Design", "M. Morris Mano", "Electronics"),
        new Book("Microelectronic Circuits", "Sedra & Smith", "Electronics"),
    };
    static final int PAGE = 5;

    private final TextField query = new TextField(18);
    private final Choice category = new Choice();
    private final Button search = new Button("Search");
    private final java.awt.List list = new java.awt.List(8, false);
    private final Button prev = new Button("Prev"), next = new Button("Next"), reserve = new Button("Reserve");
    private final Label status = new Label("Enter a keyword and press Search.");
    private final List<Book> hits = new ArrayList<>();
    private int page = 0;


    public LibrarySearch() {
        super("Campus Library");
        setLayout(new BorderLayout());

        Label title = new Label("CAMPUS LIBRARY SEARCH", Label.CENTER);
        title.setFont(new Font("SansSerif", Font.BOLD, 18));
        title.setBackground(new Color(30, 60, 120)); title.setForeground(Color.WHITE);

        category.add("All");
        for (String c : new String[]{"Computer Science", "Mathematics", "Physics", "Biography", "Electronics"}) category.add(c);
        Panel searchRow = new Panel(new FlowLayout(FlowLayout.CENTER, 8, 6));
        searchRow.add(new Label("Search:")); searchRow.add(query); searchRow.add(category); searchRow.add(search);
        Panel header = new Panel(new BorderLayout());
        header.add(title, BorderLayout.NORTH); header.add(searchRow, BorderLayout.CENTER);

        Panel buttonRow = new Panel(new FlowLayout(FlowLayout.CENTER, 10, 6));
        buttonRow.add(prev); buttonRow.add(next); buttonRow.add(reserve);
        Panel footer = new Panel(new BorderLayout());
        footer.add(buttonRow, BorderLayout.CENTER); footer.add(status, BorderLayout.SOUTH);

        add(header, BorderLayout.NORTH);
        add(list, BorderLayout.CENTER);
        add(footer, BorderLayout.SOUTH);

        ActionListener doSearch = e -> runSearch();
        search.addActionListener(doSearch);
        query.addActionListener(doSearch);
        prev.addActionListener(e -> { if (page > 0) { page--; showPage(); } });
        next.addActionListener(e -> { if ((page + 1) * PAGE < hits.size()) { page++; showPage(); } });
        reserve.addActionListener(e -> reserveSelected());
        addWindowListener(new WindowAdapter() { @Override public void windowClosing(WindowEvent e) { dispose(); } });
        updateButtons();
        setSize(560, 380);
    }

    private void runSearch() {
        String q = query.getText().trim().toLowerCase();
        String cat = category.getSelectedItem();
        hits.clear();
        for (Book b : CATALOGUE) {
            boolean catOk = cat.equals("All") || b.category().equals(cat);
            boolean textOk = q.isEmpty() || b.title().toLowerCase().contains(q) || b.author().toLowerCase().contains(q);
            if (catOk && textOk) hits.add(b);
        }
        page = 0;
        showPage();
        status.setText(hits.isEmpty() ? "No books found." : hits.size() + " book(s) found.");
    }

    private void showPage() {
        list.removeAll();
        for (int i = page * PAGE; i < Math.min(hits.size(), (page + 1) * PAGE); i++) {
            Book b = hits.get(i);
            list.add(b.title() + "  -  " + b.author() + "  [" + b.category() + "]");
        }
        int pages = Math.max(1, (hits.size() + PAGE - 1) / PAGE);
        if (!hits.isEmpty()) status.setText("Page " + (page + 1) + " of " + pages + " (" + hits.size() + " results)");
        updateButtons();
    }

    private void reserveSelected() {
        int i = list.getSelectedIndex();
        if (i < 0) { status.setText("Select a book in the list first."); return; }
        status.setText("Reserved: " + hits.get(page * PAGE + i).title());
    }

    private void updateButtons() {
        prev.setEnabled(page > 0);
        next.setEnabled((page + 1) * PAGE < hits.size());
        reserve.setEnabled(!hits.isEmpty());
    }

    // accessors for the test driver
    TextField queryField() { return query; }
    Button searchButton() { return search; }
    java.awt.List resultList() { return list; }
    Button reserveButton() { return reserve; }
    Component[] regions() { return new Component[]{ search, list, prev, status }; }

    public static void main(String[] args) { new LibrarySearch().setVisible(true); }
}
