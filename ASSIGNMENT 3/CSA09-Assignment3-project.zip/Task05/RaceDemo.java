import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/** Q5 Student A - reliably reproduce double booking, and show the exact interleaving. */
public class RaceDemo {
    interface Screen { void book(int seat); int made(); }

    static class Unsafe implements Screen {
        final boolean[] booked = new boolean[10]; int made = 0; final boolean widen;
        final AtomicIntegerArray sold = new AtomicIntegerArray(10);   // real sales per seat (for measuring)
        Unsafe(boolean widen) { this.widen = widen; }
        public void book(int seat) {
            if (!booked[seat]) {                                       // CHECK
                if (widen) { try { Thread.sleep(1); } catch (InterruptedException e) { } }
                booked[seat] = true;                                   // ACT   (check-then-act = critical section)
                made++;                                                // read-modify-write, not atomic either
                sold.incrementAndGet(seat);
            }
        }
        public int made() { return made; }
        int doubles() { int d = 0; for (int i = 0; i < 10; i++) d += Math.max(0, sold.get(i) - 1); return d; }
    }

    static class Safe extends Unsafe {
        Safe() { super(true); }
        @Override public synchronized void book(int seat) { super.book(seat); }
    }

    static int trial(Unsafe s) throws Exception {
        CountDownLatch go = new CountDownLatch(1);
        Thread[] t = new Thread[100];
        for (int i = 0; i < 100; i++) {
            final int seat = i % 10;
            t[i] = new Thread(() -> { try { go.await(); } catch (InterruptedException e) { } s.book(seat); });
            t[i].start();
        }
        go.countDown();                         // release all 100 users at once
        for (Thread x : t) x.join();
        return s.doubles();
    }

    /** Two threads, forced interleaving, same seat. */
    static void interleaving() throws Exception {
        System.out.println("== forced interleaving of two threads for seat 3 ==");
        boolean[] booked = new boolean[10];
        AtomicInteger sold = new AtomicInteger();
        CountDownLatch t1Checked = new CountDownLatch(1), t2Checked = new CountDownLatch(1), t1Done = new CountDownLatch(1);
        Thread t1 = new Thread(() -> {
            boolean free = !booked[3];  System.out.println("T1: check booked[3]==false ? " + free); t1Checked.countDown();
            try { t2Checked.await(); } catch (InterruptedException e) { }
            if (free) { booked[3] = true; sold.incrementAndGet(); System.out.println("T1: set booked[3]=true -> SOLD to user 1"); }
            t1Done.countDown();
        });
        Thread t2 = new Thread(() -> {
            try { t1Checked.await(); } catch (InterruptedException e) { }
            boolean free = !booked[3];  System.out.println("T2: check booked[3]==false ? " + free + "   (T1 has not written yet!)"); t2Checked.countDown();
            try { t1Done.await(); } catch (InterruptedException e) { }
            if (free) { booked[3] = true; sold.incrementAndGet(); System.out.println("T2: set booked[3]=true -> SOLD to user 2"); }
        });
        t1.start(); t2.start(); t1.join(); t2.join();
        System.out.println("seat 3 sold " + sold.get() + " times  -> DOUBLE BOOKING");
    }

    public static void main(String[] args) throws Exception {
        interleaving();
        System.out.println("\n== 10 runs, UNSYNCHRONIZED, check/act window widened by 1 ms ==");
        int total = 0;
        for (int r = 1; r <= 10; r++) {
            Unsafe u = new Unsafe(true); int d = trial(u); total += d;
            System.out.printf("run %2d: bookingsMade=%3d (expected 10)  doubleBookings=%d%n", r, u.made(), d);
        }
        System.out.println("total double bookings over 10 runs: " + total);

        System.out.println("\n== 10 runs, UNSYNCHRONIZED, no widening (natural timing) ==");
        total = 0;
        for (int r = 1; r <= 10; r++) {
            Unsafe u = new Unsafe(false); int d = trial(u); total += d;
            System.out.printf("run %2d: bookingsMade=%3d  doubleBookings=%d%n", r, u.made(), d);
        }
        System.out.println("total double bookings over 10 runs: " + total);

        System.out.println("\n== 10 runs, SYNCHRONIZED method, same widened window ==");
        total = 0;
        for (int r = 1; r <= 10; r++) {
            Safe s = new Safe(); int d = trial(s); total += d;
            System.out.printf("run %2d: bookingsMade=%3d  doubleBookings=%d%n", r, s.made(), d);
        }
        System.out.println("total double bookings over 10 runs: " + total);
    }
}
