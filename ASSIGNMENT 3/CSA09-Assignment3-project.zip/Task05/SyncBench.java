import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.concurrent.locks.*;

/** Q5 Student B - compare synchronisation strategies on 10,000 booking requests. */
public class SyncBench {
    static final int SEATS = 2000, REQUESTS = 10_000, THREADS = 4;
    static volatile double sink;

    /** Non-critical work (price/ticket formatting) done on every request. */
    static void nonCritical() { double x = 0; for (int i = 1; i <= 2000; i++) x += Math.sqrt(i); sink = x; }

    interface Strategy { boolean book(int seat); int made(); String name(); }

    static class NoSync implements Strategy {
        boolean[] b = new boolean[SEATS]; int made;
        public boolean book(int s) { nonCritical(); if (!b[s]) { b[s] = true; made++; return true; } return false; }
        public int made() { return made; } public String name() { return "no sync (WRONG)"; }
    }
    static class SyncMethod implements Strategy {
        boolean[] b = new boolean[SEATS]; int made;
        public synchronized boolean book(int s) { nonCritical(); if (!b[s]) { b[s] = true; made++; return true; } return false; }
        public int made() { return made; } public String name() { return "synchronized method"; }
    }
    static class SyncBlock implements Strategy {
        boolean[] b = new boolean[SEATS]; int made; final Object lock = new Object();
        public boolean book(int s) {
            nonCritical();                                   // outside the lock
            synchronized (lock) { if (!b[s]) { b[s] = true; made++; return true; } return false; }
        }
        public int made() { return made; } public String name() { return "synchronized block"; }
    }
    static class Cas implements Strategy {
        AtomicBoolean[] b = new AtomicBoolean[SEATS]; AtomicInteger made = new AtomicInteger();
        Cas() { for (int i = 0; i < SEATS; i++) b[i] = new AtomicBoolean(); }
        public boolean book(int s) { nonCritical(); if (b[s].compareAndSet(false, true)) { made.incrementAndGet(); return true; } return false; }
        public int made() { return made.get(); } public String name() { return "AtomicBoolean CAS"; }
    }
    static class Reentrant implements Strategy {
        boolean[] b = new boolean[SEATS]; int made; final ReentrantLock l = new ReentrantLock();
        public boolean book(int s) {
            nonCritical(); l.lock();
            try { if (!b[s]) { b[s] = true; made++; return true; } return false; } finally { l.unlock(); }
        }
        public int made() { return made; } public String name() { return "ReentrantLock"; }
    }
    static class Chm implements Strategy {
        ConcurrentHashMap<Integer, Boolean> m = new ConcurrentHashMap<>();
        public boolean book(int s) { nonCritical(); return m.putIfAbsent(s, Boolean.TRUE) == null; }
        public int made() { return m.size(); } public String name() { return "ConcurrentHashMap.putIfAbsent"; }
    }

    static long[] run(Supplier s) throws Exception {
        Strategy st = s.get();
        int[] seatFor = new int[REQUESTS];
        Random r = new Random(42);
        for (int i = 0; i < REQUESTS; i++) seatFor[i] = r.nextInt(SEATS);
        Set<Integer> distinct = new HashSet<>(); for (int x : seatFor) distinct.add(x);
        ExecutorService ex = Executors.newFixedThreadPool(THREADS);
        CountDownLatch go = new CountDownLatch(1);
        List<Future<?>> fs = new ArrayList<>();
        for (int t = 0; t < THREADS; t++) {
            final int from = t * REQUESTS / THREADS, to = (t + 1) * REQUESTS / THREADS;
            fs.add(ex.submit(() -> { go.await(); for (int i = from; i < to; i++) st.book(seatFor[i]); return null; }));
        }
        long t0 = System.nanoTime(); go.countDown();
        for (Future<?> f : fs) f.get();
        long ms = (System.nanoTime() - t0) / 1_000;      // microseconds
        ex.shutdown();
        return new long[]{ms, st.made(), distinct.size()};
    }
    interface Supplier { Strategy get(); }

    public static void main(String[] args) throws Exception {
        Supplier[] all = { NoSync::new, SyncMethod::new, SyncBlock::new, Reentrant::new, Cas::new, Chm::new };
        for (int w = 0; w < 3; w++) for (Supplier s : all) run(s);          // warm-up
        System.out.printf("%-30s %10s %10s %10s%n", "strategy", "median ms", "sold", "correct?");
        for (Supplier s : all) {
            long[] times = new long[7]; long[] last = null;
            for (int i = 0; i < 7; i++) { last = run(s); times[i] = last[0]; }
            Arrays.sort(times);
            String name = s.get().name();
            System.out.printf("%-30s %10.1f %10d %10s%n", name, times[3] / 1000.0, last[1],
                    last[1] == last[2] ? "yes" : "NO (expected " + last[2] + ")");
        }
    }
}
