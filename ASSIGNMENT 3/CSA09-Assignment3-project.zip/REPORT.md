---
title: "Programming in Java – Assignment 3 (CO3): Exception Handling and Multithreading"
---

**Course:** CSA09 Programming in Java  |  **Mode:** Pair work  |  **Total marks:** 50

| | Student A | Student B |
|---|---|---|
| Name | `<<fill>>` | `<<fill>>` |
| Register number | `<<fill>>` | `<<fill>>` |
| GitHub repository | `<<link>>` | `<<link>>` |

**Environment for all measurements:** OpenJDK 21.0.12, Linux, 2 vCPUs. All programs are in the repository folders `Task01` … `Task07`; raw outputs are the `output_*.txt` files and `Task07/bench_results.csv`. Timings are machine-dependent; the *patterns* are what matter.

## Individual Contribution Record

| Question | Student A – Primary responsibility | Student B – Primary responsibility | Joint |
|---|---|---|---|
| Q1 | Exception design: hierarchy, failure table, catch order, `finally` | Testing and tracing: 7 test inputs, stack trace, wrong catch order | Failure points, classification, implementation, `catch (Exception)` question |
| Q2 | Hierarchy class diagram, checked/unchecked reasons, propagation path | Scenarios, `getCause()` and chained trace, lost-cause demo, test table | Hierarchy design, throw/throws, chaining, conclusion |
| Q3 | Debugging, leak experiment, handle counts, logging | Resource inventory, why manual leaks, close order, suppressed exceptions | Both versions, same-report check, engineering decision |
| Q4 | Thread-design explanations, life-cycle diagram, `run()` vs `start()`, `join()` | 10-run experiment, priorities, daemon, scheduler explanation | Both implementations, conclusion |
| Q5 | Reproducing and explaining the race, critical section | Timing of strategies, static sync, intrinsic locks | Three versions, verification, deployment decision |
| Q6 | Producer–consumer design, size trace, `sleep` vs `wait` | Deadlock construction, four conditions, lock-ordering fix | Both parts, conclusion |
| Q7 | Stage 2 – design | Stage 3 – implement and measure | Stage 1 – interpret, Stage 4 – defend |

---

# Q1 – Handling Failure in a Bank ATM Simulation (6 marks)

Code: `Task01/AtmSimulation.java`, `UncaughtDemo.java`, `catch_order_wrong/WrongOrder.java`, `AtmErrorCodes.java`.

## Shared work – failure points and classification

| # | Failure point | Exception | Class | Caught in |
|---|---|---|---|---|
| 1 | Card-reader file missing | `FileNotFoundException` | checked | `catch (FileNotFoundException)` in `withdraw()` |
| 2 | Any other read failure on the card file | `IOException` | checked | `catch (IOException)` (after the narrower one) |
| 3 | Account or amount typed as letters | `NumberFormatException` | unchecked | multi-catch |
| 4 | Negative or zero amount | `InvalidAmountException` (custom, extends `RuntimeException`) | unchecked | same multi-catch |
| 5 | Amount larger than balance | `InsufficientFundsException` (custom, extends `Exception`) | checked | its own catch |
| 6 | Card does not match account | `SecurityException` | unchecked | final `catch (RuntimeException)` |
| 7 | JVM failure (e.g. out of memory) | `OutOfMemoryError` | Error (unchecked) | not caught – not recoverable |

Implementation: `withdraw()` uses `try` / four `catch` clauses (one is a multi-catch `NumberFormatException | InvalidAmountException`) / `finally`.

## Student A – Exception design

**Throwable hierarchy relevant to the ATM**

```
Throwable
├── Error
│    └── OutOfMemoryError                      (not caught)
└── Exception
     ├── IOException
     │    └── FileNotFoundException            (checked)
     ├── InsufficientFundsException            (custom, checked)
     └── RuntimeException                      (unchecked)
          ├── IllegalArgumentException
          │    └── NumberFormatException
          ├── InvalidAmountException           (custom)
          └── SecurityException
```

**Order of catch blocks and why.** Java tries the clauses top to bottom and takes the first that matches, so a subclass must come before its superclass: `FileNotFoundException` before `IOException`, and the broad `RuntimeException` last as a safety net for unexpected unchecked errors. If the order is reversed the compiler rejects the program (see Student B). The two types in the multi-catch are unrelated siblings; a multi-catch of types related by inheritance would not compile.

**What `finally` guarantees here.** `finally` runs after the try block completes normally, after a catch block handles an exception, and even when an exception is *not* caught (it runs, then the exception keeps propagating). In the ATM it is where the card session is closed and the screen reset, so this happens for success and for every failure. Evidence: `finally` executed **7 times for 7 inputs**. It does not run if the JVM is terminated (`System.exit`, crash) or the thread never leaves an infinite loop.

## Student B – Testing and tracing

| Test | Input (file, account, amount) | Outcome | Block that ran | `finally` ran? |
|---|---|---|---|---|
| T1 | card.txt, 12345, 1000 | dispensed, balance 4000 | none | yes (#1) |
| T2 | card.txt, 12345, `abc` | `NumberFormatException: For input string: "abc"` | multi-catch | yes (#2) |
| T3 | card.txt, 12345, -200 | `InvalidAmountException: Amount must be positive` | multi-catch | yes (#3) |
| T4 | card.txt, 12345, 999999 | `InsufficientFundsException`, short by 995999.0 | `InsufficientFundsException` | yes (#4) |
| T5 | missing.txt, 12345, 500 | `FileNotFoundException: missing.txt (No such file or directory)` | `FileNotFoundException` | yes (#5) |
| T6 | card.txt, `12x45`, 500 | `NumberFormatException` | multi-catch | yes (#6) |
| T7 | card.txt, 99999, 500 | `SecurityException: Card does not match account` | `RuntimeException` | yes (#7) |

**Stack trace of an uncaught exception** (`UncaughtDemo`, `Integer.parseInt("abc")`, nothing catches it):

```
Exception in thread "main" java.lang.NumberFormatException: For input string: "abc"
	at java.base/java.lang.NumberFormatException.forInputString(NumberFormatException.java:67)
	at java.base/java.lang.Integer.parseInt(Integer.java:662)
	at java.base/java.lang.Integer.parseInt(Integer.java:778)
	at UncaughtDemo.parseAmount(UncaughtDemo.java:3)
	at UncaughtDemo.withdraw(UncaughtDemo.java:4)
	at UncaughtDemo.main(UncaughtDemo.java:6)
```

- **Line 1:** thread that died (`main`), exception class, message (the offending text).
- **Lines 2–4 (`java.base/...`):** JDK internals, read top-down from where the exception was *created*: `forInputString` built it; `parseInt(…:662)` found a non-digit; `parseInt(…:778)` is the one-argument overload delegating to the radix version.
- **Line 5:** `parseAmount`, line 3 – the first frame of our code, i.e. where to start debugging.
- **Line 6:** `withdraw` (line 4) called `parseAmount`.
- **Line 7:** `main` (line 6) called `withdraw` – the bottom of the stack; nobody caught it, so the thread terminated.

**Broader catch before narrower** (`catch (Exception)` then `catch (NumberFormatException)`):

```
catch_order_wrong/WrongOrder.java:8: error: exception NumberFormatException has already been caught
        } catch (NumberFormatException e) {
          ^
1 error
```
The second block could never execute, so the compiler reports an error.

## Joint design question – should the ATM use a single `catch (Exception e)`?

Acceptable only at the **outermost boundary**: a top-level handler that logs the full exception and shows a generic "transaction failed" screen so that the machine never crashes, or a loop that must keep serving the next customer. What is lost when it is used *instead of* specific handlers: (1) the ability to react differently (ask for another amount vs. call maintenance); (2) accurate user messages; (3) it also swallows programming bugs (`NullPointerException`, `ArrayIndexOutOfBoundsException`) that should be fixed rather than hidden; (4) the compiler's checked-exception help is bypassed; (5) it can swallow `InterruptedException` and break thread cancellation. It also does not catch `Error`s, so it is not "catch everything" either.

## Alternative concept – no exceptions, pre-validation and error codes

`AtmErrorCodes.java` checks `Scanner.hasNextInt()` and returns `-1` (not a number), `-2` (non-positive), `-3` (insufficient). Output: `1000 → 0`, `abc → -1`, `-200 → -2`, `999999 → -3`.

| | Exceptions | Error codes |
|---|---|---|
| Readability | normal path is straight-line; error handling is separated | every call is followed by `if (code != 0)`; the happy path is buried |
| Number of checks | one `try` covers many calls | 3 explicit checks per withdrawal, repeated at every call site |
| Safety | checked exceptions *force* handling | caller can silently ignore `-1` |
| Time of failure | O(d) – stack trace filled for stack depth *d*, plus unwinding | O(1) – a return |
| Space of failure | exception object + O(d) stack-trace array | one `int` |

Measured (`output_AtmErrorCodes.txt`, 2 000 000 iterations): **throw + catch ≈ 363 ns per operation; returning a code ≈ 0.22 ns**. The code-path figure is a lower bound (the JIT can simplify such a loop), so read it as "orders of magnitude cheaper", not as an exact ratio. Conclusion: use error codes/pre-checks for *expected, frequent* conditions inside hot loops; use exceptions for rare, exceptional failures where forced handling and a stack trace matter.

---

# Q2 – User-Defined Exceptions and Propagation in an Online Examination Portal (7 marks)

Code: `Task02/ExamPortal.java` (three-layer portal), `StorageDemo.java` (Complete the Code), `StorageDemoNoCause.java`, `StackTraceCost.java`.

## Student A – Hierarchy and propagation

**Class diagram**

```
            Exception                              RuntimeException
                │                                         │
          ExamException  «checked»                PortalConfigurationException «unchecked»
     ┌──────────┼───────────────┬────────────────────┐
ExamWindowClosed  NotRegistered  FileTooLarge   SubmissionStorageException
 Exception         Exception      Exception       (wraps IOException as cause)
```
(In `ExamPortal.java` the same classes carry a `P` prefix, e.g. `PStorageException`, to avoid clashing with `StorageDemo.java` in the same folder.)

**Why checked or unchecked**

| Exception | Kind | Reason |
|---|---|---|
| `ExamException` (base) | checked | One type lets the controller handle every portal rule failure in one place |
| `ExamWindowClosedException` | checked | A normal business outcome the caller must deal with (show message, stop) |
| `NotRegisteredException` | checked | Same – expected, recoverable by the user contacting the office |
| `FileTooLargeException` | checked | The student can retry with a smaller file, so the caller is forced to offer that |
| `SubmissionStorageException` | checked | Infrastructure failure that must be translated, not ignored; carries the cause |
| `PortalConfigurationException` | unchecked | A programming/configuration bug; no caller can recover, so no `throws` clutter |

**Propagation path of one exception (disk quota exceeded)**

```
PStorage.store()      IOException("Disk quota exceeded") thrown
      │  caught here and wrapped:  new PStorageException("Could not store q3.pdf", e)
      ▼
PService.submit()     declares  throws PExamException  – does not catch, exception passes through
      ▼
PController.handle()  catch (PStorageException e)  ← finally handled here
```
The student sees: `SORRY: your answer could not be saved right now. Please retry (ref: Could not store q3.pdf)`. The log (not the student) gets the chain, including `getCause() = java.io.IOException: Disk quota exceeded`.

## Student B – Scenarios and chaining evidence

| # | Scenario | Exception | What the student sees |
|---|---|---|---|
| 1 | valid submission at 10:30 | – | `SUCCESS: a.pdf submitted` |
| 2 | submission at 12:30, window closed 12:00 | `ExamWindowClosedException` | `REJECTED (ExamWindowClosedException): Exam window closed at 2026-11-15T12:00` |
| 3 | student `S999` not registered | `NotRegisteredException` | `REJECTED (NotRegisteredException): S999 is not registered for CS101` |
| 4 | 800 KB file, limit 500 KB | `FileTooLargeException` | `REJECTED (FileTooLargeException): big.pdf is 800 KB; limit is 500 KB` |
| 5 | storage not mounted | `PStorageException` ← `FileNotFoundException` | `SORRY: … (ref: Could not store unmounted1.pdf)` |
| 6 | quota exceeded after 800 KB stored | `PStorageException` ← `IOException` | `SORRY: … (ref: Could not store q3.pdf)` |

**Chained stack trace (cause kept)**

```
PStorageException: Could not store unmounted.pdf
	at PStorage.store(ExamPortal.java:46)
	at ExamPortal.main(ExamPortal.java:110)
Caused by: java.io.FileNotFoundException: /data/submissions/ is not mounted
	at PStorage.store(ExamPortal.java:42)
	... 1 more
getCause().getClass() = java.io.FileNotFoundException
```

**Re-thrown without the cause – what is lost**

```
PStorageException: Could not store unmounted.pdf
	at PStorage.store(ExamPortal.java:47)
	at ExamPortal.main(ExamPortal.java:118)
getCause() = null
```
The `Caused by:` section is gone. We no longer know the *real* reason (not mounted vs. quota), the original class, or the original failing line (42). Support staff would only see "Could not store".

## Joint conclusion

A `SubmissionStorageException` speaks the portal's language (a submission could not be stored) and hides storage details (paths, drivers) from the UI, so the storage technology can change (disk → cloud) without touching the controller. The controller can handle it by *type* (offer retry) without knowing about `IOException`; the original `IOException` stays attached as the cause for logs. Letting a raw `IOException` reach the UI leaks internal details, couples every layer to one implementation, and forces every layer to handle a low-level type.

## Complete the Code

TODO 1: `throw new SubmissionStorageException("Could not store " + fileName, e);`

```
Saved answer01.pdf
Error: Could not store answer02.pdf
Cause: Disk quota exceeded
```
Matches the expected output. **If the IOException were not passed to the constructor**, `e.getCause()` returns `null`, so the `Cause:` line would not print `null` – calling `.getMessage()` on it throws a `NullPointerException` inside the catch block and the program ends with a stack trace after printing only the `Error:` line (`StorageDemoNoCause.java` shows this: `getCause() = null`, then the NPE).

## Alternative concept – unchecked custom exceptions

If the classes extended `RuntimeException`: the `throws SubmissionStorageException` / `throws PExamException` clauses disappear from `Storage.save`, `PService.submit` and the callers; `try/catch` in the controller becomes optional, so the compiler no longer forces anyone to handle a missing handler – a forgotten one would show up only at run time as an uncaught exception. Less boilerplate, fewer guarantees.

Cost of capturing a stack trace (`StackTraceCost.java`, 100 000 throws per row):

| Stack depth | with trace (ns) | trace disabled (ns) | ratio |
|---|---|---|---|
| 1 | 826 | 81 | 10.2x |
| 10 | 756 | 219 | 3.5x |
| 50 | 2 636 | 1 029 | 2.6x |
| 100 | 5 775 | 2 556 | 2.3x |
| 500 | 22 834 | 13 727 | 1.7x |

Time is O(d) in the stack depth *d* (the JVM walks and records every frame); the part that remains with the trace disabled is mostly unwinding the frames. Space: each exception object holds its own stack-trace array, O(d); a chain of *c* exceptions holds O(c·d) frames plus *c* references to the causes (our 6-exception chain held 6 `StackTraceElement`s because each was built at depth 1). Chaining therefore keeps the whole cause alive in memory for as long as the outer exception lives – worth it for diagnosis, but a reason not to cache or store exceptions long-term.

---

# Q3 – Resource Safety, Debugging and Robust Code (7 marks)

Code: `Task03/SalesReport.java` with three versions: `naive` (manual `close()` at the end of `try`), `finally` (try-catch-finally with manual close) and `twr` (try-with-resources). Data files are generated automatically; every 3rd file contains the corrupt line `CORRUPT#` part-way through.

## Shared work – same report from both versions

Same input (5 files, file 3 corrupt): `ok=4 failed=1` in all versions, and `diff summary_finally.csv summary_twr.csv` shows **identical** reports (naive is identical too – the leak does not change the report, it changes the *process*).

## Student A – Debugging and experiment

**Step-through debugging (jdb session, `output_jdb_session.txt`).** `catch java.lang.NumberFormatException`, then `run`:

```
Exception occurred: java.lang.NumberFormatException (to be caught at: SalesReport.run(), line=73)
  [3] SalesReport.sumNaive (SalesReport.java:25)       ← exception thrown while reading
  [5] SalesReport.run (SalesReport.java:70)
locals (top frame, Long.parseLong): s = "CORRUPT#"
main[1] step up
Step completed: SalesReport.run(), line=74            ← already in the catch block of run()
```
After the exception, the next executed line is in `run()`'s catch block. **Line 26, `br.close()`, is never reached** – that is the point where the file is leaked. (In an IDE: breakpoint on line 25, run, step over/into until the exception, then observe that execution jumps past line 26; take a screenshot for the repository.)

**Input that fails part-way:** a file whose third line is `CORRUPT#` (first two lines parse fine, so the reader is already open).

**Open file handles left behind for the same failing input** (counted from `/proc/self/fd`):

| Input | naive | finally | try-with-resources |
|---|---|---|---|
| 5 files, 1 corrupt | **1** | 0 | 0 |
| 5 files, all corrupt | **5** | 0 | 0 |
| 1000 files, all corrupt, `ulimit -n 150` | **143** (+857 "Too many open files" errors) | 0 | 0 |
| 1000 files, every 2nd corrupt, `ulimit -n 150` | ok = **143** of 500 healthy files; 357 *healthy* files failed (714 "Too many open files" errors) | ok = 500 | ok = 500 |

The last row reproduces the production symptom: leaks from bad files eventually make **good files** fail with "Too many open files", so the report is incomplete.

**Logging** (`sales.log`, `java.util.logging`): `WARNING: FAILED file=store3.txt cause=java.lang.NumberFormatException: For input string: "CORRUPT#"` – identifies which file caused the failure.

## Student B – Design and correctness

**Resources and where they must be closed:** one `PrintWriter`/`FileWriter` for the summary (opened once, closed after the loop, in `finally`), and one `BufferedReader`/`FileReader` per store file (closed as soon as that file is processed, on both the success and the failure path).

**Why the manual version can leak:** `br.close()` is an ordinary statement after the loop; when `readLine()` or `parseLong()` throws, control leaves the method and the statement is skipped. Nothing else closes the stream until the garbage collector eventually finalizes it, which is unpredictable.

**How try-with-resources guarantees closing:** the compiler expands it into a try/finally that calls `close()` on every initialized resource whether the body finishes normally or throws. Resources are closed in the **reverse order of declaration** (demo: opened `A(reader)`, `B(writer)`; closed `B(writer)` then `A(reader)`).

**Suppressed exceptions:** if the body throws *and* `close()` also throws, the body's exception stays the primary one and the `close()` failure is attached to it via `getSuppressed()` instead of replacing it. Demo output:

```
  caught primary : java.lang.IllegalStateException: primary: body failed
  suppressed     : java.io.IOException: close failed for B(writer)
```

## Joint engineering decision – when is try-with-resources not enough?

1. A failing file must not stop the whole run: it needs per-file catch-and-continue (as in `run()`), not only closing.
2. The summary can still be **incomplete** if the program dies half-way; write to a temporary file and move it into place only when complete.
3. `close()` of a *writer* can fail after buffered data was lost (full disk) – that failure must be checked/logged, not ignored.
4. Resources created outside the `try (...)` header, returned from methods, or held in fields are not covered; ownership must be explicit.
5. Opening too many resources at once (many files in parallel) can exhaust handles even though each is closed correctly; concurrency must be bounded.
6. Failures need logging with context (which file) and possibly retries/timeouts for slow storage.

## Alternative concept and complexity analysis (f store files, m lines each)

| Version | Time | Max handles open when a failure occurs |
|---|---|---|
| try-with-resources | O(f·m) | O(1): the writer + the one reader being processed; closed immediately |
| explicit `close()` in `finally` | O(f·m) | O(1) – same, but more code (nested try/catch for `close()`) |
| `close()` only at end of `try` (naive) | O(f·m) | up to **O(f)** – one leaked reader per failing file (measured 143 with limit 150) |
| no closing at all | O(f·m) | **O(f)** even without failures; limited only by the OS limit |

Processing time is the same in all versions – the difference is space (handles), and robustness.

---

# Q4 – Thread Creation and the Thread Life Cycle (7 marks)

Code: `Task04/Stations.java` (four stations of 30 scripts each, ~2–4 ms per script; stations 1–2 extend `Thread`, stations 3–4 implement `Runnable`).

## Shared work

`start()` begins execution, `sleep()` simulates scanning time, `join()` waits for completion, `isAlive()` tests liveness. Run output (`basic`): all four threads `NEW` before `start()`, `TIMED_WAITING isAlive=true` 10 ms later, `TERMINATED isAlive=false` after `join()`; `TOTAL scripts scanned = 120 (expected 120)`.

## Student A – Thread design

**Two ways to create a thread.** Extending `Thread` ties the task to the thread type and uses up the single inheritance slot; implementing `Runnable` separates the *task* from the *thread*, lets the class extend something else, and lets the same task be run by threads or executors. `Runnable` is preferred in almost all cases; extending `Thread` only makes sense when you really customise the thread itself.

**Life-cycle diagram** (each station follows this path):

```
NEW ──start()──► RUNNABLE ──(scheduler picks)──► RUNNING
                    ▲  │                              │ sleep(ms)
                    │  └──────────────────────────────┤────► TIMED_WAITING ──timeout──┐
                    └──────────────────────────────────────────────────────────────────┘
                                          run() ends ► TERMINATED
```
Stations pass through NEW → RUNNABLE → (TIMED_WAITING ⇄ RUNNABLE, once per script because of `sleep`) → TERMINATED. They would enter BLOCKED if waiting for a monitor, WAITING in `join()`/`wait()`.

**`run()` vs `start()` – evidence** (`runvsstart`):
```
calling run()   : body executed by thread: main
calling start() : body executed by thread: Station-X
4 x 50 scripts via run()  : 629 ms (sequential, all on main)
4 x 50 scripts via start(): 163 ms (parallel)
```
`run()` is an ordinary method call on the calling thread; only `start()` asks the JVM to create a new thread that then calls `run()`.

**How `join()` ensures the final total:** `main` calls `t.join()` on every station; `join()` blocks (state WAITING) until that thread is TERMINATED. Only after all four joins return does `main` print the total, so no station can still be counting.

## Student B – Behavioural experiments

**Ten runs, default priorities – finish order**

| Run | Order (first → last) | Run | Order (first → last) |
|---|---|---|---|
| 1 | S1, S3, S2, S4 | 6 | S4, S3, S2, S1 |
| 2 | S4, S1, S2, S3 | 7 | S3, S2, S4, S1 |
| 3 | S1, S4, S2, S3 | 8 | S4, S3, S1, S2 |
| 4 | S4, S1, S3, S2 | 9 | S2, S1, S3, S4 |
| 5 | S4, S3, S2, S1 | 10 | S1, S4, S3, S2 |

First finisher count: S1 = 3, S2 = 1, S3 = 1, S4 = 5 – no fixed order.

**Priorities** (Station-4 `MAX_PRIORITY`, Station-3 `MIN_PRIORITY`, 10 runs): Station-4 finished first 5/10 times – the same as with default priorities – while the MIN-priority Station-3 finished first 3/10 times. **No reliable effect.** Priority is only a hint; on typical Linux JVMs it is not mapped to OS scheduling priority, and in any case these threads spend most of their time sleeping rather than competing for the CPU.

**Daemon station:** with `setDaemon(true)` and a ~6 s batch, `main()` ended after 100 ms while the daemon had scanned only 32 scripts; the JVM exited immediately and "daemon finished its batch" was never printed. Control with a normal thread: the JVM waited and "normal thread finished its batch" was printed. A JVM exits when only daemon threads remain.

**Scheduler explanation:** the OS/JVM scheduler decides which RUNNABLE thread runs and for how long; sleep durations include small random jitter, wake-up latency and CPU availability vary, so equal-sized stations finish in different orders. Nothing in the Java language fixes that order.

## Joint conclusion

The order depends on timing the program does not control (scheduler decisions, load, number of cores, JIT warm-up). A correct program must produce correct results for **every** legal interleaving – use `join`, locks or queues to enforce the ordering that matters (the total is printed after all `join()`s) and never rely on "usually Station-4 finishes first".

## Alternative concept – `ExecutorService` with a fixed pool

Stations become tasks submitted with `pool.submit(...)`; `Future.get()` replaces `join()`. Measured for n = 400 scripts at 5 ms (p = number of threads):

| p | pool (ms) | hand-made threads (ms) | ideal n·5/p (ms) |
|---|---|---|---|
| 1 | 2 091 | 2 060 | 2 000 |
| 2 | 1 030 | 1 028 | 1 000 |
| 4 | 515 | 513 | 500 |
| 8 | 259 | 257 | 250 |

Expected completion ≈ (n/p)·t – both approaches follow it (about 4 % above ideal from sleep granularity). Four stations on a pool of 2 took 192 ms ≈ 2 rounds × ~90 ms, with finish order S1, S2, S3, S4 (queued stations start only when a worker is free). **Memory:** each platform thread reserves a stack (default about 1 MB on 64-bit Linux, committed lazily), so p threads ≈ p MB virtual; creating one thread per task is O(n) threads. The pool bounds this to p and reuses threads, avoiding repeated creation cost.

---

# Q5 – Race Conditions in a Cinema Seat-Booking System (6 marks)

Code: `Task05/SeatBooking.java` (Complete the Code, synchronized), `SeatBookingUnsync.java`, `RaceDemo.java`, `SyncBench.java`.

## Complete the Code – results

TODO 1: `synchronized void book(int seat) { if (!booked[seat]) { booked[seat] = true; bookingsMade++; } }`

- **Synchronized, 10 runs:** `Seats sold: 10` every time (expected output).
- **Same program with TODO 1 written WITHOUT `synchronized`, 10 runs:** `Seats sold: 10` in **all 10** runs. The race exists, but in this exact program the 100 threads are started one at a time and each runs for a few microseconds, so the threads barely overlap and the check–act window (nanoseconds) is almost never hit. The absence of a failure is not evidence of correctness – which is why Student A built a test that forces the interleaving.

**Why the unsynchronized version may sell more than 10 seats:** `book()` is a *check-then-act* sequence (read `booked[seat]`, then write it) followed by a non-atomic `bookingsMade++` (read, add, write). Two threads can both read `false` before either writes `true`, so both mark the seat and both increment the counter.

## Student A – Producing and explaining the race

**Reliable test (`RaceDemo`):** 100 threads wait on a `CountDownLatch` and are released together; a 1 ms pause is added between the check and the write to widen the window. Ten runs, unsynchronized:

| Run | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | Total |
|---|---|---|---|---|---|---|---|---|---|---|---|
| bookingsMade (should be 10) | 52 | 62 | 55 | 47 | 60 | 49 | 27 | 60 | 80 | 72 | |
| double bookings | 42 | 52 | 45 | 37 | 50 | 39 | 17 | 50 | 70 | 62 | **464** |

Without the widening, 0 double bookings in 10 runs (natural timing). With a `synchronized` method and the same widened window: **0** double bookings in 10 runs.

**Step-by-step interleaving of two threads for seat 3** (forced in `RaceDemo`, actual output):
```
T1: check booked[3]==false ? true
T2: check booked[3]==false ? true   (T1 has not written yet!)
T1: set booked[3]=true -> SOLD to user 1
T2: set booked[3]=true -> SOLD to user 2
seat 3 sold 2 times  -> DOUBLE BOOKING
```

**Critical section:** the whole sequence `if (!booked[seat]) { booked[seat] = true; bookingsMade++; }` – it must execute as one indivisible unit per screen.

## Student B – Comparing synchronization strategies

10 000 booking requests, 2 000 seats, 4 threads, each request also does a little non-critical work (price calculation); median of 7 runs after warm-up (`SyncBench`):

| Strategy | Median time (ms) | Seats sold | Correct? |
|---|---|---|---|
| no synchronization | 19.3 | 1 982 | **no** (expected 1 985) |
| `synchronized` method | 40.5 | 1 985 | yes |
| `synchronized` block (critical section only) | 22.5 | 1 985 | yes |
| `ReentrantLock` | 22.3 | 1 985 | yes |
| `AtomicBoolean[]` + `compareAndSet` | 20.7 | 1 985 | yes |
| `ConcurrentHashMap.putIfAbsent` | 23.5 | 1 985 | yes |

**Whole method vs. critical section only:** the synchronized method keeps the lock while doing the non-critical work, so the work of all threads is serialised – about **2x slower** here. Locking only the check-and-mark block lets the non-critical work run in parallel and is as fast as the lock-free options. (The unsynchronised run is fast but wrong – it also lost updates on the counter, 1 982 vs 1 985.)

**Intrinsic lock used:** the synchronized *method* locks `this` (the screen object); the synchronized *block* locks the object named in the parentheses (`this` or a private lock object).

**Static synchronization:** `static synchronized` (or `synchronized (SeatBooking.class)`) locks the `Class` object – one lock for the whole program. It would be needed if the seat data were `static` (shared by all screens). Here every screen has its own instance data, and a static lock would make all 20 screens wait for each other for no reason, so it should *not* be used.

## Joint decision – 20 screens

Use **one lock (or lock-free state) per screen**, not a global one, so different screens never block each other. Inside a screen, make only the check-and-mark critical section atomic: `AtomicBoolean[]`/`compareAndSet` (or `putIfAbsent`) for single-seat bookings – lock-free, simple, fastest in our measurement; a `synchronized` block or `ReentrantLock` per screen if a booking must reserve several seats together (all-or-nothing). Avoid the synchronized method with extra work in it, and avoid static locks. (Caveat: our workload is a small 2-core experiment; contention at a real cinema is far lower, so the choice is also about correctness and clarity.)

## Alternative concept and complexity analysis (s seats)

| Approach | Time per booking under contention | Extra space for s seats |
|---|---|---|
| `synchronized` method/block | O(1) uncontended; contenders block and queue – waiting time grows with the number of waiting threads | none beyond `boolean[s]` (≈ s bytes) |
| `AtomicBoolean[]` + CAS | O(1) lock-free; a losing CAS fails once and returns (no blocking) | s `AtomicBoolean` objects ≈ 16–20 bytes each → O(s), several times the plain array |
| `ReentrantLock` | O(1) uncontended; contenders park in a queue; allows `tryLock`/fairness | one lock object O(1) + `boolean[s]` |
| `ConcurrentHashMap.putIfAbsent` | O(1) expected; bin-level locking, no global lock | one entry per *booked* seat (≈ 50 bytes each) → O(s) |

---

# Q6 – Deadlock and Inter-Thread Communication (7 marks)

Code: `Task06/TokenCounter.java` (Complete the Code), `TokenVariants.java`, `WalletTransfers.java`, `QueueCounter.java`.

## Complete the Code – TokenCounter

TODO 1 (`put`): `while (count == buffer.length) wait();` then `buffer[in] = token; in = (in + 1) % buffer.length; count++; notifyAll();`
TODO 2 (`take`): `while (count == 0) wait();` then `int token = buffer[out]; out = (out + 1) % buffer.length; count--; notifyAll(); return token;`

Output (10 runs, identical): `Sum of tokens collected: 210 (expected 210)`.

**Changing `while` to `if` (200 runs, capacity 5):**

| Variant | correct sums | wrong sums | counter size seen (legal 0..5) |
|---|---|---|---|
| `while` | 200 | 0 | min 0, max 5 |
| `if` | 173 | **27** | min **-15**, max 5 |
| `while`, slow cook (1 ms per token), 20 runs | 20 | 0 | 0..1 |
| `if`, slow cook (1 ms per token), 20 runs | 0 | **20** | min **-19** |

Explanation: with `if`, a woken student does **not** re-check the condition. With two students waiting on an empty counter, one `notifyAll()` wakes both; the first takes the token, the second continues without re-checking, "takes" from an empty counter (stale slot, `count` becomes negative) and the sum is wrong.

## Student A – Producer–consumer design

- **`wait()` inside `synchronized`:** `wait()` releases the monitor and must be called by the monitor's owner; otherwise `IllegalMonitorStateException`. The check of `count` and the decision to wait must be atomic with respect to other threads, which the monitor provides.
- **`wait()` inside a loop:** after being notified a thread must re-acquire the lock, and by then another thread may already have changed the state (as shown above), or the wake-up may be spurious. The loop re-tests the condition every time.
- **`notify()` vs `notifyAll()`:** with several consumers one monitor holds producers *and* consumers; `notify()` wakes just one arbitrary waiter, which may be the wrong kind. Measured with `while` kept: capacity 5 → 200/200 correct (no failure observed, but not guaranteed); **capacity 1, `notify()` → 85 of 100 runs hung** (all threads waiting, nobody to wake the right one); capacity 1, `notifyAll()` → 100/100 correct. Our design uses `notifyAll()`.
- **Counter size over time:** recorded as the minimum/maximum inside the synchronized methods across 200 runs: **min 0, max 5** – never above 5, never below 0 (the `if` variant shows -15, confirming the check works).
- **`sleep()` vs `wait()`:** `sleep(ms)` is a `Thread` method, keeps any monitors it holds, and ends when the time is up; `wait()` is an `Object` method, requires and *releases* the monitor, and ends on `notify`/`notifyAll`/timeout/interrupt.

## Student B – Deadlock analysis and prevention

**Reliable deadlock** (`WalletTransfers deadlock`): T1 transfers A→B, T2 transfers B→A, each locks its source account and pauses 100 ms before locking the destination. Detected with `ThreadMXBean.findDeadlockedThreads()`:

```
unsafe: DEADLOCK detected among 2 threads:
   T1(A->B) is BLOCKED, waiting for lock Account@27d6c5e0 held by T2(B->A)
   T2(B->A) is BLOCKED, waiting for lock Account@2f4d3709 held by T1(A->B)
   T1 alive=true T2 alive=true  balances A=1000 B=1000 (no transfer completed)
```

**Four conditions present:** (1) *mutual exclusion* – `synchronized` allows one owner; (2) *hold and wait* – each thread holds its source account while waiting for the destination; (3) *no preemption* – a monitor cannot be taken from its owner; (4) *circular wait* – T1 waits for what T2 holds and T2 for what T1 holds.

**Prevention with lock ordering:** always lock the account with the smaller id first. The opposite transfers then both start with account 1, so one waits for the other and no cycle exists. Result: both finished, `A=950 B=1050 total=2000`; stress test of 8 threads × 20 000 random transfers over 10 accounts completed with `total=10000` (money conserved), no hang.

**Why the rule works:** it imposes a total order on locks, so the "waits-for" graph can only point from lower to higher ids and cannot contain a cycle – circular wait (condition 4) becomes impossible.

## Joint conclusion

Both problems are about threads **waiting for a condition that only another thread can change**. In deadlock the dependencies form a cycle so nobody ever proceeds; in producer–consumer the dependencies are *alternating*: producers wait for consumers to free space, consumers wait for producers to add tokens. Progress is ensured by design: lock ordering removes the cycle; in the counter every state change calls `notifyAll()` and each waiter re-checks its condition in a `while` loop, so some thread can always proceed.

## Alternative concept and complexity analysis

| Question | Result |
|---|---|
| `ArrayBlockingQueue(5)` vs `wait/notifyAll` monitor, 200 000 tokens, 1 cook + 2 students | monitor 1 059 ms (5 298 ns/token); queue 1 089 ms (5 449 ns/token) – equal within noise; both O(1) per put/take; space O(capacity) = 5 slots |
| lock ordering vs `tryLock(timeout)` with random back-off, 4 threads, 4 accounts (high contention) | ordering 4 ms, `tryLock` 23 ms; both conserved money; both O(1) per transfer when uncontended; `tryLock` adds retries and sleeps under contention; space O(1) per account (one lock object each) |

**Less error-prone:** `ArrayBlockingQueue` – no manual `wait`/`notify`, loops or index arithmetic, so the `if`-vs-`while` and `notify`-vs-`notifyAll` mistakes cannot occur. For transfers, lock ordering is simple and fast but needs a global rule known to every caller; `tryLock` needs no global knowledge but adds retry/back-off logic and the risk of livelock, so it is more error-prone.

---

# Q7 – A Concurrent, Fault-Tolerant Processor Designed from First Principles (10 marks)

Code: `Task07/ResultProcessor.java`. Modes: `small`, `robust`, `bench`, and alternatives `pool`, `ps-naive`, `ps-handled`, `tpf`.

## Stage 1 – Interpret the problem (joint, 2 marks)

**Parallel tasks and shared data.** Processing one file (read → validate → compute) is independent of every other file, so all 10 000 can run in parallel. Shared data: the results store, the counts and the final summary (many threads write, one reads at the end). The work is I/O-bound (reading small files).

**Failures and handling**

| Failure | How it appears | Handling |
|---|---|---|
| File missing | `NoSuchFileException` | → `MissingFileException` → status MISSING |
| Corrupt: empty, wrong field count, non-numeric mark, mark outside 0–100, invalid UTF-8 | line-count/field checks, `NumberFormatException`, `CharacterCodingException` | → `CorruptFileException` → status CORRUPT |
| Other I/O error | `IOException` | → status ERROR (with message) |
| Unexpected bug (runtime exception) | `RuntimeException` | caught inside the task → ERROR |
| `Error` (e.g. `AssertionError`, out of memory) | escapes the task | caught by `Future.get` as `ExecutionException` → ERROR |
| Hung/slow file | no result | `Future.get(timeout)` → `TimeoutException` → cancel → ERROR |

**Measurable requirements**

| ID | Requirement | Measure |
|---|---|---|
| R1 | Every file gets exactly one recorded outcome | `results.size() == 10 000` and OK + CORRUPT + MISSING + ERROR = 10 000 |
| R2 | Injected failures are counted correctly | expected 9 550 OK / 250 corrupt / 200 missing; sum of totals = 2 387 432 |
| R3 | One bad file never stops the run | run completes in all failure scenarios (incl. injected `Error`) |
| R4 | Bounded resources | ≤ 8 worker threads (not 10 000) |
| R5 | Fast | all 10 000 files in under 1 s on local files with ≥ 4 threads |

## Stage 2 – Design (Student A, 3 marks)

**Class diagram**

```
ResultProcessor
 ├─ main / runPool(files, threads, timeout)  : Summary
 ├─ task(Path, results) : Callable<Outcome>      – layer 1 handling
 ├─ process(Path) throws ScoreFileException : Outcome   (read → validate → compute)
 ├─ summarise(results, n) : Summary
 ├─ record Outcome(file, status, total, detail)
 ├─ enum Status { OK, CORRUPT, MISSING, ERROR }
 └─ ScoreFileException ◄── MissingFileException
                       ◄── CorruptFileException
Shared: ConcurrentHashMap<String,Outcome> results      ExecutorService (fixed pool)      Future<Outcome> per file
```

**Concurrent collection and why:** `ConcurrentHashMap<fileName, Outcome>` – many workers write concurrently; striped/bin-level locking avoids one global lock; the key is the file name, so a retry or the collector's `putIfAbsent` can never create duplicates (idempotent), and `size()` gives the completeness check. (`Collections.synchronizedList` would serialise all writers; `CopyOnWriteArrayList` would copy the array on every write.)

**Exception handling design:** *Layer 1*, inside the `Callable`: catch `MissingFileException`, `CorruptFileException`, and `ScoreFileException | RuntimeException`, convert each to an `Outcome`, store it, return it. *Layer 2*, in the collector: `Future.get(timeout)` – `ExecutionException` (an `Error` escaped), `TimeoutException` (cancel + ERROR), `CancellationException` → store ERROR with `putIfAbsent`. No exception ever propagates out of `runPool`.

**Pseudocode**
```
runPool(files, p):
    results = new ConcurrentHashMap;  pool = fixedThreadPool(p)
    for f in files:  futures[f] = pool.submit( task(f) )
    for (f, fut) in futures:
        try   fut.get(timeout)
        catch ExecutionException   -> results.putIfAbsent(f, ERROR(cause))
        catch TimeoutException     -> fut.cancel(true); results.putIfAbsent(f, ERROR("timeout"))
    pool.shutdown(); awaitTermination
    return summarise(results, files.size())          // checks size == files.size()

task(f):  return () -> { try  o = process(f)
                          catch Missing -> MISSING; catch Corrupt -> CORRUPT; catch Score|Runtime -> ERROR
                          results.put(f.name, o);  return o }
process(f): readAllLines (NoSuchFile->Missing, bad UTF-8->Corrupt); 1 line, 6 fields, id S\d{4,5},
            5 marks integer 0..100 else Corrupt; return OK(sum of marks)
```

## Stage 3 – Implement and measure (Student B, 3 marks)

**Test data (10 000 paths):** 200 files missing (every 50th path is never created), 250 corrupt in five ways (empty, non-numeric, out of range, truncated, binary garbage), 9 550 valid; expected sum of valid totals 2 387 432.

**Hand-checked small set (12 paths, `small`):**

| File | Content | Expected | Program |
|---|---|---|---|
| s01–s05 | valid (totals 400, 300, 0, 500, 300) | OK | OK (sum 1 500) |
| s06 | `abc` mark | CORRUPT | CORRUPT |
| s07 | mark 101 | CORRUPT | CORRUPT |
| s08 | empty file | CORRUPT | CORRUPT |
| s09 | only 3 marks | CORRUPT | CORRUPT |
| s10, s11 | do not exist | MISSING | MISSING |
| poison | throws `AssertionError` (injected Error) | ERROR | ERROR (via `ExecutionException`) |

Hand count `OK=5 CORRUPT=4 MISSING=2 ERROR=1 sum=1500`; program output identical – **PASS**. A second test (`robust`) with a 3-second file and a 500 ms timeout finished in 519 ms with the slow file recorded as ERROR "timeout" and the run complete.

**Timings – pool of 1, 2, 4, 8 (and 16, 32 extra), all 42 runs produced the correct summary (`bench_results.csv`)**

| Threads | A: real local files, best of 5 (ms) | speed-up | B: +1 ms simulated storage latency per file, best of 2 (ms) | speed-up |
|---|---|---|---|---|
| 1 | 141 | 1.00x | 11 721 | 1.00x |
| 2 | 81 | 1.74x | 5 738 | 2.04x |
| 4 | 60 | 2.35x | 2 862 | 4.10x |
| 8 | 62 | 2.27x | 1 429 | 8.20x |
| 16 | 62 | 2.27x | 711 | 16.49x |
| 32 | 66 | 2.14x | 359 | 32.65x |

Scenario A measures the real files (tiny, in the OS cache) on a 2-vCPU machine; scenario B adds `Thread.sleep(1 ms)` per file to *simulate* slow storage and is labelled as such – it is not a measurement of a real network disk.

**Failures not handled correctly:** none among the injected cases in the final design (all 42 benchmark runs and both small tests produced the expected counts). The first design question we checked was whether an `Error` thrown in a task is lost – it is not, because layer 2 records it. Weak points that remain are listed under Stage 4.

## Stage 4 – Defend the design (joint, 2 marks)

**Recommended pool size.** For purely local, cached files (A) speed-up stops at about 4 threads (2 vCPUs × 2); 8, 16, 32 give no gain and 32 is slightly slower (66 vs 60 ms) because of context switching and contention. For I/O-latency-bound work (B) threads keep helping almost linearly, because sleeping/waiting threads do not use the CPU. The rule of thumb is threads ≈ cores × (1 + wait time / compute time): about 1–2 × cores for local disk and more (limited by the storage system) for slow/networked storage. **For this problem on local disks: 2 × cores (4 on our machine); if the storage is slow, raise it stepwise while the time keeps dropping.** More threads did not always help because the CPU/disk becomes the bottleneck and extra threads only add scheduling overhead.

**Why the summary is complete and correct:** every task writes exactly one `Outcome` under its own file name; anything that escapes the task is recorded by the collector with `putIfAbsent`, so one entry exists per file; `summarise` checks `results.size() == files` and `OK+CORRUPT+MISSING+ERROR == files`; the map's keyed `put` is idempotent so duplicates cannot inflate counts; and the totals were verified against the hand-checked set and against the generator's expected counts in all 42 runs.

**One remaining limitation:** results live only in memory – a crash of the JVM mid-run loses everything (no checkpointing/restart). Also: `Future.get(timeout)` is measured from the moment the collector calls `get` (sequentially), not from the task's start; tasks stuck in non-interruptible I/O ignore `cancel(true)`; and holding 10 000 `Future`s is fine here but would need a bounded queue / `CompletionService` for millions of files.

## Alternative concept and complexity analysis

Each alternative was run in a **separate cold JVM** (no warm-up) so memory figures are comparable. `VmPeak`/`VmHWM` come from `/proc/self/status` (peak virtual / peak resident memory).

| Approach | latency | time (ms) | peak live threads | VmHWM (resident) | VmPeak (virtual) | correct summary |
|---|---|---|---|---|---|---|
| Fixed pool (8) | none | 396 | 14 | 145 MB | 4.2 GB | yes |
| Fixed pool (8) | 1 ms | 1 611 | 14 | 153 MB | 4.2 GB | yes |
| `parallelStream`, handled | none | 307 | 7 | 126 MB | 4.2 GB | yes |
| `parallelStream`, handled | 1 ms | 5 890 | 7 | 130 MB | 4.2 GB | yes |
| `parallelStream`, **not handled** | none | 17 | 7 | 71 MB | – | **no – aborted after 38 of 10 000 files** |
| Thread per file | none | 2 290 | 21 | 192 MB | 4.2 GB | yes |
| Thread per file | 1 ms | 2 152 | 49 | 184 MB | 4.2 GB | yes |
| Thread per file | 500 ms | 3 662 | **3 781** | **475 MB** | **8.0 GB** | yes |

- **Parallel streams:** run on the common `ForkJoinPool`, whose parallelism here is only `cores − 1 = 1`, so I/O-latency work was ~3.7x slower than the pool of 8 (5 890 vs 1 611 ms) and the pool size is not under the program's control. **Failure handling:** an exception thrown out of the lambda aborts the whole stream – the naive version stopped after 38 files at the first corrupt file (`score_02527.txt`); it works only if every lambda catches its own exceptions, and there are no `Future`s for timeouts/cancellation.
- **One thread per file:** it still produced the right answer, but thread creation dominates (2.3 s vs 0.4 s for the pool, ~6x slower) and memory grows with the number of simultaneously alive threads: with 500 ms latency **3 781 threads were alive at once**, peak resident memory rose from ~145 MB to 475 MB and virtual memory from 4.2 GB to 8.0 GB. In the worst case memory = threads × stack size (≈ 10 000 × 1 MB ≈ 10 GB reserved) and the JVM can fail with `OutOfMemoryError: unable to create native thread`. A failure in one thread kills only that thread, but its result is lost unless the thread records it itself – there is no `Future` to carry the exception.
- **Complexity:** time ≈ O(n/p · t) for the pool (n files, p threads, t time per file) – confirmed by scenario B (1.43 s for p = 8 vs 11.7 s for p = 1); memory O(p) for the pool (plus O(n) for the queued tasks and futures) vs O(n) threads in the worst case for thread-per-file.

---

# Appendix – raw evidence in the repository

`Task01/output_*.txt`, `Task02/output_*.txt`, `Task03/output_SalesReport.txt`, `output_mixed_leak.txt`, `output_jdb_session.txt`, `sales.log`, `Task04/output_Stations.txt`, `Task05/output_*.txt`, `Task06/output_*.txt`, `Task07/output_*.txt`, `Task07/bench_results.csv`. Each student must add their own screenshots of running every program.
