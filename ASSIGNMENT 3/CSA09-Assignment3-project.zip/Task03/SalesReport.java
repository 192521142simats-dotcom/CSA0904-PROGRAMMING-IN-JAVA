import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.logging.*;

/**
 * Q3 - Daily sales report. Three implementations:
 *   naive   : manual close() at the end of the try block (leaks when an exception occurs)
 *   finally : try-catch-finally with manual close() (correct but verbose)
 *   twr     : try-with-resources
 * Open file handles are counted from /proc/self/fd (real OS-level evidence).
 */
public class SalesReport {
    static final Logger LOG = Logger.getLogger("sales");

    static int openFds() {
        String[] a = new File("/proc/self/fd").list();
        return a == null ? -1 : a.length;
    }

    // ---------- version 1: naive manual close (LEAKS on exception) ----------
    static long sumNaive(File f) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(f));
        long s = 0; String line;
        while ((line = br.readLine()) != null) s += Long.parseLong(line.trim());  // may throw
        br.close();                                                                 // skipped on exception
        return s;
    }

    // ---------- version 2: try-catch-finally with manual close ----------
    static long sumFinally(File f) throws IOException {
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(f));
            long s = 0; String line;
            while ((line = br.readLine()) != null) s += Long.parseLong(line.trim());
            return s;
        } finally {
            if (br != null) {
                try { br.close(); } catch (IOException e) { LOG.warning("close failed: " + e); }
            }
        }
    }

    // ---------- version 3: try-with-resources ----------
    static long sumTwr(File f) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            long s = 0; String line;
            while ((line = br.readLine()) != null) s += Long.parseLong(line.trim());
            return s;
        }
    }

    interface Summer { long sum(File f) throws IOException; }

    /** Generates the report. Returns {ok, failed, leakedHandles, tooManyOpen}. */
    static long[] run(String mode, File dir, int files, File out) throws IOException {
        Summer summer = switch (mode) {
            case "naive"   -> SalesReport::sumNaive;
            case "finally" -> SalesReport::sumFinally;
            default        -> SalesReport::sumTwr;
        };
        int before = openFds();
        long ok = 0, failed = 0, tooMany = 0;
        PrintWriter w = new PrintWriter(new FileWriter(out));
        try {
            for (int i = 1; i <= files; i++) {
                File f = new File(dir, "store" + i + ".txt");
                try {
                    long total = summer.sum(f);
                    w.println("store" + i + "," + total);
                    ok++;
                } catch (IOException | NumberFormatException e) {
                    failed++;
                    if (String.valueOf(e.getMessage()).contains("Too many open files")) tooMany++;
                    LOG.log(Level.WARNING, "FAILED file=" + f.getName() + " cause=" + e);
                    w.println("store" + i + ",ERROR");
                }
            }
        } finally {
            w.close();
        }
        int after = openFds();
        return new long[]{ok, failed, after - before, tooMany};
    }

    /** Creates data files; every 'badEvery'-th file contains a corrupt line part-way through. */
    static File makeData(int files, int badEvery) throws IOException {
        File dir = new File("data"); dir.mkdirs();
        for (int i = 1; i <= files; i++) {
            try (PrintWriter pw = new PrintWriter(new File(dir, "store" + i + ".txt"))) {
                pw.println(100 * i); pw.println(250);
                if (badEvery > 0 && i % badEvery == 0) pw.println("CORRUPT#");   // fails part-way
                pw.println(75);
            }
        }
        return dir;
    }

    // ---------- suppressed exception + closing order demo ----------
    static class Res implements AutoCloseable {
        final String name; final boolean failOnClose;
        Res(String n, boolean f) { name = n; failOnClose = f; System.out.println("  open  " + n); }
        public void close() throws IOException {
            System.out.println("  close " + name);
            if (failOnClose) throw new IOException("close failed for " + name);
        }
    }

    static void suppressedDemo() {
        System.out.println("--- try-with-resources: closing order + suppressed exception ---");
        try (Res a = new Res("A(reader)", false);
             Res b = new Res("B(writer)", true)) {
            System.out.println("  body throws");
            throw new IllegalStateException("primary: body failed");
        } catch (Exception e) {
            System.out.println("  caught primary : " + e);
            for (Throwable s : e.getSuppressed()) System.out.println("  suppressed     : " + s);
        }
    }

    public static void main(String[] args) throws Exception {
        LogManager.getLogManager().reset();
        FileHandler fh = new FileHandler("sales.log", false);
        fh.setFormatter(new SimpleFormatter());
        LOG.addHandler(fh);

        if (args.length > 0 && args[0].equals("suppressed")) { suppressedDemo(); return; }

        String mode = args.length > 0 ? args[0] : "twr";
        int files = args.length > 1 ? Integer.parseInt(args[1]) : 5;
        int badEvery = args.length > 2 ? Integer.parseInt(args[2]) : 3;
        File dir = makeData(files, badEvery);
        long[] r = run(mode, dir, files, new File("summary_" + mode + ".csv"));
        System.out.printf("mode=%-8s files=%d ok=%d failed=%d leakedHandles=%d tooManyOpenFilesErrors=%d%n",
                mode, files, r[0], r[1], r[2], r[3]);
    }
}
