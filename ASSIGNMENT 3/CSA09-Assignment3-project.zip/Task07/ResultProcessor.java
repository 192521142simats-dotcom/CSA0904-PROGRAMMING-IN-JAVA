import java.io.*;
import java.lang.management.*;
import java.nio.charset.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.stream.*;

/**
 * Q7 - Concurrent, fault-tolerant semester result processor.
 *
 * Design:  ExecutorService(fixed pool)  +  Callable<Outcome> per file  +  Future for completion/timeout/Error capture
 *          ConcurrentHashMap<fileName,Outcome> for the shared results (many writers, keyed => idempotent, no global lock)
 *          Two-layer failure handling:
 *            layer 1 (inside the Callable)  : expected failures (missing / corrupt / I-O / runtime bug) -> recorded as an Outcome
 *            layer 2 (Future.get in collector): anything that escapes (Error, timeout, cancellation) -> recorded as ERROR
 *          Completeness invariant: results.size() == files.size()  and  OK+CORRUPT+MISSING+ERROR == files.size()
 */
public class ResultProcessor {
    enum Status { OK, CORRUPT, MISSING, ERROR }
    record Outcome(String file, Status status, int total, String detail) { }

    static class ScoreFileException extends Exception {
        ScoreFileException(String m) { super(m); }
        ScoreFileException(String m, Throwable c) { super(m, c); }
    }
    static class MissingFileException extends ScoreFileException {
        MissingFileException(String m, Throwable c) { super(m, c); }
    }
    static class CorruptFileException extends ScoreFileException {
        CorruptFileException(String m) { super(m); }
        CorruptFileException(String m, Throwable c) { super(m, c); }
    }

    static volatile int latencyMs = 0;            // SIMULATED storage latency per file (0 = real local disk only)
    static final AtomicInteger started = new AtomicInteger();

    // ------------------------------------------------------------------ read + validate + compute
    static Outcome process(Path p) throws ScoreFileException {
        String name = p.getFileName().toString();
        started.incrementAndGet();
        if (name.startsWith("poison")) throw new AssertionError("injected unexpected Error for " + name);   // test hook
        List<String> lines;
        try {
            lines = Files.readAllLines(p, StandardCharsets.UTF_8);
        } catch (NoSuchFileException e) {
            throw new MissingFileException(name + " does not exist", e);
        } catch (CharacterCodingException e) {                    // invalid UTF-8 / binary garbage
            throw new CorruptFileException(name + " is not valid text", e);
        } catch (IOException e) {
            throw new ScoreFileException(name + " I/O error: " + e, e);
        }
        if (lines.size() != 1) throw new CorruptFileException(name + " has " + lines.size() + " lines, expected 1");
        String[] f = lines.get(0).split(",", -1);
        if (f.length != 6) throw new CorruptFileException(name + " has " + f.length + " fields, expected 6");
        if (!f[0].matches("S\\d{4,5}")) throw new CorruptFileException(name + " bad student id '" + f[0] + "'");
        int total = 0;
        for (int k = 1; k <= 5; k++) {
            try {
                int m = Integer.parseInt(f[k].trim());
                if (m < 0 || m > 100) throw new CorruptFileException(name + " mark out of range: " + m);
                total += m;
            } catch (NumberFormatException e) {
                throw new CorruptFileException(name + " non-numeric mark '" + f[k] + "'", e);
            }
        }
        return new Outcome(name, Status.OK, total, "");
    }

    /** Layer 1: the Callable converts every expected failure into an Outcome, so a bad file never kills a worker. */
    static Callable<Outcome> task(Path p, ConcurrentHashMap<String, Outcome> results) {
        return () -> {
            String name = p.getFileName().toString();
            if (name.startsWith("slow")) Thread.sleep(3000);          // test hook for timeout handling
            if (latencyMs > 0) Thread.sleep(latencyMs);
            Outcome o;
            try {
                o = process(p);
            } catch (MissingFileException e) {
                o = new Outcome(name, Status.MISSING, 0, e.getMessage());
            } catch (CorruptFileException e) {
                o = new Outcome(name, Status.CORRUPT, 0, e.getMessage());
            } catch (ScoreFileException | RuntimeException e) {
                o = new Outcome(name, Status.ERROR, 0, e.toString());
            }
            results.put(name, o);
            return o;
        };
    }

    record Summary(int files, int ok, int corrupt, int missing, int error, long sumTotals, boolean complete, long millis,
                   Map<String, Outcome> results) { }

    static Summary summarise(Map<String, Outcome> r, int files, long millis) {
        int[] c = new int[4]; long sum = 0;
        for (Outcome o : r.values()) { c[o.status().ordinal()]++; if (o.status() == Status.OK) sum += o.total(); }
        boolean complete = r.size() == files && c[0] + c[1] + c[2] + c[3] == files;
        return new Summary(files, c[0], c[1], c[2], c[3], sum, complete, millis, r);
    }

    // ------------------------------------------------------------------ the recommended design
    static Summary runPool(List<Path> files, int threads, long timeoutMs) throws InterruptedException {
        ConcurrentHashMap<String, Outcome> results = new ConcurrentHashMap<>();
        ExecutorService pool = Executors.newFixedThreadPool(threads);
        long t0 = System.nanoTime();
        LinkedHashMap<Path, Future<Outcome>> futures = new LinkedHashMap<>();
        for (Path p : files) futures.put(p, pool.submit(task(p, results)));
        for (Map.Entry<Path, Future<Outcome>> e : futures.entrySet()) {          // layer 2
            String name = e.getKey().getFileName().toString();
            try {
                e.getValue().get(timeoutMs, TimeUnit.MILLISECONDS);
            } catch (ExecutionException ex) {
                results.putIfAbsent(name, new Outcome(name, Status.ERROR, 0, "unexpected: " + ex.getCause()));
            } catch (TimeoutException ex) {
                e.getValue().cancel(true);
                results.putIfAbsent(name, new Outcome(name, Status.ERROR, 0, "timeout after " + timeoutMs + " ms"));
            } catch (CancellationException ex) {
                results.putIfAbsent(name, new Outcome(name, Status.ERROR, 0, "cancelled"));
            }
        }
        pool.shutdown();
        pool.awaitTermination(1, TimeUnit.MINUTES);
        return summarise(results, files.size(), (System.nanoTime() - t0) / 1_000_000);
    }

    // ------------------------------------------------------------------ data generation
    static final int N = 10_000;
    static long expectedSum = 0; static int expOk, expCorrupt, expMissing;

    static void generate(Path dir) throws IOException {
        Files.createDirectories(dir);
        expectedSum = 0; expOk = expCorrupt = expMissing = 0;
        for (int i = 1; i <= N; i++) {
            Path p = dir.resolve(String.format("score_%05d.txt", i));
            String id = String.format("S%05d", i);
            if (i % 50 == 0) { expMissing++; continue; }                                  // missing: never created
            if (i % 40 == 7) {                                                           // corrupt, five different ways
                expCorrupt++;
                switch ((i / 40) % 5) {
                    case 0 -> Files.write(p, new byte[0]);                                         // empty
                    case 1 -> Files.writeString(p, id + ",abc,80,70,60,50\n");                     // non-numeric
                    case 2 -> Files.writeString(p, id + ",150,80,70,60,50\n");                     // out of range
                    case 3 -> Files.writeString(p, id + ",80,70,60\n");                            // truncated
                    default -> Files.write(p, new byte[]{(byte) 0xFF, (byte) 0xFE, (byte) 0xC3, 0x28, '\n'}); // binary garbage
                }
                continue;
            }
            int t = 0; StringBuilder sb = new StringBuilder(id);
            for (int k = 1; k <= 5; k++) { int m = (i * k * 7 + k * 13) % 101; t += m; sb.append(',').append(m); }
            Files.writeString(p, sb.append('\n').toString());
            expOk++; expectedSum += t;
        }
    }

    static List<Path> listFiles(Path dir) {
        List<Path> l = new ArrayList<>();
        for (int i = 1; i <= N; i++) l.add(dir.resolve(String.format("score_%05d.txt", i)));   // manifest, includes missing ones
        return l;
    }

    // ------------------------------------------------------------------ modes
    static void small() throws Exception {
        Path d = Files.createTempDirectory("small");
        Files.writeString(d.resolve("s01.txt"), "S0001,80,90,70,60,100\n");   // 400
        Files.writeString(d.resolve("s02.txt"), "S0002,55,45,65,75,60\n");    // 300
        Files.writeString(d.resolve("s03.txt"), "S0003,0,0,0,0,0\n");         // 0   boundary
        Files.writeString(d.resolve("s04.txt"), "S0004,100,100,100,100,100\n");// 500 boundary
        Files.writeString(d.resolve("s05.txt"), "S0005,40,50,60,70,80\n");    // 300
        Files.writeString(d.resolve("s06.txt"), "S0006,abc,90,80,70,60\n");   // corrupt: non-numeric
        Files.writeString(d.resolve("s07.txt"), "S0007,101,90,80,70,60\n");   // corrupt: out of range
        Files.write(d.resolve("s08.txt"), new byte[0]);                       // corrupt: empty
        Files.writeString(d.resolve("s09.txt"), "S0009,50,60,70\n");          // corrupt: truncated
        // s10, s11 intentionally missing; poison.txt throws an Error
        List<Path> files = new ArrayList<>();
        for (int i = 1; i <= 11; i++) files.add(d.resolve(String.format("s%02d.txt", i)));
        files.add(d.resolve("poison.txt"));
        Summary s = runPool(files, 4, 5000);
        System.out.println("file        status   total  detail");
        new TreeMap<>(s.results()).values().forEach(o -> System.out.printf("%-11s %-8s %5d  %s%n", o.file(), o.status(), o.total(), o.detail()));
        System.out.printf("%nHAND-CHECKED EXPECTATION: files=12 OK=5 CORRUPT=4 MISSING=2 ERROR=1 sumOfTotals=1500%n");
        System.out.printf("PROGRAM RESULT           : files=%d OK=%d CORRUPT=%d MISSING=%d ERROR=%d sumOfTotals=%d complete=%b%n",
                s.files(), s.ok(), s.corrupt(), s.missing(), s.error(), s.sumTotals(), s.complete());
        boolean pass = s.files() == 12 && s.ok() == 5 && s.corrupt() == 4 && s.missing() == 2 && s.error() == 1 && s.sumTotals() == 1500 && s.complete();
        System.out.println("VERDICT: " + (pass ? "PASS - summary matches hand count" : "FAIL"));
    }

    static void robust() throws Exception {
        Path d = Files.createTempDirectory("robust");
        Files.writeString(d.resolve("a.txt"), "S0001,1,2,3,4,5\n");
        Files.writeString(d.resolve("slow1.txt"), "S0002,1,2,3,4,5\n");     // takes 3 s -> will time out at 500 ms
        Files.writeString(d.resolve("b.txt"), "S0003,10,20,30,40,50\n");
        List<Path> files = List.of(d.resolve("a.txt"), d.resolve("slow1.txt"), d.resolve("poison.txt"), d.resolve("b.txt"), d.resolve("gone.txt"));
        Summary s = runPool(files, 2, 500);
        new TreeMap<>(s.results()).values().forEach(o -> System.out.printf("%-11s %-8s %5d  %s%n", o.file(), o.status(), o.total(), o.detail()));
        System.out.printf("files=%d OK=%d CORRUPT=%d MISSING=%d ERROR=%d complete=%b time=%d ms%n", s.files(), s.ok(), s.corrupt(), s.missing(), s.error(), s.complete(), s.millis());
    }

    static double median(double[] a) { double[] b = a.clone(); Arrays.sort(b); return b[b.length / 2]; }

    static void bench(Path dir) throws Exception {
        List<Path> files = listFiles(dir);
        System.out.printf("expected: OK=%d CORRUPT=%d MISSING=%d sumOfTotals=%d%n", expOk, expCorrupt, expMissing, expectedSum);
        PrintWriter csv = new PrintWriter("bench_results.csv"); csv.println("scenario,threads,rep,millis,ok,corrupt,missing,error,sumTotals,complete,correct");
        for (int scenario = 0; scenario < 2; scenario++) {
            latencyMs = scenario == 0 ? 0 : 1;
            int reps = scenario == 0 ? 5 : 2;
            String label = scenario == 0 ? "A: real local files, no added latency" : "B: + 1 ms simulated storage latency per file";
            System.out.println("\n== Scenario " + label + " ==");
            if (scenario == 0) runPool(files, 2, 30000);                       // JIT / page-cache warm-up
            System.out.println("threads | best ms | median ms | speed-up vs 1 | summary correct?");
            double base = 0;
            for (int th : new int[]{1, 2, 4, 8, 16, 32}) {
                double[] ms = new double[reps]; boolean allCorrect = true;
                for (int r = 0; r < reps; r++) {
                    Summary s = runPool(files, th, 30000);
                    ms[r] = s.millis();
                    boolean ok = s.ok() == expOk && s.corrupt() == expCorrupt && s.missing() == expMissing && s.error() == 0 && s.sumTotals() == expectedSum && s.complete();
                    allCorrect &= ok;
                    csv.printf("%s,%d,%d,%d,%d,%d,%d,%d,%d,%b,%b%n", scenario == 0 ? "A" : "B", th, r + 1, s.millis(), s.ok(), s.corrupt(), s.missing(), s.error(), s.sumTotals(), s.complete(), ok);
                }
                double best = Arrays.stream(ms).min().getAsDouble();
                if (th == 1) base = best;
                System.out.printf("%7d | %7.0f | %9.0f | %13.2fx | %s%n", th, best, median(ms), base / best, allCorrect ? "yes" : "NO");
            }
        }
        csv.close();
        latencyMs = 0;
    }

    // ------------------------------------------------------------------ alternatives (each run in its own JVM)
    static String mem() throws IOException {
        String vmHwm = "", vmPeak = "";
        for (String l : Files.readAllLines(Path.of("/proc/self/status"))) {
            if (l.startsWith("VmHWM")) vmHwm = l.replaceAll("\\s+", " ");
            if (l.startsWith("VmPeak")) vmPeak = l.replaceAll("\\s+", " ");
        }
        return vmPeak + " | " + vmHwm + " | peak live threads=" + ManagementFactory.getThreadMXBean().getPeakThreadCount();
    }

    static void altParallelStream(Path dir, boolean handled, int lat) throws Exception {
        latencyMs = lat;
        List<Path> files = listFiles(dir);
        ConcurrentHashMap<String, Outcome> results = new ConcurrentHashMap<>();
        System.out.println("commonPool parallelism = " + ForkJoinPool.commonPool().getParallelism() + " (cores=" + Runtime.getRuntime().availableProcessors() + ")");
        long t0 = System.nanoTime();
        try {
            files.parallelStream().forEach(p -> {
                try {
                    if (latencyMs > 0) Thread.sleep(latencyMs);
                    results.put(p.getFileName().toString(), process(p));
                } catch (ScoreFileException | InterruptedException e) {
                    if (handled) {
                        Status st = e instanceof MissingFileException ? Status.MISSING : e instanceof CorruptFileException ? Status.CORRUPT : Status.ERROR;
                        results.put(p.getFileName().toString(), new Outcome(p.getFileName().toString(), st, 0, e.getMessage()));
                    } else throw new RuntimeException(e);                     // typical naive lambda: propagate
                }
            });
        } catch (RuntimeException e) {
            System.out.println("RUN ABORTED by first failure: " + e.getCause());
            System.out.println("files recorded before abort: " + results.size() + " of " + files.size() + " (summary would be INCOMPLETE)");
        }
        long ms = (System.nanoTime() - t0) / 1_000_000;
        Summary s = summarise(results, files.size(), ms);
        System.out.printf("parallelStream handled=%b latency=%dms: time=%d ms OK=%d CORRUPT=%d MISSING=%d recorded=%d complete=%b%n", handled, lat, ms, s.ok(), s.corrupt(), s.missing(), results.size(), s.complete());
        System.out.println(mem());
    }

    static void altThreadPerFile(Path dir, int lat) throws Exception {
        latencyMs = lat;
        List<Path> files = listFiles(dir);
        ConcurrentHashMap<String, Outcome> results = new ConcurrentHashMap<>();
        CountDownLatch done = new CountDownLatch(files.size());
        long t0 = System.nanoTime(); int created = 0; String failure = null;
        try {
            for (Path p : files) {
                Thread t = new Thread(() -> {
                    try { results.put(p.getFileName().toString(), task(p, results).call()); }
                    catch (Exception e) { /* ignored */ }
                    finally { done.countDown(); }
                });
                t.start(); created++;
            }
        } catch (Throwable e) {
            failure = e.toString();
            for (int i = created; i < files.size(); i++) done.countDown();
        }
        done.await();
        long ms = (System.nanoTime() - t0) / 1_000_000;
        Summary s = summarise(results, files.size(), ms);
        System.out.printf("thread-per-file latency=%dms: threads created=%d time=%d ms OK=%d CORRUPT=%d MISSING=%d recorded=%d complete=%b failure=%s%n", lat, created, ms, s.ok(), s.corrupt(), s.missing(), results.size(), s.complete(), failure);
        System.out.println(mem());
    }

    static void altPool(Path dir, int threads, int lat) throws Exception {
        latencyMs = lat;
        Summary s = runPool(listFiles(dir), threads, 30000);
        System.out.printf("fixed pool(%d) latency=%dms: time=%d ms OK=%d CORRUPT=%d MISSING=%d complete=%b%n", threads, lat, s.millis(), s.ok(), s.corrupt(), s.missing(), s.complete());
        System.out.println(mem());
    }

    public static void main(String[] args) throws Exception {
        String mode = args.length > 0 ? args[0] : "small";
        Path dir = Path.of("data");
        switch (mode) {
            case "small" -> small();
            case "robust" -> robust();
            case "gen" -> { generate(dir); System.out.printf("generated %d paths: OK=%d CORRUPT=%d MISSING=%d (expected sumOfTotals=%d)%n", N, expOk, expCorrupt, expMissing, expectedSum); }
            case "bench" -> { generate(dir); bench(dir); }
            case "ps-naive" -> { generate(dir); altParallelStream(dir, false, 0); }
            case "ps-handled" -> { generate(dir); altParallelStream(dir, true, Integer.parseInt(args[1])); }
            case "tpf" -> { generate(dir); altThreadPerFile(dir, Integer.parseInt(args[1])); }
            case "pool" -> { generate(dir); altPool(dir, Integer.parseInt(args[1]), Integer.parseInt(args[2])); }
            default -> System.out.println("unknown mode");
        }
    }
}
