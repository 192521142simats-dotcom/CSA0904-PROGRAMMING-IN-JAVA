import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/** Q4 - Four scanner stations: Thread vs Runnable, life cycle, priorities, daemon, executor. */
public class Stations {
    static final int[] BATCH = {30, 30, 30, 30};           // equal batches so the finish order depends on scheduling
    static final String[] NAME = {"Station-1", "Station-2", "Station-3", "Station-4"};
    static final AtomicInteger total = new AtomicInteger();
    static final List<String> finishOrder = Collections.synchronizedList(new ArrayList<>());

    static void scan(String name, int scripts) {
        for (int i = 0; i < scripts; i++) {
            try { Thread.sleep(2 + ThreadLocalRandom.current().nextInt(3)); }   // 2-4 ms per script
            catch (InterruptedException e) { return; }
            total.incrementAndGet();
        }
        finishOrder.add(name);
    }

    // way 1: extend Thread
    static class StationThread extends Thread {
        final int scripts;
        StationThread(String name, int scripts) { super(name); this.scripts = scripts; }
        @Override public void run() { scan(getName(), scripts); }
    }

    // way 2: implement Runnable
    static class StationTask implements Runnable {
        final String name; final int scripts;
        StationTask(String name, int scripts) { this.name = name; this.scripts = scripts; }
        @Override public void run() { scan(name, scripts); }
    }

    static void reset() { total.set(0); finishOrder.clear(); }

    // ---------------------------------------------------------------
    static void basic() throws Exception {
        System.out.println("== Thread subclass (stations 1-2) and Runnable (stations 3-4) ==");
        reset();
        Thread[] t = {
            new StationThread(NAME[0], BATCH[0]), new StationThread(NAME[1], BATCH[1]),
            new Thread(new StationTask(NAME[2], BATCH[2]), NAME[2]),
            new Thread(new StationTask(NAME[3], BATCH[3]), NAME[3])
        };
        for (Thread x : t) System.out.println(x.getName() + " state before start(): " + x.getState());
        for (Thread x : t) x.start();
        Thread.sleep(10);
        for (Thread x : t) System.out.println(x.getName() + " state after 10 ms  : " + x.getState() + "  isAlive=" + x.isAlive());
        for (Thread x : t) x.join();                       // main waits here
        for (Thread x : t) System.out.println(x.getName() + " state after join()  : " + x.getState() + "  isAlive=" + x.isAlive());
        System.out.println("Finish order: " + finishOrder);
        System.out.println("TOTAL scripts scanned = " + total.get() + " (expected " + Arrays.stream(BATCH).sum() + ")");
    }

    static void runVsStart() throws Exception {
        System.out.println("== run() vs start() ==");
        Thread viaRun = new Thread(() -> System.out.println("  body executed by thread: " + Thread.currentThread().getName()), "Station-X");
        System.out.println("calling run()  :"); viaRun.run();
        Thread viaStart = new Thread(() -> System.out.println("  body executed by thread: " + Thread.currentThread().getName()), "Station-X");
        System.out.println("calling start():"); viaStart.start(); viaStart.join();
        // timing evidence: run() is sequential, start() is parallel
        long t0 = System.nanoTime();
        for (int i = 0; i < 4; i++) new Thread(() -> scan("r", 50)).run();
        long seq = (System.nanoTime() - t0) / 1_000_000;
        Thread[] ts = new Thread[4]; t0 = System.nanoTime();
        for (int i = 0; i < 4; i++) { ts[i] = new Thread(() -> scan("s", 50)); ts[i].start(); }
        for (Thread x : ts) x.join();
        long par = (System.nanoTime() - t0) / 1_000_000;
        System.out.println("4 x 50 scripts via run()  : " + seq + " ms (sequential, all on main)");
        System.out.println("4 x 50 scripts via start(): " + par + " ms (parallel)");
    }

    static void order10(boolean priorities) throws Exception {
        System.out.println(priorities ? "== 10 runs with priorities (Station-4 MAX, Station-3 MIN) ==" : "== 10 runs, default priority ==");
        Map<String, Integer> firstCount = new TreeMap<>();
        for (int run = 1; run <= 10; run++) {
            reset();
            Thread[] t = new Thread[4];
            for (int i = 0; i < 4; i++) t[i] = new Thread(new StationTask(NAME[i], BATCH[i]), NAME[i]);
            if (priorities) { t[3].setPriority(Thread.MAX_PRIORITY); t[2].setPriority(Thread.MIN_PRIORITY); }
            for (Thread x : t) x.start();
            for (Thread x : t) x.join();
            System.out.printf("run %2d: %s%n", run, finishOrder);
            firstCount.merge(finishOrder.get(0), 1, Integer::sum);
        }
        System.out.println("who finished first (count): " + firstCount);
    }

    static void daemon() throws Exception {
        System.out.println("== daemon station ==");
        reset();
        Thread d = new Thread(() -> {
            scan("Station-D(daemon)", 2000);               // ~6 s of work
            System.out.println("daemon finished its batch");   // never printed if JVM exits first
        }, "Station-D");
        d.setDaemon(true);
        d.start();
        Thread.sleep(100);
        System.out.println("main() ends now; daemon isAlive=" + d.isAlive() + ", scripts scanned so far=" + total.get());
    }

    static void nonDaemonControl() throws Exception {
        System.out.println("== same station as a normal (non-daemon) thread ==");
        reset();
        Thread d = new Thread(() -> { scan("Station-D", 100); System.out.println("normal thread finished its batch (JVM waited)"); }, "Station-D");
        d.start();
        Thread.sleep(50);
        System.out.println("main() ends now; thread isAlive=" + d.isAlive());
    }

    // ---------------------------------------------------------------
    // Alternative: ExecutorService fixed pool, n scripts, p threads
    static void executor() throws Exception {
        System.out.println("== ExecutorService vs hand-made threads: n=400 scripts, 5 ms/script ==");
        int n = 400;
        System.out.println("p | pool time (ms) | ideal n*5/p (ms) | thread-per-batch time (ms)");
        for (int p : new int[]{1, 2, 4, 8}) {
            ExecutorService pool = Executors.newFixedThreadPool(p);
            long t0 = System.nanoTime();
            List<Future<?>> fs = new ArrayList<>();
            for (int i = 0; i < n; i++) fs.add(pool.submit(() -> { try { Thread.sleep(5); } catch (InterruptedException e) { } }));
            for (Future<?> f : fs) f.get();
            long pool_ms = (System.nanoTime() - t0) / 1_000_000;
            pool.shutdown();
            // same work using p hand-made threads, each taking n/p scripts
            t0 = System.nanoTime();
            Thread[] ts = new Thread[p];
            for (int k = 0; k < p; k++) { ts[k] = new Thread(() -> { for (int i = 0; i < n / p; i++) try { Thread.sleep(5); } catch (InterruptedException e) { } }); ts[k].start(); }
            for (Thread x : ts) x.join();
            long thr_ms = (System.nanoTime() - t0) / 1_000_000;
            System.out.printf("%d | %14d | %16d | %d%n", p, pool_ms, n * 5 / p, thr_ms);
        }
        // four stations on a pool of 2: stations queue up (completion ~ n/p batches)
        reset();
        ExecutorService pool = Executors.newFixedThreadPool(2);
        List<Future<?>> fs = new ArrayList<>();
        long t0 = System.nanoTime();
        for (int i = 0; i < 4; i++) { final int k = i; fs.add(pool.submit(() -> scan(NAME[k], BATCH[k]))); }
        for (Future<?> f : fs) f.get();
        System.out.println("4 stations on pool of 2: finish order " + finishOrder + ", total=" + total.get()
                + ", time=" + (System.nanoTime() - t0) / 1_000_000 + " ms");
        pool.shutdown();
        System.out.println("Default thread stack size on this JVM (64-bit Linux) ~ 1 MB reserved per platform thread.");
    }

    public static void main(String[] args) throws Exception {
        String mode = args.length > 0 ? args[0] : "basic";
        switch (mode) {
            case "basic" -> basic();
            case "runvsstart" -> runVsStart();
            case "order10" -> order10(false);
            case "priority" -> order10(true);
            case "daemon" -> daemon();
            case "normal" -> nonDaemonControl();
            case "executor" -> executor();
            default -> System.out.println("unknown mode");
        }
    }
}
