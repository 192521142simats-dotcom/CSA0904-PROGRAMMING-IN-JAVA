#!/usr/bin/env bash
# Compile and run every task. Usage: ./run_all.sh   (needs JDK 17+; tested on OpenJDK 21)
# Output of each program is printed and also saved next to the source as output_*.txt when you redirect it yourself.
set -e
run() { echo; echo "================ $* ================"; "$@"; }
for t in Task01 Task02 Task03 Task04 Task05 Task06 Task07; do
  mkdir -p "$t/out"; javac -d "$t/out" "$t"/*.java
done
cd Task01; run java -cp out AtmSimulation; run java -cp out UncaughtDemo || true; run java -cp out AtmErrorCodes
javac -d /tmp/wrongorder catch_order_wrong/WrongOrder.java || true; cd ..
cd Task02; run java -cp out StorageDemo; run java -cp out StorageDemoNoCause; run java -cp out ExamPortal; run java -cp out StackTraceCost; cd ..
cd Task03; for m in naive finally twr; do rm -rf data; run java -cp out SalesReport $m 5 3; done; run java -cp out SalesReport suppressed; cd ..
cd Task04; for m in basic runvsstart order10 priority executor daemon normal; do run java -cp out Stations $m; done; cd ..
cd Task05; run java -cp out SeatBooking; run java -cp out SeatBookingUnsync; run java -cp out RaceDemo; run java -cp out SyncBench; cd ..
cd Task06; run java -cp out TokenCounter; run java -cp out TokenVariants while all 5 0 200; run java -cp out TokenVariants if all 5 0 200
run java -cp out TokenVariants while one 1 0 100; run java -cp out WalletTransfers all; run java -cp out QueueCounter; cd ..
cd Task07; run java -cp out ResultProcessor small; run java -cp out ResultProcessor robust; run java -cp out ResultProcessor bench; cd ..
