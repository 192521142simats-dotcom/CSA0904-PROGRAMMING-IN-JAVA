/** Q1 Student B - an uncaught exception to show a stack trace. */
public class UncaughtDemo {
    static int parseAmount(String s) { return Integer.parseInt(s); }
    static void withdraw(String s) { System.out.println("Withdrawing " + parseAmount(s)); }
    public static void main(String[] args) {
        withdraw("abc");          // nothing catches this
    }
}
