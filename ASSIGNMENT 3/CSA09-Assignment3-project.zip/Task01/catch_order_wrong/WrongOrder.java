/** Q1 Student B - broader catch placed BEFORE narrower: does not compile. */
public class WrongOrder {
    public static void main(String[] args) {
        try {
            Integer.parseInt("abc");
        } catch (Exception e) {                    // broad first
            System.out.println("generic");
        } catch (NumberFormatException e) {        // unreachable -> compile error
            System.out.println("number format");
        }
    }
}
