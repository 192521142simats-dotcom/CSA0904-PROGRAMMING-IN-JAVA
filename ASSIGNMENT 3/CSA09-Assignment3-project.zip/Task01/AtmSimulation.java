import java.io.*;
import java.util.*;

/** Q1 - ATM withdrawal: try / multi-catch / finally. */
class InsufficientFundsException extends Exception {          // checked (business rule)
    final double shortBy;
    InsufficientFundsException(String msg, double shortBy) { super(msg); this.shortBy = shortBy; }
}

class InvalidAmountException extends RuntimeException {       // unchecked (programming/input error)
    InvalidAmountException(String msg) { super(msg); }
}

public class AtmSimulation {
    static double balance = 5000.00;
    static int finallyRuns = 0;

    /** Reads the card file: first line = account number. Throws checked FileNotFoundException/IOException. */
    static String readCard(String path) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            return br.readLine();
        }
    }

    /** Core withdrawal. Throws checked InsufficientFundsException, unchecked InvalidAmountException. */
    static void dispense(double amount) throws InsufficientFundsException {
        if (amount <= 0) throw new InvalidAmountException("Amount must be positive: " + amount);
        if (amount > balance)
            throw new InsufficientFundsException("Insufficient funds. Balance=" + balance, amount - balance);
        balance -= amount;
    }

    static String withdraw(String cardFile, String accountText, String amountText) {
        String outcome;
        try {
            String card = readCard(cardFile);                   // FileNotFoundException / IOException
            int account = Integer.parseInt(accountText);        // NumberFormatException
            double amount = Double.parseDouble(amountText);     // NumberFormatException
            if (card == null || Integer.parseInt(card.trim()) != account)
                throw new SecurityException("Card does not match account");
            dispense(amount);                                   // InsufficientFundsException, InvalidAmountException
            outcome = "OK dispensed " + amount + ", new balance " + balance;
        } catch (FileNotFoundException e) {                     // narrower IOException subclass first
            outcome = "CATCH FileNotFoundException: card reader file missing -> " + e.getMessage();
        } catch (InsufficientFundsException e) {
            outcome = "CATCH InsufficientFundsException: " + e.getMessage() + ", short by " + e.shortBy;
        } catch (NumberFormatException | InvalidAmountException e) {   // multi-catch: both unchecked, unrelated
            outcome = "CATCH multi(NumberFormat|InvalidAmount): " + e.getClass().getSimpleName() + " - " + e.getMessage();
        } catch (IOException e) {                               // broader I/O failure after the narrow one
            outcome = "CATCH IOException: " + e.getMessage();
        } catch (RuntimeException e) {                          // last resort for unexpected unchecked
            outcome = "CATCH RuntimeException: " + e.getClass().getSimpleName() + " - " + e.getMessage();
        } finally {
            finallyRuns++;
            System.out.println("   [finally] card session closed / ATM screen reset (run #" + finallyRuns + ")");
        }
        return outcome;
    }

    public static void main(String[] args) throws Exception {
        File card = new File("card.txt");
        try (PrintWriter pw = new PrintWriter(card)) { pw.println("12345"); }

        String[][] tests = {
            {"T1 valid withdrawal",          "card.txt",    "12345", "1000"},
            {"T2 letters instead of number", "card.txt",    "12345", "abc"},
            {"T3 negative amount",           "card.txt",    "12345", "-200"},
            {"T4 more than balance",         "card.txt",    "12345", "999999"},
            {"T5 card-reader file missing",  "missing.txt", "12345", "500"},
            {"T6 non-numeric account",       "card.txt",    "12x45", "500"},
            {"T7 wrong account (Security)",  "card.txt",    "99999", "500"},
        };
        for (String[] t : tests) {
            System.out.println(t[0] + "  (file=" + t[1] + ", acct=" + t[2] + ", amt=" + t[3] + ")");
            System.out.println("   -> " + withdraw(t[1], t[2], t[3]));
        }
        System.out.println("finally executed " + finallyRuns + " times for " + tests.length + " inputs");

        // Optional interactive mode: java AtmSimulation interactive
        if (args.length > 0 && args[0].equals("interactive")) {
            Scanner sc = new Scanner(System.in);
            System.out.print("Account: "); String a = sc.nextLine();
            System.out.print("Amount : "); String m = sc.nextLine();
            System.out.println(withdraw("card.txt", a, m));
        }
    }
}
