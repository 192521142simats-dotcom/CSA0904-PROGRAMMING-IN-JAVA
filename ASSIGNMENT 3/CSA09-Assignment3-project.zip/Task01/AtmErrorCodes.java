import java.util.*;

/** Q1 Alternative concept: no exceptions - pre-validate with hasNextInt()/checks and return error codes. */
public class AtmErrorCodes {
    static double balance = 5000;
    static final int OK = 0, BAD_NUMBER = -1, NEGATIVE = -2, INSUFFICIENT = -3;

    static int withdraw(Scanner in) {
        if (!in.hasNextInt()) return BAD_NUMBER;      // check 1
        int amt = in.nextInt();
        if (amt <= 0) return NEGATIVE;                // check 2
        if (amt > balance) return INSUFFICIENT;       // check 3
        balance -= amt; return OK;
    }

    public static void main(String[] args) {
        String[] inputs = {"1000", "abc", "-200", "999999"};
        for (String s : inputs) System.out.println(s + " -> code " + withdraw(new Scanner(s)));
        // Micro-benchmark: cost of throw/catch vs returning a code
        int N = 2_000_000; long sink = 0;
        for (int w = 0; w < 3; w++) {                  // warm-up
            for (int i = 0; i < N; i++) { try { throw new IllegalStateException("x"); } catch (IllegalStateException e) { sink++; } }
        }
        long t0 = System.nanoTime();
        for (int i = 0; i < N; i++) { try { throw new IllegalStateException("x"); } catch (IllegalStateException e) { sink++; } }
        long tEx = System.nanoTime() - t0;
        t0 = System.nanoTime();
        for (int i = 0; i < N; i++) { sink += (i % 2 == 0) ? -1 : 0; }
        long tCode = System.nanoTime() - t0;
        System.out.printf("throw+catch: %.1f ns/op   error code: %.2f ns/op   (sink=%d)%n",
                tEx / (double) N, tCode / (double) N, sink);
    }
}
