# CSA09 – Programming in Java – Assignment 3 (CO3)

| | Student A | Student B |
|---|---|---|
| Name | `<<fill>>` | `<<fill>>` |
| Register number | `<<fill>>` | `<<fill>>` |
| Repository | `CSA09-<RegisterNumber>-Assignment3` | `CSA09-<RegisterNumber>-Assignment3` |

**Java version:** OpenJDK 21.0.12 (`javac 21.0.12.1`). Any JDK 17+ compiles everything.
**Machine used for the measurements:** 2 vCPU Linux VM. Timings on your own machine will differ – re-run and record your own numbers.

## Layout (one folder per task)

| Folder | Topic | Main programs | Evidence files |
|---|---|---|---|
| `Task01` | ATM – try / multi-catch / finally | `AtmSimulation`, `UncaughtDemo`, `AtmErrorCodes`, `catch_order_wrong/WrongOrder` | `output_*.txt` |
| `Task02` | Exam portal – custom exceptions, chaining | `StorageDemo` (Complete the Code), `StorageDemoNoCause`, `ExamPortal`, `StackTraceCost` | `output_*.txt` |
| `Task03` | Sales report – try-with-resources, debugging | `SalesReport` | `output_SalesReport.txt`, `output_mixed_leak.txt`, `output_jdb_session.txt`, `sales.log` |
| `Task04` | Scanner stations – threads | `Stations` | `output_Stations.txt` |
| `Task05` | Cinema booking – race conditions | `SeatBooking` (Complete the Code), `SeatBookingUnsync`, `RaceDemo`, `SyncBench` | `output_*.txt` |
| `Task06` | Deadlock + producer–consumer | `TokenCounter` (Complete the Code), `TokenVariants`, `WalletTransfers`, `QueueCounter` | `output_*.txt` |
| `Task07` | Concurrent fault-tolerant processor | `ResultProcessor` | `output_*.txt`, `bench_results.csv` |

`REPORT.md` / `REPORT.docx` is the joint report. `run_all.sh` compiles and runs everything.

## How to compile and run

```bash
cd TaskNN
mkdir -p out && javac -d out *.java
java -cp out <MainClass> [arguments]
```

| Task | Commands | Result in one line |
|---|---|---|
| Task01 | `java -cp out AtmSimulation`, `java -cp out UncaughtDemo`, `java -cp out AtmErrorCodes`; `javac catch_order_wrong/WrongOrder.java` (expected compile error) | 7 inputs hit 6 different paths; `finally` ran 7/7 times; broader-before-narrower catch does not compile |
| Task02 | `java -cp out StorageDemo` (prints the expected 3 lines), `StorageDemoNoCause`, `ExamPortal`, `StackTraceCost` | Cause is kept only if passed to the constructor; stack-trace capture costs 1.7–10x |
| Task03 | `java -cp out SalesReport naive\|finally\|twr 5 3`, `... SalesReport suppressed` | naive leaks 1 handle, other two 0; with `ulimit -n 150` naive fails healthy files too |
| Task04 | `java -cp out Stations basic\|runvsstart\|order10\|priority\|daemon\|normal\|executor` | finish order varies between runs; priorities have no reliable effect; daemon is killed when `main` ends |
| Task05 | `java -cp out SeatBooking` (expected `Seats sold: 10`), `SeatBookingUnsync`, `RaceDemo`, `SyncBench` | the plain unsynchronized program did not fail in 10 runs; the widened-window test double-booked every run (464 total) |
| Task06 | `java -cp out TokenCounter` (expected sum 210), `TokenVariants <while\|if> <all\|one> <cap> <delayMs> <runs>`, `WalletTransfers all`, `QueueCounter` | `if` gives wrong sums (27/200); `notify()` hangs 85/100 at capacity 1; lock ordering removes the deadlock |
| Task07 | `java -cp out ResultProcessor small\|robust\|bench\|pool 8 1\|ps-naive\|ps-handled 1\|tpf 1` | hand-checked set passes; 42/42 benchmark runs give the correct summary |

## Before you submit (things only you can do)
1. Fill in the name / register-number placeholders here and in `REPORT.md`.
2. Run every program yourself and add your own output screenshots to each task folder (both students, in their own repository).
3. Create the GitHub repository, commit task by task as you go (the commit history is checked), and paste the link in the report.
4. Re-run the measurements on your machine and replace the tables if your numbers differ.
