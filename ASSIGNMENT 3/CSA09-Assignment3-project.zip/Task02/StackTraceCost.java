/** Q2 Alternative analysis: cost of capturing a stack trace, and memory held by a chained exception. */
public class StackTraceCost {
    /** Exception that skips stack-trace capture (writableStackTrace = false). */
    static class LightException extends RuntimeException {
        LightException(String m) { super(m, null, false, false); }
    }

    static int recurse(int depth, int kind) {
        if (depth == 0) {
            if (kind == 0) throw new RuntimeException("with trace");
            throw new LightException("no trace");
        }
        return recurse(depth - 1, kind) + 1;
    }

    static double timeNs(int depth, int kind, int n) {
        for (int i = 0; i < 20000; i++) { try { recurse(depth, kind); } catch (RuntimeException e) { } } // warm-up
        long t0 = System.nanoTime();
        for (int i = 0; i < n; i++) { try { recurse(depth, kind); } catch (RuntimeException e) { } }
        return (System.nanoTime() - t0) / (double) n;
    }

    public static void main(String[] args) {
        System.out.println("depth | with stack trace (ns) | without (ns) | ratio");
        for (int d : new int[]{1, 10, 50, 100, 500}) {
            double a = timeNs(d, 0, 100_000), b = timeNs(d, 1, 100_000);
            System.out.printf("%5d | %20.0f | %12.0f | %.1fx%n", d, a, b, a / b);
        }
        // chain length vs stack frames held
        Throwable t = new RuntimeException("root");
        for (int i = 0; i < 5; i++) t = new Exception("wrap" + i, t);
        int frames = 0, objs = 0;
        for (Throwable x = t; x != null; x = x.getCause()) { objs++; frames += x.getStackTrace().length; }
        System.out.println("chain of " + objs + " exceptions holds " + frames + " StackTraceElements in total");
    }
}
