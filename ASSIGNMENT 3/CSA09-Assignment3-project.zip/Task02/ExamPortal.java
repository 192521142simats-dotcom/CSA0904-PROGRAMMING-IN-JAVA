import java.io.*;
import java.time.*;
import java.util.*;

/* ---------- Exception hierarchy ----------
 *  Throwable
 *   +-- Exception
 *   |    +-- ExamException            (checked, base for all portal rules)
 *   |         +-- ExamWindowClosedException     (checked)
 *   |         +-- NotRegisteredException        (checked)
 *   |         +-- FileTooLargeException         (checked)
 *   |         +-- SubmissionStorageException    (checked, wraps IOException)
 *   +-- RuntimeException
 *        +-- PortalConfigurationException       (unchecked, programmer/config bug)
 */
class PExamException extends Exception {
    PExamException(String m) { super(m); }
    PExamException(String m, Throwable c) { super(m, c); }
}
class ExamWindowClosedException extends PExamException {
    ExamWindowClosedException(String m) { super(m); }
}
class NotRegisteredException extends PExamException {
    NotRegisteredException(String m) { super(m); }
}
class FileTooLargeException extends PExamException {
    FileTooLargeException(String m) { super(m); }
}
class PStorageException extends PExamException {
    PStorageException(String m, Throwable c) { super(m, c); }
}
class PortalConfigurationException extends RuntimeException {
    PortalConfigurationException(String m) { super(m); }
}

/* ---------- Storage layer ---------- */
class PStorage {
    static final long QUOTA_KB = 1000;
    private long used = 0;
    void store(String file, long kb, boolean keepCause) throws PStorageException {
        try {
            if (file.startsWith("unmounted")) throw new FileNotFoundException("/data/submissions/ is not mounted");
            if (used + kb > QUOTA_KB) throw new IOException("Disk quota exceeded");
            used += kb;
        } catch (IOException e) {
            if (keepCause) throw new PStorageException("Could not store " + file, e);
            else            throw new PStorageException("Could not store " + file, null);   // cause lost
        }
    }
}

/* ---------- Service layer ---------- */
class PService {
    private final PStorage storage = new PStorage();
    private final Set<String> registered = Set.of("S101:CS101", "S102:CS101", "S103:MA201");
    private final LocalDateTime windowClose = LocalDateTime.of(2026, 11, 15, 12, 0);
    boolean keepCause = true;

    void submit(String student, String course, String file, long kb, LocalDateTime now)
            throws PExamException {
        if (now.isAfter(windowClose))
            throw new ExamWindowClosedException("Exam window closed at " + windowClose);
        if (!registered.contains(student + ":" + course))
            throw new NotRegisteredException(student + " is not registered for " + course);
        if (kb > 500)
            throw new FileTooLargeException(file + " is " + kb + " KB; limit is 500 KB");
        storage.store(file, kb, keepCause);                 // PStorageException propagates upward
    }
}

/* ---------- Controller layer: the only place that handles & talks to the student ---------- */
class PController {
    final PService service = new PService();
    String handle(String student, String course, String file, long kb, LocalDateTime now) {
        try {
            service.submit(student, course, file, kb, now);
            return "SUCCESS: " + file + " submitted";
        } catch (ExamWindowClosedException | NotRegisteredException | FileTooLargeException e) {
            return "REJECTED (" + e.getClass().getSimpleName() + "): " + e.getMessage();
        } catch (PStorageException e) {
            // log full chain for support staff; show friendly text to student
            System.out.println("   [LOG] " + e);
            Throwable c = e.getCause();
            System.out.println("   [LOG] getCause() = " + (c == null ? "null  <-- root cause LOST" : c));
            return "SORRY: your answer could not be saved right now. Please retry (ref: " + e.getMessage() + ")";
        } catch (PExamException e) {
            return "REJECTED: " + e.getMessage();
        }
    }
}

public class ExamPortal {
    public static void main(String[] args) {
        LocalDateTime open = LocalDateTime.of(2026, 11, 15, 10, 30);
        LocalDateTime late = LocalDateTime.of(2026, 11, 15, 12, 30);
        PController c = new PController();

        System.out.println("=== Student B: one scenario per exception (test table) ===");
        System.out.println("1 valid        -> " + c.handle("S101", "CS101", "a.pdf", 120, open));
        System.out.println("2 window closed-> " + c.handle("S101", "CS101", "a.pdf", 120, late));
        System.out.println("3 not registered-> " + c.handle("S999", "CS101", "a.pdf", 120, open));
        System.out.println("4 too large    -> " + c.handle("S101", "CS101", "big.pdf", 800, open));
        System.out.println("5 storage down -> " + c.handle("S102", "CS101", "unmounted1.pdf", 100, open));
        c.handle("S101", "CS101", "q1.pdf", 400, open);
        c.handle("S102", "CS101", "q2.pdf", 400, open);
        System.out.println("6 quota hit    -> " + c.handle("S103", "MA201", "q3.pdf", 300, open));

        System.out.println("\n=== Exception chaining: full chained stack trace ===");
        PStorage st = new PStorage();
        try { st.store("unmounted.pdf", 100, true); }
        catch (PStorageException e) {
            e.printStackTrace(System.out);
            System.out.println("getCause().getClass() = " + e.getCause().getClass().getName());
            System.out.println("getCause().getMessage() = " + e.getCause().getMessage());
        }

        System.out.println("\n=== Re-thrown WITHOUT cause (information lost) ===");
        try { st.store("unmounted.pdf", 100, false); }
        catch (PStorageException e) {
            e.printStackTrace(System.out);
            System.out.println("getCause() = " + e.getCause());
        }

        System.out.println("\n=== Propagation path (storage -> service -> controller) ===");
        PController c2 = new PController();
        System.out.println(c2.handle("S101", "CS101", "q1.pdf", 400, open));
        System.out.println(c2.handle("S102", "CS101", "q2.pdf", 400, open));
        System.out.println(c2.handle("S101", "CS101", "q3.pdf", 300, open));
    }
}
