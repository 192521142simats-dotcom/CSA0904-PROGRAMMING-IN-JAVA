import java.io.IOException;

/** Q2 follow-up: what if the IOException is NOT passed to the constructor? */
class ExamEx extends Exception {
    ExamEx(String m) { super(m); }
    ExamEx(String m, Throwable c) { super(m, c); }
}

class StorageNoCause {
    void save(String fileName, long sizeKb) throws ExamEx {
        try {
            if (sizeKb > 500) throw new IOException("Disk quota exceeded");
            System.out.println("Saved " + fileName);
        } catch (IOException e) {
            throw new ExamEx("Could not store " + fileName);      // cause dropped!
        }
    }
}

public class StorageDemoNoCause {
    public static void main(String[] args) {
        try {
            new StorageNoCause().save("answer02.pdf", 800);
        } catch (ExamEx e) {
            System.out.println("Error: " + e.getMessage());
            System.out.println("getCause() = " + e.getCause());
            try {
                System.out.println("Cause: " + e.getCause().getMessage());
            } catch (NullPointerException npe) {
                System.out.println("Cause line -> NullPointerException (getCause() is null)");
            }
            System.out.println("--- full stack trace (note: no 'Caused by:') ---");
            e.printStackTrace(System.out);
        }
    }
}
