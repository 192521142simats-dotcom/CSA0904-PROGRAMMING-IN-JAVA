import java.lang.management.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.locks.*;

/** Q6 Part A - hostel wallet transfers: deadlock, lock-ordering fix, tryLock alternative. */
public class WalletTransfers {
    static class Account {
        final int id; int balance; final ReentrantLock lock = new ReentrantLock();
        Account(int id, int bal) { this.id = id; this.balance = bal; }
    }

    // (1) Deadlock-prone: lock 'from' then 'to' in caller order
    static void transferUnsafe(Account from, Account to, int amt, int pauseMs) {
        synchronized (from) {
            if (pauseMs > 0) try { Thread.sleep(pauseMs); } catch (InterruptedException e) { }
            synchronized (to) { from.balance -= amt; to.balance += amt; }
        }
    }

    // (2) Fixed: always lock the account with the smaller id first
    static void transferOrdered(Account from, Account to, int amt, int pauseMs) {
        Account first = from.id < to.id ? from : to, second = first == from ? to : from;
        synchronized (first) {
            if (pauseMs > 0) try { Thread.sleep(pauseMs); } catch (InterruptedException e) { }
            synchronized (second) { from.balance -= amt; to.balance += amt; }
        }
    }

    // (3) Alternative: tryLock with timeout, back off and retry
    static boolean transferTry(Account from, Account to, int amt, long timeoutMs) throws InterruptedException {
        long end = System.nanoTime() + timeoutMs * 1_000_000;
        while (System.nanoTime() < end) {
            if (from.lock.tryLock(1, TimeUnit.MILLISECONDS)) {
                try {
                    if (to.lock.tryLock(1, TimeUnit.MILLISECONDS)) {
                        try { from.balance -= amt; to.balance += amt; return true; } finally { to.lock.unlock(); }
                    }
                } finally { from.lock.unlock(); }
            }
            Thread.sleep(ThreadLocalRandom.current().nextInt(1, 3));      // random back-off avoids livelock
        }
        return false;
    }

    static void detect(String label, Thread... ts) throws Exception {
        Thread.sleep(500);
        ThreadMXBean mx = ManagementFactory.getThreadMXBean();
        long[] ids = mx.findDeadlockedThreads();
        if (ids == null) { System.out.println(label + ": no deadlock detected"); return; }
        System.out.println(label + ": DEADLOCK detected among " + ids.length + " threads:");
        for (ThreadInfo ti : mx.getThreadInfo(ids))
            System.out.println("   " + ti.getThreadName() + " is " + ti.getThreadState() + ", waiting for lock " + ti.getLockName()
                    + " held by " + ti.getLockOwnerName());
    }

    public static void main(String[] args) throws Exception {
        String mode = args.length > 0 ? args[0] : "all";

        if (mode.equals("deadlock") || mode.equals("all")) {
            System.out.println("== Student B: transfers that reliably deadlock (A->B and B->A, 100 ms between the two locks) ==");
            Account a = new Account(1, 1000), b = new Account(2, 1000);
            Thread t1 = new Thread(() -> transferUnsafe(a, b, 100, 100), "T1(A->B)");
            Thread t2 = new Thread(() -> transferUnsafe(b, a, 50, 100), "T2(B->A)");
            t1.setDaemon(true); t2.setDaemon(true);
            t1.start(); t2.start();
            detect("unsafe", t1, t2);
            System.out.println("   T1 alive=" + t1.isAlive() + " T2 alive=" + t2.isAlive() + "  balances A=" + a.balance + " B=" + b.balance + " (no transfer completed)");
        }

        if (mode.equals("ordered") || mode.equals("all")) {
            System.out.println("\n== Fixed with lock ordering (smaller id first), same opposite transfers ==");
            Account a = new Account(1, 1000), b = new Account(2, 1000);
            Thread t1 = new Thread(() -> transferOrdered(a, b, 100, 100), "T1(A->B)");
            Thread t2 = new Thread(() -> transferOrdered(b, a, 50, 100), "T2(B->A)");
            t1.start(); t2.start(); t1.join(2000); t2.join(2000);
            System.out.println("both finished: " + (!t1.isAlive() && !t2.isAlive()) + "  A=" + a.balance + " B=" + b.balance + " total=" + (a.balance + b.balance) + " (expected 2000)");
            System.out.println("stress: 8 threads x 20,000 random transfers across 10 accounts");
            Account[] acc = new Account[10]; for (int i = 0; i < 10; i++) acc[i] = new Account(i, 1000);
            ExecutorService ex = Executors.newFixedThreadPool(8);
            List<Future<?>> fs = new ArrayList<>();
            long t0 = System.nanoTime();
            for (int k = 0; k < 8; k++) fs.add(ex.submit(() -> {
                ThreadLocalRandom r = ThreadLocalRandom.current();
                for (int i = 0; i < 20_000; i++) { int x = r.nextInt(10), y = r.nextInt(10); if (x != y) transferOrdered(acc[x], acc[y], 1, 0); }
            }));
            boolean done = true;
            for (Future<?> f : fs) { try { f.get(20, TimeUnit.SECONDS); } catch (TimeoutException e) { done = false; } }
            long sum = 0; for (Account x : acc) sum += x.balance;
            System.out.printf("completed=%b time=%d ms total=%d (expected 10000)%n", done, (System.nanoTime() - t0) / 1_000_000, sum);
            ex.shutdownNow();
        }

        if (mode.equals("compare") || mode.equals("all")) {
            System.out.println("\n== Alternative: tryLock(timeout) vs lock ordering, 4 threads, 100,000 transfers, 4 accounts (high contention) ==");
            for (String kind : new String[]{"ordered", "tryLock"}) {
                long best = Long.MAX_VALUE; long sum = 0;
                for (int rep = 0; rep < 3; rep++) {
                    Account[] acc = new Account[4]; for (int i = 0; i < 4; i++) acc[i] = new Account(i, 1000);
                    ExecutorService ex = Executors.newFixedThreadPool(4);
                    List<Future<?>> fs = new ArrayList<>();
                    long t0 = System.nanoTime();
                    for (int k = 0; k < 4; k++) fs.add(ex.submit(() -> {
                        ThreadLocalRandom r = ThreadLocalRandom.current();
                        for (int i = 0; i < 25_000; i++) {
                            int x = r.nextInt(4), y = r.nextInt(4); if (x == y) continue;
                            if (kind.equals("ordered")) transferOrdered(acc[x], acc[y], 1, 0);
                            else { try { transferTry(acc[x], acc[y], 1, 1000); } catch (InterruptedException e) { } }
                        }
                        return null;
                    }));
                    for (Future<?> f : fs) f.get();
                    best = Math.min(best, (System.nanoTime() - t0) / 1_000_000);
                    sum = 0; for (Account x : acc) sum += x.balance;
                    ex.shutdown();
                }
                System.out.printf("%-8s best of 3: %d ms   money conserved: %b%n", kind, best, sum == 4000);
            }
        }
    }
}
