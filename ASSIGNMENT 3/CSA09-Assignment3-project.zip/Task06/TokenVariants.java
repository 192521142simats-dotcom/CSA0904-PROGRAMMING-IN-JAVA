import java.util.*;

/**
 * Q6 Student A - experiments on the producer-consumer counter.
 *   args: mode(while|if) wake(all|one) capacity producerDelayMs runs
 * Records min/max counter size seen, wrong sums, and hangs (timeouts).
 */
public class TokenVariants {
    static class Counter {
        final int[] buf; int count, in, out, min = 0, max = 0;
        final boolean useWhile, wakeAll;
        Counter(int cap, boolean useWhile, boolean wakeAll) { buf = new int[cap]; this.useWhile = useWhile; this.wakeAll = wakeAll; }
        void wake() { if (wakeAll) notifyAll(); else notify(); }
        synchronized void put(int t) throws InterruptedException {
            if (useWhile) while (count == buf.length) wait(); else if (count == buf.length) wait();
            buf[in] = t; in = (in + 1) % buf.length; count++;
            max = Math.max(max, count); wake();
        }
        synchronized int take() throws InterruptedException {
            if (useWhile) while (count == 0) wait(); else if (count == 0) wait();
            int t = buf[out]; out = (out + 1) % buf.length; count--;
            min = Math.min(min, count); wake();
            return t;
        }
    }

    public static void main(String[] a) throws Exception {
        boolean useWhile = a[0].equals("while"), wakeAll = a[1].equals("all");
        int cap = Integer.parseInt(a[2]), delay = Integer.parseInt(a[3]), runs = Integer.parseInt(a[4]);
        int ok = 0, wrong = 0, hang = 0, minAll = 0, maxAll = 0;
        for (int r = 0; r < runs; r++) {
            Counter c = new Counter(cap, useWhile, wakeAll);
            int[] got = new int[2];
            Thread cook = new Thread(() -> { try { for (int t = 1; t <= 20; t++) { c.put(t); if (delay > 0) Thread.sleep(delay); } } catch (InterruptedException e) { } });
            Thread[] st = new Thread[2];
            for (int s = 0; s < 2; s++) { final int id = s; st[s] = new Thread(() -> { try { for (int k = 0; k < 10; k++) got[id] += c.take(); } catch (InterruptedException e) { } }); }
            cook.start(); for (Thread t : st) t.start();
            long deadline = System.currentTimeMillis() + 3000;
            boolean hung = false;
            for (Thread t : new Thread[]{cook, st[0], st[1]}) { t.join(Math.max(1, deadline - System.currentTimeMillis())); if (t.isAlive()) hung = true; }
            if (hung) { hang++; cook.interrupt(); st[0].interrupt(); st[1].interrupt(); for (Thread t : new Thread[]{cook, st[0], st[1]}) t.join(); }
            else if (got[0] + got[1] == 210) ok++; else wrong++;
            synchronized (c) { minAll = Math.min(minAll, c.min); maxAll = Math.max(maxAll, c.max); }
        }
        System.out.printf("mode=%-5s wake=%-3s cap=%d delay=%dms runs=%d -> correct=%d wrongSum=%d hung=%d | counter size seen: min=%d max=%d (legal 0..%d)%n",
                a[0], a[1], cap, delay, runs, ok, wrong, hang, minAll, maxAll, cap);
    }
}
