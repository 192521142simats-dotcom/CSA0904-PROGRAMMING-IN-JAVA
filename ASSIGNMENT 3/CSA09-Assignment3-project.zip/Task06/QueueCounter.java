import java.util.concurrent.*;

/** Q6 Alternative: ArrayBlockingQueue(5) vs wait/notifyAll monitor, 1 cook + 2 students, 200,000 tokens. */
public class QueueCounter {
    static class Monitor {
        final int[] buf = new int[5]; int count, in, out;
        synchronized void put(int t) throws InterruptedException { while (count == 5) wait(); buf[in] = t; in = (in + 1) % 5; count++; notifyAll(); }
        synchronized int take() throws InterruptedException { while (count == 0) wait(); int t = buf[out]; out = (out + 1) % 5; count--; notifyAll(); return t; }
    }

    static long runMonitor(int n) throws Exception {
        Monitor m = new Monitor(); long[] got = new long[2];
        Thread cook = new Thread(() -> { try { for (int t = 1; t <= n; t++) m.put(t); } catch (InterruptedException e) { } });
        Thread[] st = new Thread[2];
        for (int s = 0; s < 2; s++) { final int id = s; st[s] = new Thread(() -> { try { for (int k = 0; k < n / 2; k++) got[id] += m.take(); } catch (InterruptedException e) { } }); }
        long t0 = System.nanoTime(); cook.start(); for (Thread t : st) t.start(); cook.join(); for (Thread t : st) t.join();
        long el = System.nanoTime() - t0;
        if (got[0] + got[1] != (long) n * (n + 1) / 2) throw new IllegalStateException("wrong sum");
        return el;
    }

    static long runQueue(int n) throws Exception {
        ArrayBlockingQueue<Integer> q = new ArrayBlockingQueue<>(5); long[] got = new long[2];
        Thread cook = new Thread(() -> { try { for (int t = 1; t <= n; t++) q.put(t); } catch (InterruptedException e) { } });
        Thread[] st = new Thread[2];
        for (int s = 0; s < 2; s++) { final int id = s; st[s] = new Thread(() -> { try { for (int k = 0; k < n / 2; k++) got[id] += q.take(); } catch (InterruptedException e) { } }); }
        long t0 = System.nanoTime(); cook.start(); for (Thread t : st) t.start(); cook.join(); for (Thread t : st) t.join();
        long el = System.nanoTime() - t0;
        if (got[0] + got[1] != (long) n * (n + 1) / 2) throw new IllegalStateException("wrong sum");
        return el;
    }

    public static void main(String[] a) throws Exception {
        int n = 200_000;
        runMonitor(n); runQueue(n);   // warm-up
        long bm = Long.MAX_VALUE, bq = Long.MAX_VALUE;
        for (int i = 0; i < 5; i++) { bm = Math.min(bm, runMonitor(n)); bq = Math.min(bq, runQueue(n)); }
        System.out.printf("wait/notifyAll monitor : %d ms total, %.0f ns per token (put+take)%n", bm / 1_000_000, bm / (double) n);
        System.out.printf("ArrayBlockingQueue(5)  : %d ms total, %.0f ns per token (put+take)%n", bq / 1_000_000, bq / (double) n);
        System.out.println("Both produced the correct sum " + (long) n * (n + 1) / 2);
    }
}
